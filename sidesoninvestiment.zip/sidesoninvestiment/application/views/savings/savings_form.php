<!doctype html>
<html>
<-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Savings Account</h1>
                </section>

    <script type="text/javascript">
    $('#refresh_table').on('submit', function(e) {
        
        $(this).find('button[type=submit]').prop('disabled', true);
        $('.btn').prop('disabled', true);
        $('.btn').button('loading');
        return true;
    });
    </script>

     <section class="content">
    <div class="box box-info">
    <body>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Borrowers Id <?php echo form_error('borrowers_id') ?></label>
            <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id" id="inputLoanId2" style="">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                              <script src="<?php echo base_url()."assets/";?>select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });
    </script>
                                </select>
        </div>
	    <div class="form-group">
            <label for="int">Savings Product <?php echo form_error('saving_product') ?></label>
             <select data-placeholder="Choose saving product or Search by Name" class="select2 form-control" name="savings_product" id="inputLoanId2" style="">
                                    <option></option>
                                    <?php
                                $savings_product = $this->db->get('savingproduct')->result_array();
                                foreach($savings_product as $row): ?>
                                    <option value="<?php echo $row['savingproduct_id'];?>">
                                    <?php echo $row['savingproduct'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
        </div>
	    <div class="form-group">
            <label for="int">Account No <?php echo form_error('account_no') ?></label>
            <input type="text" class="form-control" name="account_no" id="account_no" placeholder="Account No" value="<?php echo $account_no; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('description') ?></label>
            <input type="text" class="form-control" name="description" id="description" placeholder="Description" value="<?php echo $description; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Last Transaction <?php echo form_error('last_transaction') ?></label>
            <input type="text" class="form-control" name="last_transaction" id="last_transaction" placeholder="Last Transaction" value="<?php echo $last_transaction; ?>" />
        </div>
	    
	    <input type="hidden" name="saving_id" value="<?php echo $saving_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('savings') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>