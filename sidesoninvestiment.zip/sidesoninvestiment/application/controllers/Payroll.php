<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Payroll extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Payroll_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('payroll/payroll_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Payroll_model->json();
    }

    public function read($id) 
    {
        $row = $this->Payroll_model->get_by_id($id);
        if ($row) {
            $data = array(
		'payroll_id' => $row->payroll_id,
		'Employee_name' => $row->Employee_name,
		'Payroll_Date' => $row->Payroll_Date,
		'Business_Name' => $row->Business_Name,
		'Basic_Pay' => $row->Basic_Pay,
		'Overtime' => $row->Overtime,
		'Paid_Leaves' => $row->Paid_Leaves,
		'Transport_Allowance' => $row->Transport_Allowance,
		'Medical_Allowance' => $row->Medical_Allowance,
		'Bonus' => $row->Bonus,
		'Other_Allowance' => $row->Other_Allowance,
		'Pension' => $row->Pension,
		'Health_Insurance' => $row->Health_Insurance,
		'Unpaid_Leave' => $row->Unpaid_Leave,
		'Tax_Deduction' => $row->Tax_Deduction,
		'Salary_Loan' => $row->Salary_Loan,
		'Total_Pay' => $row->Total_Pay,
		'Total_Deductions' => $row->Total_Deductions,
		'Net_Pay' => $row->Net_Pay,
		'Payment_Method' => $row->Payment_Method,
		'Bank_Name' => $row->Bank_Name,
		'Account_Number' => $row->Account_Number,
		'Description' => $row->Description,
		'Paid_Amount' => $row->Paid_Amount,
		'Comments' => $row->Comments,
		'time_date' => $row->time_date,
	    );
            $this->load->view('payroll/payroll_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('payroll'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('payroll/create_action'),
	    'payroll_id' => set_value('payroll_id'),
	    'Employee_name' => set_value('Employee_name'),
	    'Payroll_Date' => set_value('Payroll_Date'),
	    'Business_Name' => set_value('Business_Name'),
	    'Basic_Pay' => set_value('Basic_Pay'),
	    'Overtime' => set_value('Overtime'),
	    'Paid_Leaves' => set_value('Paid_Leaves'),
	    'Transport_Allowance' => set_value('Transport_Allowance'),
	    'Medical_Allowance' => set_value('Medical_Allowance'),
	    'Bonus' => set_value('Bonus'),
	    'Other_Allowance' => set_value('Other_Allowance'),
	    'Pension' => set_value('Pension'),
	    'Health_Insurance' => set_value('Health_Insurance'),
	    'Unpaid_Leave' => set_value('Unpaid_Leave'),
	    'Tax_Deduction' => set_value('Tax_Deduction'),
	    'Salary_Loan' => set_value('Salary_Loan'),
	    'Total_Pay' => set_value('Total_Pay'),
	    'Total_Deductions' => set_value('Total_Deductions'),
	    'Net_Pay' => set_value('Net_Pay'),
	    'Payment_Method' => set_value('Payment_Method'),
	    'Bank_Name' => set_value('Bank_Name'),
	    'Account_Number' => set_value('Account_Number'),
	    'Description' => set_value('Description'),
	    'Paid_Amount' => set_value('Paid_Amount'),
	    'Comments' => set_value('Comments'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('payroll/payroll_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Employee_name' => $this->input->post('Employee_name',TRUE),
		'Payroll_Date' => $this->input->post('Payroll_Date',TRUE),
		'Business_Name' => $this->input->post('Business_Name',TRUE),
		'Basic_Pay' => $this->input->post('Basic_Pay',TRUE),
		'Overtime' => $this->input->post('Overtime',TRUE),
		'Paid_Leaves' => $this->input->post('Paid_Leaves',TRUE),
		'Transport_Allowance' => $this->input->post('Transport_Allowance',TRUE),
		'Medical_Allowance' => $this->input->post('Medical_Allowance',TRUE),
		'Bonus' => $this->input->post('Bonus',TRUE),
		'Other_Allowance' => $this->input->post('Other_Allowance',TRUE),
		'Pension' => $this->input->post('Pension',TRUE),
		'Health_Insurance' => $this->input->post('Health_Insurance',TRUE),
		'Unpaid_Leave' => $this->input->post('Unpaid_Leave',TRUE),
		'Tax_Deduction' => $this->input->post('Tax_Deduction',TRUE),
		'Salary_Loan' => $this->input->post('Salary_Loan',TRUE),
		'Total_Pay' => $this->input->post('Total_Pay',TRUE),
		'Total_Deductions' => $this->input->post('Total_Deductions',TRUE),
		'Net_Pay' => $this->input->post('Net_Pay',TRUE),
		'Payment_Method' => $this->input->post('Payment_Method',TRUE),
		'Bank_Name' => $this->input->post('Bank_Name',TRUE),
		'Account_Number' => $this->input->post('Account_Number',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Paid_Amount' => $this->input->post('Paid_Amount',TRUE),
		'Comments' => $this->input->post('Comments',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Payroll_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('payroll'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Payroll_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('payroll/update_action'),
		'payroll_id' => set_value('payroll_id', $row->payroll_id),
		'Employee_name' => set_value('Employee_name', $row->Employee_name),
		'Payroll_Date' => set_value('Payroll_Date', $row->Payroll_Date),
		'Business_Name' => set_value('Business_Name', $row->Business_Name),
		'Basic_Pay' => set_value('Basic_Pay', $row->Basic_Pay),
		'Overtime' => set_value('Overtime', $row->Overtime),
		'Paid_Leaves' => set_value('Paid_Leaves', $row->Paid_Leaves),
		'Transport_Allowance' => set_value('Transport_Allowance', $row->Transport_Allowance),
		'Medical_Allowance' => set_value('Medical_Allowance', $row->Medical_Allowance),
		'Bonus' => set_value('Bonus', $row->Bonus),
		'Other_Allowance' => set_value('Other_Allowance', $row->Other_Allowance),
		'Pension' => set_value('Pension', $row->Pension),
		'Health_Insurance' => set_value('Health_Insurance', $row->Health_Insurance),
		'Unpaid_Leave' => set_value('Unpaid_Leave', $row->Unpaid_Leave),
		'Tax_Deduction' => set_value('Tax_Deduction', $row->Tax_Deduction),
		'Salary_Loan' => set_value('Salary_Loan', $row->Salary_Loan),
		'Total_Pay' => set_value('Total_Pay', $row->Total_Pay),
		'Total_Deductions' => set_value('Total_Deductions', $row->Total_Deductions),
		'Net_Pay' => set_value('Net_Pay', $row->Net_Pay),
		'Payment_Method' => set_value('Payment_Method', $row->Payment_Method),
		'Bank_Name' => set_value('Bank_Name', $row->Bank_Name),
		'Account_Number' => set_value('Account_Number', $row->Account_Number),
		'Description' => set_value('Description', $row->Description),
		'Paid_Amount' => set_value('Paid_Amount', $row->Paid_Amount),
		'Comments' => set_value('Comments', $row->Comments),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('payroll/payroll_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('payroll'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('payroll_id', TRUE));
        } else {
            $data = array(
		'Employee_name' => $this->input->post('Employee_name',TRUE),
		'Payroll_Date' => $this->input->post('Payroll_Date',TRUE),
		'Business_Name' => $this->input->post('Business_Name',TRUE),
		'Basic_Pay' => $this->input->post('Basic_Pay',TRUE),
		'Overtime' => $this->input->post('Overtime',TRUE),
		'Paid_Leaves' => $this->input->post('Paid_Leaves',TRUE),
		'Transport_Allowance' => $this->input->post('Transport_Allowance',TRUE),
		'Medical_Allowance' => $this->input->post('Medical_Allowance',TRUE),
		'Bonus' => $this->input->post('Bonus',TRUE),
		'Other_Allowance' => $this->input->post('Other_Allowance',TRUE),
		'Pension' => $this->input->post('Pension',TRUE),
		'Health_Insurance' => $this->input->post('Health_Insurance',TRUE),
		'Unpaid_Leave' => $this->input->post('Unpaid_Leave',TRUE),
		'Tax_Deduction' => $this->input->post('Tax_Deduction',TRUE),
		'Salary_Loan' => $this->input->post('Salary_Loan',TRUE),
		'Total_Pay' => $this->input->post('Total_Pay',TRUE),
		'Total_Deductions' => $this->input->post('Total_Deductions',TRUE),
		'Net_Pay' => $this->input->post('Net_Pay',TRUE),
		'Payment_Method' => $this->input->post('Payment_Method',TRUE),
		'Bank_Name' => $this->input->post('Bank_Name',TRUE),
		'Account_Number' => $this->input->post('Account_Number',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Paid_Amount' => $this->input->post('Paid_Amount',TRUE),
		'Comments' => $this->input->post('Comments',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Payroll_model->update($this->input->post('payroll_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('payroll'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Payroll_model->get_by_id($id);

        if ($row) {
            $this->Payroll_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('payroll'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('payroll'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Employee_name', 'employee name', 'trim|required');
	$this->form_validation->set_rules('Payroll_Date', 'payroll date', 'trim|required');
	$this->form_validation->set_rules('Business_Name', 'business name', 'trim|required');
	$this->form_validation->set_rules('Basic_Pay', 'basic pay', 'trim|required');
	$this->form_validation->set_rules('Overtime', 'overtime', 'trim|required');
	$this->form_validation->set_rules('Paid_Leaves', 'paid leaves', 'trim|required');
	$this->form_validation->set_rules('Transport_Allowance', 'transport allowance', 'trim|required');
	$this->form_validation->set_rules('Medical_Allowance', 'medical allowance', 'trim|required');
	$this->form_validation->set_rules('Bonus', 'bonus', 'trim|required');
	$this->form_validation->set_rules('Other_Allowance', 'other allowance', 'trim|required');
	$this->form_validation->set_rules('Pension', 'pension', 'trim|required');
	$this->form_validation->set_rules('Health_Insurance', 'health insurance', 'trim|required');
	$this->form_validation->set_rules('Unpaid_Leave', 'unpaid leave', 'trim|required');
	$this->form_validation->set_rules('Tax_Deduction', 'tax deduction', 'trim|required');
	$this->form_validation->set_rules('Salary_Loan', 'salary loan', 'trim|required');
	$this->form_validation->set_rules('Total_Pay', 'total pay', 'trim|required');
	$this->form_validation->set_rules('Total_Deductions', 'total deductions', 'trim|required');
	$this->form_validation->set_rules('Net_Pay', 'net pay', 'trim|required');
	$this->form_validation->set_rules('Payment_Method', 'payment method', 'trim|required');
	$this->form_validation->set_rules('Bank_Name', 'bank name', 'trim|required');
	$this->form_validation->set_rules('Account_Number', 'account number', 'trim|required');
	$this->form_validation->set_rules('Description', 'description', 'trim|required');
	$this->form_validation->set_rules('Paid_Amount', 'paid amount', 'trim|required');
	$this->form_validation->set_rules('Comments', 'comments', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('payroll_id', 'payroll_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Payroll.php */
/* Location: ./application/controllers/Payroll.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */