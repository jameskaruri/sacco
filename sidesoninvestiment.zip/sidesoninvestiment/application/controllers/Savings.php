<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Savings extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Savings_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {    $this->load->view('header/link');
        $this->load->view('savings/view_savings_branch');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Savings_model->json();
    }

    public function read($id) 
    {
        $row = $this->Savings_model->get_by_id($id);
        if ($row) {
            $data = array(
		'saving_id' => $row->saving_id,
		'borrowers_id' => $row->borrowers_id,
		'savings_product' => $row->savings_product,
		'account_no' => $row->account_no,
		'description' => $row->description,
		'last_transaction' => $row->last_transaction,
		
	    );
            $this->load->view('header/link');
            $this->load->view('savings/savings_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('savings'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('savings/create_action'),
	    'saving_id' => set_value('saving_id'),
	    'borrowers_id' => set_value('borrowers_id'),
	    'savings_product' => set_value('savings_product'),
	    'account_no' => set_value('account_no'),
	    'description' => set_value('description'),
	    'last_transaction' => set_value('last_transaction'),
	    
	);
        $this->load->view('header/link');
        $this->load->view('savings/add_savings_account', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'savings_product' => $this->input->post('savings_product',TRUE),
		'account_no' => $this->input->post('account_no',TRUE),
		'description' => $this->input->post('description',TRUE),
		'last_transaction' => $this->input->post('last_transaction',TRUE),
		
	    );
            $this->Savings_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('savings'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Savings_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('savings/update_action'),
		'saving_id' => set_value('saving_id', $row->saving_id),
		'borrowers_id' => set_value('borrowers_id', $row->borrowers_id),
		'savings_product' => set_value('savings_product', $row->savings_product),
		'account_no' => set_value('account_no', $row->account_no),
		'description' => set_value('description', $row->description),
		'last_transaction' => set_value('last_transaction', $row->last_transaction),
		
	    );
             $this->load->view('header/link');
            $this->load->view('savings/savings_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('savings'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('saving_id', TRUE));
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'savings_product' => $this->input->post('savings_product',TRUE),
		'account_no' => $this->input->post('account_no',TRUE),
		'description' => $this->input->post('description',TRUE),
		'last_transaction' => $this->input->post('last_transaction',TRUE),
		
	    );

            $this->Savings_model->update($this->input->post('saving_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('savings'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Savings_model->get_by_id($id);

        if ($row) {
            $this->Savings_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('savings'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('savings'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('borrowers_id', 'borrowers id', 'trim|required');
	$this->form_validation->set_rules('savings_product', 'savings product', 'trim|required');
	$this->form_validation->set_rules('account_no', 'account no', 'trim|required');
	$this->form_validation->set_rules('description', 'description', 'trim|required');
	

	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

