<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Repayments Read</h2>
        <table class="table">
	    <tr><td>Borrowers Id</td><td><?php echo $borrowers_id; ?></td></tr>
	    <tr><td>Amout</td><td><?php echo $amout; ?></td></tr>
	    <tr><td>Method</td><td><?php echo $method; ?></td></tr>
	    <tr><td>Date Collected</td><td><?php echo $date_collected; ?></td></tr>
	    <tr><td>Collected By</td><td><?php echo $collected_by; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $description; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('repayments') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>