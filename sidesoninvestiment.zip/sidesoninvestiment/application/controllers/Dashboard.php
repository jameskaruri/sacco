<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard extends CI_Controller{
  public function index(){
    $this->load->view('header/link');
    $this->load->view('home/home_branch');
  }
}
