<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Borrowers_model extends CI_Model
{

    public $table = 'borrowers';
    public $id = 'borrowers_id';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // datatables
    function json() {
        $this->datatables->select('borrowers_id,borrower_surname,borrower_firstname,borrower_lastname,borrower_id_number,borrower_email,borrower_mobile,borrower_gender,borrower_title,borrower_dob,borrower_address,borrower_zipcode,borrower_town,borrower_street,borrower_estate,borrower_nearestcommonfeature,borrower_picture,borrower_description,borrower_id,borrower_business_name,borrower_business_nature,borrower_business_Duration,Business_owner,address1,zipcode1,town1,street1,estate1,nearestcommonfeature1,business_location,residence_location,borrower_access_ids,created_at,updated_at');
        $this->datatables->from('borrowers');
        //add this line for join
        //$this->datatables->join('table2', 'borrowers.field = table2.field');
        $this->datatables->add_column('action', anchor(site_url('borrowers/read/$1'),'View','class="btn btn-primary btn-xs"')." | ".anchor(site_url('borrowers/update/$1'),'Edit','class="btn btn-info btn-xs"')." | ".anchor(site_url('borrowers/delete/$1'),'Delete','class="btn btn-danger btn-xs"','onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'borrowers_id');
        return $this->datatables->generate();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }

    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('borrowers_id', $q);
	$this->db->or_like('borrower_surname', $q);
	$this->db->or_like('borrower_firstname', $q);
	$this->db->or_like('borrower_lastname', $q);
	$this->db->or_like('borrower_id_number', $q);
	$this->db->or_like('borrower_email', $q);
	$this->db->or_like('borrower_mobile', $q);
	$this->db->or_like('borrower_gender', $q);
	$this->db->or_like('borrower_title', $q);
	$this->db->or_like('borrower_dob', $q);
	$this->db->or_like('borrower_address', $q);
	$this->db->or_like('borrower_zipcode', $q);
	$this->db->or_like('borrower_town', $q);
	$this->db->or_like('borrower_street', $q);
	$this->db->or_like('borrower_estate', $q);
	$this->db->or_like('borrower_nearestcommonfeature', $q);
	$this->db->or_like('borrower_picture', $q);
	$this->db->or_like('borrower_description', $q);
	$this->db->or_like('borrower_id', $q);
	$this->db->or_like('borrower_business_name', $q);
	$this->db->or_like('borrower_business_nature', $q);
	$this->db->or_like('borrower_business_Duration', $q);
	$this->db->or_like('Business_owner', $q);
	$this->db->or_like('address1', $q);
	$this->db->or_like('zipcode1', $q);
	$this->db->or_like('town1', $q);
	$this->db->or_like('street1', $q);
	$this->db->or_like('estate1', $q);
	$this->db->or_like('nearestcommonfeature1', $q);
	$this->db->or_like('business_location', $q);
	$this->db->or_like('residence_location', $q);
	$this->db->or_like('borrower_access_ids', $q);
	$this->db->or_like('created_at', $q);
	$this->db->or_like('updated_at', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('borrowers_id', $q);
	$this->db->or_like('borrower_surname', $q);
	$this->db->or_like('borrower_firstname', $q);
	$this->db->or_like('borrower_lastname', $q);
	$this->db->or_like('borrower_id_number', $q);
	$this->db->or_like('borrower_email', $q);
	$this->db->or_like('borrower_mobile', $q);
	$this->db->or_like('borrower_gender', $q);
	$this->db->or_like('borrower_title', $q);
	$this->db->or_like('borrower_dob', $q);
	$this->db->or_like('borrower_address', $q);
	$this->db->or_like('borrower_zipcode', $q);
	$this->db->or_like('borrower_town', $q);
	$this->db->or_like('borrower_street', $q);
	$this->db->or_like('borrower_estate', $q);
	$this->db->or_like('borrower_nearestcommonfeature', $q);
	$this->db->or_like('borrower_picture', $q);
	$this->db->or_like('borrower_description', $q);
	$this->db->or_like('borrower_id', $q);
	$this->db->or_like('borrower_business_name', $q);
	$this->db->or_like('borrower_business_nature', $q);
	$this->db->or_like('borrower_business_Duration', $q);
	$this->db->or_like('Business_owner', $q);
	$this->db->or_like('address1', $q);
	$this->db->or_like('zipcode1', $q);
	$this->db->or_like('town1', $q);
	$this->db->or_like('street1', $q);
	$this->db->or_like('estate1', $q);
	$this->db->or_like('nearestcommonfeature1', $q);
	$this->db->or_like('business_location', $q);
	$this->db->or_like('residence_location', $q);
	$this->db->or_like('borrower_access_ids', $q);
	$this->db->or_like('created_at', $q);
	$this->db->or_like('updated_at', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }
    //cheking if borrower exist before add
    function check_if_user_exist($borrower_id_number){
    	$this->db->where('borrower_id_number',$borrower_id_number);
    	$this->db->from($this->table);
    	$query=$this->db->get();
    	if ($query->num_rows()>0) {
    		return true;
    	}
    	else{
    		
    		return false;
    	}

    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}
