$(document).ready(function() {          
    $(".confirm_action").unbind().click(function(e) {
        e.preventDefault();
        var href_value = $(this).attr('href');
        var confirm_text = $(this).attr('actionconfirm');
        $.confirm({
            title: 'Please Confirm',
            content: 'Are you sure you want to ' + confirm_text + '?',
            type: 'green',
            buttons: {
                confirm: function () {
                    window.location = href_value;
                    return true;
                },
                cancel: function () {
                    return true;
                }
            }  
        });
    });
});