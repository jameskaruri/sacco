
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Bulk Repayments</h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="row row-grid">
        <div id="pre_loader">
            <div class="loader"></div>
            <div style="text-align:center; font-weight:bold;font-style:italic;">Loading Add Bulk Repayments. Please wait...</div>
        </div>
    </div>
<script type="text/javascript">

    function updatesum()
    {
        var inputRepaymentAmountTotal = 0;

        for(var i=1; i <= 20; i++)
        {
            var inputRepaymentAmount = document.getElementById("inputRepaymentAmount" + i).value;

            if (inputRepaymentAmount == "")
                inputRepaymentAmount = 0;

            inputRepaymentAmountTotal = parseFloat(inputRepaymentAmountTotal) + parseFloat(inputRepaymentAmount)*100;
        }
        document.getElementById("RepaymentAmountTotal").innerHTML = numberWithCommas((inputRepaymentAmountTotal / 100).toFixed(2));
    }
    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
</script>
    <script src="<?php echo base_url()."assets/";?>select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });
    </script>
    <h2 style="margin-top:0px"></h2>

            <?php echo form_open_multipart('repayments/create_action', 'id="form"','class="form-horizontal"'); ?>
            
       
         <div class="box box-info">
            <div class="box-body">
                <p>You can use this page to add bulk repayments. Please be careful that you select the right loan. You can enter as many rows as you like.</p>

                <p>To make this page fullscreen, <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">click here.</a></p>

                <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr class="bg-blue">
                            <th>Row</th>
                            <th>Loan</th>
                            <th>Amount</th>
                            <th>Method</th>

                            <th>Collection By <small></small></th>
                            <th>Description (optional)</th>
                        </tr>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                1
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[1]" id="inputLoanId1" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
								$borrowers_get = $this->db->get('borrowers')->result_array();
								foreach($borrowers_get as $row): ?>
                            		<option value="<?php echo $row['borrowers_id'];?>">
									<?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
								endforeach;
							  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[1]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount1" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[1]" id="inputRepaymentMethodId1">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>

                                <script type="text/javascript">
                                    $("#SetDefaultMethods").click(function(){
                                        var inputRepaymentMethodId1 = $("#inputRepaymentMethodId1 option:selected").index() + 1;
                                        for(var i=2; i <= 20; i++)
                                        {
                                            $("#inputRepaymentMethodId" + i + " :nth-child(" + inputRepaymentMethodId1 + ")").prop("selected", true);
                                        }
                                    });
                                 </script>
                            </td>



                                <script type="text/javascript">
                                    $("#SetDefaultDates").click(function(){
                                        var inputRepaymentDate1 = document.getElementById("inputRepaymentDate1").value;
                                        for(var i=2; i <= 20; i++)
                                        {
                                            $("#inputRepaymentDate" + i).val(inputRepaymentDate1);
                                        }
                                    });
                                 </script>
                            </td>
                            <td>
                                <select  class="form-control" name="collected_by[1]" id="inputRepaymentCollectorId1">
                                    <option value=""></option>
                                  <?php  $get_staff = $this->db->get('staff')->result_array();
                    								foreach($get_staff as $row): ?>
                                                		<option value="<?php echo $row['staff_id'];?>">
                    									<?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                    								endforeach;
                    							  ?>
                                </select>

                                <script type="text/javascript">
                                    $("#SetDefaultCollectors").click(function(){
                                        var inputRepaymentCollectorId1 = $("#inputRepaymentCollectorId1 option:selected").index() + 1;
                                        for(var i=2; i <= 20; i++)
                                        {
                                            $("#inputRepaymentCollectorId" + i + " :nth-child(" + inputRepaymentCollectorId1 + ")").prop("selected", true);
                                        }
                                    });
                                 </script>
                            </td>
                            <td>
                                <input type="text" name="description[1]" class="form-control" id="inputDescription1" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                2
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[2]" id="inputLoanId2" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[2]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount2" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[2]" id="inputRepaymentMethodId2">
                                    <option value="Cash" >Cash</option>
                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[2]" id="inputRepaymentCollectorId2">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[2]" class="form-control" id="inputDescription2" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                3
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[3]" id="inputLoanId3" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[3]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount3" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[3]" id="inputRepaymentMethodId3">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[3]" id="inputRepaymentCollectorId3">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[3]" class="form-control" id="inputDescription3" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                4
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[4]" id="inputLoanId4" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[4]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount4" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[4]" id="inputRepaymentMethodId4">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[4]" id="inputRepaymentCollectorId4">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[4]" class="form-control" id="inputDescription4" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                5
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[5]" id="inputLoanId5" style="width: 350px">
                                    <option></option>
                                   <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[5]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount5" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[5]" id="inputRepaymentMethodId5">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>


                            <td>
                                <select  class="form-control" name="collected_by[5]" id="inputRepaymentCollectorId5">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[5]" class="form-control" id="inputDescription5" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                6
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[6]" id="inputLoanId6" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[6]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount6" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[6]" id="inputRepaymentMethodId6">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[6]" id="inputRepaymentCollectorId6">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[6]" class="form-control" id="inputDescription6" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                7
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[7]" id="inputLoanId7" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[7]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount7" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[7]" id="inputRepaymentMethodId7">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[7]" id="inputRepaymentCollectorId7">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[7]" class="form-control" id="inputDescription7" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                8
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[8]" id="inputLoanId8" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[8]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount8" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[8]" id="inputRepaymentMethodId8">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[8]" id="inputRepaymentCollectorId8">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[8]" class="form-control" id="inputDescription8" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                9
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[9]" id="inputLoanId9" style="width: 350px">
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[9]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount9" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[9]" id="inputRepaymentMethodId9">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[9]" id="inputRepaymentCollectorId9">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[9]" class="form-control" id="inputDescription9" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                10
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[10]" id="inputLoanId10" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[10]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount10" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[10]" id="inputRepaymentMethodId10">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[10]" id="inputRepaymentCollectorId10">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[10]" class="form-control" id="inputDescription10" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                11
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[11]" id="inputLoanId11" style="width: 350px">
                                    <option></option>
                                   <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[11]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount11" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[11]" id="inputRepaymentMethodId11">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[11]" id="inputRepaymentCollectorId11">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[11]" class="form-control" id="inputDescription11" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                12
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[12]" id="inputLoanId12" style="width: 350px">
                                    <option></option>
                                   <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[12]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount12" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[12]" id="inputRepaymentMethodId12">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[12]" id="inputRepaymentCollectorId12">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[12]" class="form-control" id="inputDescription12" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                13
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[13]" id="inputLoanId13" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[13]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount13" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[13]" id="inputRepaymentMethodId13">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[13]" id="inputRepaymentCollectorId13">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[13]" class="form-control" id="inputDescription13" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                14
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[14]" id="inputLoanId14" style="width: 350px">
                                    <option></option>
                                  <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[14]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount14" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[14]" id="inputRepaymentMethodId14">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[14]" id="inputRepaymentCollectorId14">
                                    <option value=""></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[14]" class="form-control" id="inputDescription14" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                15
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[15]" id="inputLoanId15" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[15]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount15" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[15]" id="inputRepaymentMethodId15">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[15]" id="inputRepaymentCollectorId15">
                                    <option></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[15]" class="form-control" id="inputDescription15" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                16
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[16]" id="inputLoanId16" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[16]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount16" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[16]" id="inputRepaymentMethodId16">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>
                            <td>
                              
                                <select  class="form-control" name="collected_by[16]" id="inputRepaymentCollectorId16">
                                    <option></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[16]" class="form-control" id="inputDescription16" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                17
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[17]" id="inputLoanId17" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[17]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount17" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[17]" id="inputRepaymentMethodId17">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[17]" id="inputRepaymentCollectorId17">
                                    <option></option>
                                    <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[17]" class="form-control" id="inputDescription17" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                18
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[18]" id="inputLoanId18" style="width: 350px">
                                    <option></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[18]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount18" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[18]" id="inputRepaymentMethodId18">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[18]" id="inputRepaymentCollectorId18">
                                    <option></option>
                                     <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[18]" class="form-control" id="inputDescription18" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                19
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[19]" id="inputLoanId19" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[19]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount19" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[19]" id="inputRepaymentMethodId19">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[19]" id="inputRepaymentCollectorId19">
                                    <option></option>
                                    <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[19]" class="form-control" id="inputDescription19" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                20
                            </td>
                            <td>
                                <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id[20]" id="inputLoanId20" style="width: 350px">
                                    <option></option>
                                    <option value=""></option>
                                    <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="amout[20]" class="form-control text-right decimal-2-places" id="inputRepaymentAmount20" placeholder="Amount" value="" onKeyUp="updatesum()">
                            </td>
                            <td>
                                <select class="form-control" name="method[20]" id="inputRepaymentMethodId20">
                                    <option value="Cash" >Cash</option>

                                    <option value="Cheque" >Cheque</option>

                                </select>
                            </td>

                            <td>
                                <select  class="form-control" name="collected_by[20]" id="inputRepaymentCollectorId20">
                                    <option></option>
                                    <?php  $get_staff = $this->db->get('staff')->result_array();
                                                    foreach($get_staff as $row): ?>
                                                        <option value="<?php echo $row['staff_id'];?>">
                                                        <?php echo $row['surname'];?>&nbsp&nbsp<?php echo $row['Fname'];?>&nbsp&nbsp<?php echo $row['Lname'];?>
                                                        </option>
                                                    <?php
                                                    endforeach;
                                                  ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="description[20]" class="form-control" id="inputDescription20" placeholder="Description" value="">
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td class="text-bold text-right">
                                Total:
                            </td>
                            <td class="text-bold text-right">
                                <div id="RepaymentAmountTotal">0</div>
                            </td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                   </tbody>
             </table>
             <button type="submit" class="btn btn-info pull-right" class="btn btn-info pull-right" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Please Wait. This can take a few minutes.">Submit</button>

    <script type="text/javascript">
    $('#form').on('submit', function(e) {

        $(this).find('button[type=submit]').prop('disabled', true);
        $('.btn').prop('disabled', true);
        $('.btn').button('loading');
        return true;
    });
    </script>
            </div>
          </div>
       </div>
<?php echo form_close(); ?>
    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>


    </body>
</html>
