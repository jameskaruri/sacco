<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Colletral <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Borrowers Id <?php echo form_error('borrowers_id') ?></label>
            <input type="text" class="form-control" name="borrowers_id" id="borrowers_id" placeholder="Borrowers Id" value="<?php echo $borrowers_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Type <?php echo form_error('type') ?></label>
            <input type="text" class="form-control" name="type" id="type" placeholder="Type" value="<?php echo $type; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Productname <?php echo form_error('productname') ?></label>
            <input type="text" class="form-control" name="productname" id="productname" placeholder="Productname" value="<?php echo $productname; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Register <?php echo form_error('register') ?></label>
            <input type="text" class="form-control" name="register" id="register" placeholder="Register" value="<?php echo $register; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Value <?php echo form_error('value') ?></label>
            <input type="text" class="form-control" name="value" id="value" placeholder="Value" value="<?php echo $value; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Colletralstatus <?php echo form_error('colletralstatus') ?></label>
            <input type="text" class="form-control" name="colletralstatus" id="colletralstatus" placeholder="Colletralstatus" value="<?php echo $colletralstatus; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Colletralstatus Date <?php echo form_error('colletralstatus date') ?></label>
            <input type="text" class="form-control" name="colletralstatus date" id="colletralstatus date" placeholder="Colletralstatus Date" value="<?php echo $colletralstatus date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Serialno <?php echo form_error('serialno') ?></label>
            <input type="text" class="form-control" name="serialno" id="serialno" placeholder="Serialno" value="<?php echo $serialno; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Modelname <?php echo form_error('modelname') ?></label>
            <input type="text" class="form-control" name="modelname" id="modelname" placeholder="Modelname" value="<?php echo $modelname; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Datemanufacured <?php echo form_error('datemanufacured') ?></label>
            <input type="text" class="form-control" name="datemanufacured" id="datemanufacured" placeholder="Datemanufacured" value="<?php echo $datemanufacured; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Colletracondition <?php echo form_error('colletracondition') ?></label>
            <input type="text" class="form-control" name="colletracondition" id="colletracondition" placeholder="Colletracondition" value="<?php echo $colletracondition; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Address <?php echo form_error('address') ?></label>
            <input type="text" class="form-control" name="address" id="address" placeholder="Address" value="<?php echo $address; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('description') ?></label>
            <input type="text" class="form-control" name="description" id="description" placeholder="Description" value="<?php echo $description; ?>" />
        </div>
	    <div class="form-group">
            <label for="longblob">Photo <?php echo form_error('photo') ?></label>
            <input type="text" class="form-control" name="photo" id="photo" placeholder="Photo" value="<?php echo $photo; ?>" />
        </div>
	    <div class="form-group">
            <label for="longblob">File <?php echo form_error('file') ?></label>
            <input type="text" class="form-control" name="file" id="file" placeholder="File" value="<?php echo $file; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="colletral_id" value="<?php echo $colletral_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('colletral') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>