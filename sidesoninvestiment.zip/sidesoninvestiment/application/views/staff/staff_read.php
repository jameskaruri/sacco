<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Staff Read</h2>
        <table class="table">
	    <tr><td>Surname</td><td><?php echo $surname; ?></td></tr>
	    <tr><td>Fname</td><td><?php echo $Fname; ?></td></tr>
	    <tr><td>Lname</td><td><?php echo $Lname; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Employee Number</td><td><?php echo $Employee_number; ?></td></tr>
	    <tr><td>Idno</td><td><?php echo $Idno; ?></td></tr>
	    <tr><td>Job</td><td><?php echo $job; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('staff') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>