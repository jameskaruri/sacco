<?php
//function login()
$con = mysqli_connect("localhost","root","0714057392","sacco");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  else
  {
  	//echo "connection established";
  }

?> 
