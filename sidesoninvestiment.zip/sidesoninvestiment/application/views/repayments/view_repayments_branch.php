
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>View Repayments<small><a href="http://support.loandisk.com/support/solutions/articles/17000014715-view-repayments" target="_blank">Help</a></small></h1>
                </section>

                <!-- Main content -->
                <section class="content">
        <script>
        $(document).ready(function () {
          $(".slidingDiv").hide();       
          $('.show_hide').click(function (e) {
            $(".slidingDiv").slideToggle("fast");
            var val = $(this).text() == "Hide" ? "Show" : "Hide";
            $(this).hide().text(val).fadeIn("fast");
            e.preventDefault();
          });
        });
        </script>
       
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                    <div class="pull-left">
                        <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            <div class="btn-group-horizontal">
                <a type="button" class="btn btn-block btn-default" "></a>
            </div>
                    </div>
                </div>
            </div>              
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
                    <table id="view-repayments" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
                        <thead>
                            <tr style="background-color: #D1F9FF">
                                   <th width="80px">No</th>
            <th>Borrowers Id</th>
            <th>Amout</th>
            <th>Method</th>
            
            <th>Collected By</th>
            <th>Description</th>
            <th>Time Date</th>
            <th width="200px">Action</th>
                
                </tr>
            </thead>
                    </table>
                </div>
            </div>
        </div>
    <script type="text/javascript" language="javascript">
        
        $(document).ready(function() {
            var dataTable = $('#view-repayments').DataTable( {
                "fixedHeader": {
                    "header": false,
                    "footer": false
                },
                "dom": '<"pull-left"f>r<"pull-right"l>tip',"order": [0, 'desc'],
                "autoWidth": true,
                "lengthMenu": [[10,20, 50, 100, 250, 500, 5000], [10,20, 50, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": true,
                "responsive": true,
            
                ajax: {"url": "repayments/json", "type": "POST"},
                    columns: [
                        {
                            "data": "repayment_id",
                            "orderable": false
                        },{"data": "borrowers_id"},{"data": "amout"},{"data": "method"},{"data": "collected_by"},{"data": "description"},{"data": "time_date"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                stateSave: true
            } );
             var buttons = new $.fn.dataTable.Buttons(dataTable, {
                 "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export Data',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'print'
                        ]
                    }
                ]
            }).container().appendTo($('#export_button'));
            
            $("#view-repayments").unbind().on('click', '.confirm_action', function(e){
                e.preventDefault();
                var href_value = $(this).attr('href');
                var confirm_text = $(this).attr('actionconfirm');
                $.confirm({
                    title: 'Please Confirm',
                    content: 'Are you sure you want to ' + confirm_text + '?',
                    type: 'green',
                    buttons: {
                        confirm: function () {
                            window.location = href_value;
                            return true;
                        },
                        cancel: function () {
                            return true;
                        }
                    }  
                });
            });
        } );
    </script>
    
    <script>
    $( "#pre_loader" ).hide();
    </script>
    
                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>
            
            
    </body>
</html>
