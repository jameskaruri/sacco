<!doctype html>
<html>
    <head>
         <div class="content-wrapper">
                <!-- Content Header (Page header) -->
               
                <!-- Main content -->
               
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                   
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            
                    </div>
                </div>
            </div> 
    <body>
        <h2 style="margin-top:0px">Loan Read</h2>
        <table class="table">
	    <tr><td>Borrowers Id</td><td><?php echo $borrowers_id; ?></td></tr>
	    <tr><td>Loan Product</td><td><?php echo $Loan_product_id; ?></td></tr>
	    <tr><td>Loan</td><td><?php echo $loan; ?></td></tr>
	    <tr><td>Loan Disbursed By Id</td><td><?php echo $loan_disbursed_by_id; ?></td></tr>
	    <tr><td>Loan Principal Amount</td><td><?php echo $loan_principal_amount; ?></td></tr>
	    <tr><td>Loan Released Date</td><td><?php echo $loan_released_date; ?></td></tr>
	    <tr><td>Loan Interest Method</td><td><?php echo $loan_interest_method; ?></td></tr>
	    <tr><td>Loan Interest Type</td><td><?php echo $loan_interest_type; ?></td></tr>
	    <tr><td>Loan Interest</td><td><?php echo $loan_interest; ?></td></tr>
	    <tr><td>Loan Interest Period</td><td><?php echo $loan_interest_period; ?></td></tr>
	    <tr><td>Loan Duration</td><td><?php echo $loan_duration; ?></td></tr>
	    <tr><td>Loan Duration Period</td><td><?php echo $loan_duration_period; ?></td></tr>
	    <tr><td>Loan Payment Scheme Id</td><td><?php echo $loan_payment_scheme_id; ?></td></tr>
	    <tr><td>Loan Num Of Repayments</td><td><?php echo $loan_num_of_repayments; ?></td></tr>
	    <tr><td>Loan Decimal Places</td><td><?php echo $loan_decimal_places; ?></td></tr>
	    <tr><td>Loan Interest Start Date</td><td><?php echo $loan_interest_start_date; ?></td></tr>
	    <tr><td>Loan First Repayment Date</td><td><?php echo $loan_first_repayment_date; ?></td></tr>
	    <tr><td>First Repayment Amount</td><td><?php echo $first_repayment_amount; ?></td></tr>
	    <tr><td>Last Repayment Amount</td><td><?php echo $last_repayment_amount; ?></td></tr>
	    <tr><td>Loan Override Maturity Date</td><td><?php echo $loan_override_maturity_date; ?></td></tr>
	    <tr><td>Override Each Repayment Amount</td><td><?php echo $override_each_repayment_amount; ?></td></tr>
	    <tr><td>Loan Interest Schedule</td><td><?php echo $loan_interest_schedule; ?></td></tr>
	    <tr><td>Gaurantor Id</td><td><?php echo $gaurantor_id; ?></td></tr>
	    <tr><td>Gaurantor Id2</td><td><?php echo $gaurantor_id2; ?></td></tr>
	    <tr><td>Loan Description</td><td><?php echo $loan_description; ?></td></tr>
	    <tr><td>Loan Files</td><td><?php echo $loan_files; ?></td></tr>
	    <tr><td>Loan Status Id</td><td><?php echo $loan_status_id; ?></td></tr>
	  
	  
	    <tr><td></td><td><a href="<?php echo site_url('loan') ?>" class="btn btn-default">Back

</a></td></tr>
	</table>
        </body>
</html>