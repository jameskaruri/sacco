<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Staff <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Surname <?php echo form_error('surname') ?></label>
            <input type="text" class="form-control" name="surname" id="surname" placeholder="Surname" value="<?php echo $surname; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Fname <?php echo form_error('Fname') ?></label>
            <input type="text" class="form-control" name="Fname" id="Fname" placeholder="Fname" value="<?php echo $Fname; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Lname <?php echo form_error('Lname') ?></label>
            <input type="text" class="form-control" name="Lname" id="Lname" placeholder="Lname" value="<?php echo $Lname; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Email <?php echo form_error('email') ?></label>
            <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Employee Number <?php echo form_error('Employee_number') ?></label>
            <input type="text" class="form-control" name="Employee_number" id="Employee_number" placeholder="Employee Number" value="<?php echo $Employee_number; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Idno <?php echo form_error('Idno') ?></label>
            <input type="text" class="form-control" name="Idno" id="Idno" placeholder="Idno" value="<?php echo $Idno; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Job <?php echo form_error('job') ?></label>
            <input type="text" class="form-control" name="job" id="job" placeholder="Job" value="<?php echo $job; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="staff_id" value="<?php echo $staff_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('staff') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>