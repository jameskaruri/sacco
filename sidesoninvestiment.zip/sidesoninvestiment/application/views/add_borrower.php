<!doctype html>
<html>
    <head>
       <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Borrower<small><a href="" target="_blank">Help</a></small></h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="box box-info">
<script type="text/javascript">
        $(document).ready(function() {
          if (window.FormData) {
              $('#data_files').bind({
                  change : function()
                  {
                      var input = document.getElementById('data_files');
                      files = input.files;

                      if (files.length > 20) {
                          alert('You can only upload max of 20 files');
                          $('#data_files').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(application/pdf|application/acrobat|applications/vnd.pdf|text/pdf|text/x-pdf|application/msword|application/x-msword|application/vnd.openxmlformats-officedocument.wordprocessingml.document|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet|text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/zip|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt|image/png|image/jpeg|image/gif|application/zip|application/x-zip|application/octet-stream|application/x-zip-compressed)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload text, word, pdf, image, zip, csv, or excel files.",
                                          type: "red"
                                        });
                                      $('#data_files').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });

                                  $('#data_files').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
              $('#photo_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('photo_file');
                      files = input.files;

                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#photo_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(image/png|image/jpeg|image/gif)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload png, jpeg, or gif files.",
                                          type: "red"
                                        });
                                      $('#photo_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#photo_file').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
              $('#csv_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('csv_file');
                      files = input.files;

                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#csv_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var matcher = regExp.test(file.type);
                              if (file.type != '')
                              {
                                  var filesize = file.size;
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload csv file.",
                                          type: "red"
                                        });
                                      $('#csv_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#csv_file').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
          }
        });
        </script>
    <body>
      <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
        
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold" >Personal details:</div></div>
        <form action="<?php echo anchor(site_url('borrowers/create')); ?>" method="post" id="borrower_form">
            <table class="table table-bordered table-condensed table-hover" style="width: 100%">
                <tr><td>
      <div class="form-group">
            <label for="varchar">Surname <?php echo form_error('borrower_surname') ?></label>
            <input type="text" class="form-control" name="borrower_surname" id="borrower_surname" placeholder=" Surname" value="<?php echo $borrower_surname; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Firstname <?php echo form_error('borrower_firstname') ?></label>
            <input type="text" class="form-control" name="borrower_firstname" id="borrower_firstname" placeholder=" Firstname" value="<?php echo $borrower_firstname; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Lastname <?php echo form_error('borrower_lastname') ?></label>
            <input type="text" class="form-control" name="borrower_lastname" id="borrower_lastname" placeholder=" Lastname" value="<?php echo $borrower_lastname; ?>" />
        </div></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Id Number <?php echo form_error('borrower_id_number') ?></label>
            <input type="text" class="form-control" name="borrower_id_number" id="borrower_id_number" placeholder=" Id Number" value="<?php echo $borrower_id_number; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Email <?php echo form_error('borrower_email') ?></label>
            <input type="text" class="form-control" name="borrower_email" id="borrower_email" placeholder=" Email" value="<?php echo $borrower_email; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Mobile <?php echo form_error('borrower_mobile') ?></label>
            <input type="text" class="form-control" name="borrower_mobile" id="borrower_mobile" placeholder=" Mobile" value="<?php echo $borrower_mobile; ?>" />
        </div></td></tr><tr><td>
             <div class="form-group">
            <label for="varchar">Gender <?php echo form_error('borrower_gender') ?></label>
            <select class="form-control" name="borrower_gender" id="borrower_gender" value="<?php echo $borrower_gender; ?>">
                            <option value=""></option>
                            <option value="Male" />Male</option>
                            <option  value="Female" />Female</option>
                        </select>
      
        </div></td><td>
     <label for="varchar">Title <?php echo form_error('borrower_title') ?></label>
       <select class="form-control" name="borrower_title" id="borrower_title">
                            <option value="" ></option>
                            <option value="Mr" >Mr. </option>
                            <option value="Mrs" >Mrs. </option>
                            <option value="Miss" >Miss </option>

                        </select>
        </div></td>
          <script>
        $(function() {
            $('#borrower_dob').datepick({
            maxDate: '',
            defaultDate: '', showTrigger: '#calImg',
            yearRange: 'c-80:c+20', showTrigger: '#calImg',

            dateFormat: 'dd/mm/yyyy',
            minDate: '01/01/1920'
            });
        });

        </script><td>
      <div class="form-group">
            <label for="varchar">Date Of Birth <?php echo form_error('borrower_dob') ?></label>
            <input type="text" class="form-control" name="borrower_dob" id="borrower_dob" placeholder=" Dob" value="<?php echo $borrower_dob; ?>" />
        </div></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Address <?php echo form_error('borrower_address') ?></label>
            <input type="text" class="form-control" name="borrower_address" id="borrower_address" placeholder=" Address" value="<?php echo $borrower_address; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Zipcode <?php echo form_error('borrower_zipcode') ?></label>
            <input type="text" class="form-control" name="borrower_zipcode" id="borrower_zipcode" placeholder=" Zipcode" value="<?php echo $borrower_zipcode; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Town <?php echo form_error('borrower_town') ?></label>
            <input type="text" class="form-control" name="borrower_town" id="borrower_town" placeholder=" Town" value="<?php echo $borrower_town; ?>" />
        </div></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Street <?php echo form_error('borrower_street') ?></label>
            <input type="text" class="form-control" name="borrower_street" id="borrower_street" placeholder=" Street" value="<?php echo $borrower_street; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Estate <?php echo form_error('borrower_estate') ?></label>
            <input type="text" class="form-control" name="borrower_estate" id="borrower_estate" placeholder=" Estate" value="<?php echo $borrower_estate; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Nearestcommonfeature <?php echo form_error('borrower_nearestcommonfeature') ?></label>
            <input type="text" class="form-control" name="borrower_nearestcommonfeature" id="borrower_nearestcommonfeature" placeholder=" Nearestcommonfeature" value="<?php echo $borrower_nearestcommonfeature; ?>" />
        </div></td><td></td><tr><td>
      <div class="form-group">
            <label for="longblob">Borrower Picture <?php echo form_error('borrower_picture') ?></label>
            <input type="file" id="borrower_picture" name="borrower_picture" value="<?php echo $borrower_picture; ?>"/>
           
        </div>
      <div class="form-group">
            <label for="varchar">Description <?php echo form_error('borrower_description') ?></label>
            <textarea type="text" class="form-control" name="borrower_description" id="borrower_description" placeholder=" Description" value="<?php echo $borrower_description; ?>" /></textarea>
        </div>
      <div class="form-group">
            <label for="blob">Borrower Id <?php echo form_error('borrower_id') ?></label>
            <input type="file" id="data_files" name="borrower_id" id="borrower_id" value="<?php echo $borrower_id; ?>"/>
            
        </div></td></tr></tr></table>
        <table class="table table-bordered table-condensed table-hover" style="width: 100%">
            <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Business details:</div></div>

        <tr>
         
            <td>
      <div class="form-group">
            <label for="varchar">Business Name <?php echo form_error('borrower_business_name') ?></label>
            <input type="text" class="form-control" name="borrower_business_name" id="borrower_business_name" placeholder=" Business Name" value="<?php echo $borrower_business_name; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Business Nature <?php echo form_error('borrower_business_nature') ?></label>
            <input type="text" class="form-control" name="borrower_business_nature" id="borrower_business_nature" placeholder=" Business Nature" value="<?php echo $borrower_business_nature; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Business Duration <?php echo form_error('borrower_business_Duration') ?></label>
            <input type="text" class="form-control" name="borrower_business_Duration" id="borrower_business_Duration" placeholder=" Business Duration" value="<?php echo $borrower_business_Duration; ?>" />
        </div></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Business Owner <?php echo form_error('Business_owner') ?></label>
            <input type="text" class="form-control" name="Business_owner" id="Business_owner" placeholder="Business Owner" value="<?php echo $Business_owner; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Address1 <?php echo form_error('address1') ?></label>
            <input type="text" class="form-control" name="address1" id="address1" placeholder="Address1" value="<?php echo $address1; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Zipcode1 <?php echo form_error('zipcode1') ?></label>
            <input type="text" class="form-control" name="zipcode1" id="zipcode1" placeholder="Zipcode1" value="<?php echo $zipcode1; ?>" />
        </div></td></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Town1 <?php echo form_error('town1') ?></label>
            <input type="text" class="form-control" name="town1" id="town1" placeholder="Town1" value="<?php echo $town1; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Street1 <?php echo form_error('street1') ?></label>
            <input type="text" class="form-control" name="street1" id="street1" placeholder="Street1" value="<?php echo $street1; ?>" />
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Estate1 <?php echo form_error('estate1') ?></label>
            <input type="text" class="form-control" name="estate1" id="estate1" placeholder="Estate1" value="<?php echo $estate1; ?>" />
        </div></td></tr><tr><td>
      <div class="form-group">
            <label for="varchar">Nearestcommonfeature1 <?php echo form_error('nearestcommonfeature1') ?></label>
            <input type="text" class="form-control" name="nearestcommonfeature1" id="nearestcommonfeature1" placeholder="Nearestcommonfeature1" value="<?php echo $nearestcommonfeature1; ?>" />
        </div></td><td></tr></table >
            <table class="table table-bordered table-condensed table-hover" style="width: 100%">
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Direction:</div>
      <tr><td>
        <div class="form-group">
            <label for="varchar">Business Location <?php echo form_error('business_location') ?></label>
            <textarea type="text" class="form-control" name="business_location" id="business_location" placeholder="Business Location" value="<?php echo $business_location; ?>" /></textarea>
        </div></td><td>
      <div class="form-group">
            <label for="varchar">Residence Location <?php echo form_error('residence_location') ?></label>
            <textarea type="text" class="form-control" name="residence_location" id="residence_location" placeholder="Residence Location" value="<?php echo $residence_location; ?>" /></textarea>
        </div></td></tr>
      <div class="form-group">
          
            <input type="hidden" class="form-control" name="borrower_access_ids" id="borrower_access_ids" placeholder=" Access Ids" value="<?php echo $borrower_access_ids; ?>" />
        </div>
      
        </div>
      <input type="hidden" name="borrowers_id" value="<?php echo $borrowers_id; ?>" /> 
        
      <tr><td><a href="<?php echo site_url('borrowers') ?>" class="btn btn-default">Back</a></td>
<td>
        <button type="submit" class="btn btn-info pull-right align" > Submit </button> </td></tr>

    <script type="text/javascript">
    $('#borrower_form').on('submit', function(e) {
 
                            }


        $(this).find('button[type=submit]').prop('disabled', true);
        $('.btn').prop('disabled', true);
        $('.btn').button('loading');
        return true;
    });
    </script>
  </form>
</table>
    </body>
    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                    <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>

</html>