<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Expenses extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Expenses_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('expenses/expenses_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Expenses_model->json();
    }

    public function read($id) 
    {
        $row = $this->Expenses_model->get_by_id($id);
        if ($row) {
            $data = array(
		'expensis_id' => $row->expensis_id,
		'Expense_Type' => $row->Expense_Type,
		'Expense_Amount' => $row->Expense_Amount,
		'Expense_Date' => $row->Expense_Date,
		'Recurring' => $row->Recurring,
		'Recurring_Expense' => $row->Recurring_Expense,
		'Description' => $row->Description,
		'Receipt' => $row->Receipt,
		'time_date' => $row->time_date,
	    );
            $this->load->view('expenses/expenses_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('expenses'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('expenses/create_action'),
	    'expensis_id' => set_value('expensis_id'),
	    'Expense_Type' => set_value('Expense_Type'),
	    'Expense_Amount' => set_value('Expense_Amount'),
	    'Expense_Date' => set_value('Expense_Date'),
	    'Recurring' => set_value('Recurring'),
	    'Recurring_Expense' => set_value('Recurring_Expense'),
	    'Description' => set_value('Description'),
	    'Receipt' => set_value('Receipt'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('expenses/expenses_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Expense_Type' => $this->input->post('Expense_Type',TRUE),
		'Expense_Amount' => $this->input->post('Expense_Amount',TRUE),
		'Expense_Date' => $this->input->post('Expense_Date',TRUE),
		'Recurring' => $this->input->post('Recurring',TRUE),
		'Recurring_Expense' => $this->input->post('Recurring_Expense',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Receipt' => $this->input->post('Receipt',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Expenses_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('expenses'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Expenses_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('expenses/update_action'),
		'expensis_id' => set_value('expensis_id', $row->expensis_id),
		'Expense_Type' => set_value('Expense_Type', $row->Expense_Type),
		'Expense_Amount' => set_value('Expense_Amount', $row->Expense_Amount),
		'Expense_Date' => set_value('Expense_Date', $row->Expense_Date),
		'Recurring' => set_value('Recurring', $row->Recurring),
		'Recurring_Expense' => set_value('Recurring_Expense', $row->Recurring_Expense),
		'Description' => set_value('Description', $row->Description),
		'Receipt' => set_value('Receipt', $row->Receipt),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('expenses/expenses_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('expenses'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('expensis_id', TRUE));
        } else {
            $data = array(
		'Expense_Type' => $this->input->post('Expense_Type',TRUE),
		'Expense_Amount' => $this->input->post('Expense_Amount',TRUE),
		'Expense_Date' => $this->input->post('Expense_Date',TRUE),
		'Recurring' => $this->input->post('Recurring',TRUE),
		'Recurring_Expense' => $this->input->post('Recurring_Expense',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Receipt' => $this->input->post('Receipt',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Expenses_model->update($this->input->post('expensis_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('expenses'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Expenses_model->get_by_id($id);

        if ($row) {
            $this->Expenses_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('expenses'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('expenses'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Expense_Type', 'expense type', 'trim|required');
	$this->form_validation->set_rules('Expense_Amount', 'expense amount', 'trim|required');
	$this->form_validation->set_rules('Expense_Date', 'expense date', 'trim|required');
	$this->form_validation->set_rules('Recurring', 'recurring', 'trim|required');
	$this->form_validation->set_rules('Recurring_Expense', 'recurring expense', 'trim|required');
	$this->form_validation->set_rules('Description', 'description', 'trim|required');
	$this->form_validation->set_rules('Receipt', 'receipt', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('expensis_id', 'expensis_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Expenses.php */
/* Location: ./application/controllers/Expenses.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */