<?php
/**
* 
*/
class Dropdown extends CI_model
{
	
	
	public function getborrower(){
     $query= $this->db->get('borrowers');
     if ($query->num_rows()>0) {
     	return $query->result();
     	
     } 
     

	}
}
  ?>