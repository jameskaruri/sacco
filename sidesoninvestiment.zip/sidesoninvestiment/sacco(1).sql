-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2018 at 05:23 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sacco`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowers`
--

CREATE TABLE IF NOT EXISTS `borrowers` (
  `borrowers_id` int(10) unsigned NOT NULL,
  `borrower_surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_id_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_dob` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_zipcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_town` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_estate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_nearestcommonfeature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_business_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_business_nature` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_business_Duration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Business_owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `town1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estate1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nearestcommonfeature1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `residence_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrower_access_ids` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `borrowers`
--

INSERT INTO `borrowers` (`borrowers_id`, `borrower_surname`, `borrower_firstname`, `borrower_lastname`, `borrower_id_number`, `borrower_email`, `borrower_mobile`, `borrower_gender`, `borrower_title`, `borrower_dob`, `borrower_address`, `borrower_zipcode`, `borrower_town`, `borrower_street`, `borrower_estate`, `borrower_nearestcommonfeature`, `borrower_picture`, `borrower_description`, `borrower_id`, `borrower_business_name`, `borrower_business_nature`, `borrower_business_Duration`, `Business_owner`, `address1`, `zipcode1`, `town1`, `street1`, `estate1`, `nearestcommonfeature1`, `business_location`, `residence_location`, `borrower_access_ids`, `created_at`, `updated_at`) VALUES
(1, 'Njuguna', 'gladys', 'Njeri', '11545569', 'N/A', '0701593700', 'Female', 'Mrs', '19/05/1970', 'n/a', 'N/A', 'Naivasha', 'kenyatta avenue', 'kabati', 'booster', '', 'N/A', '', 'mutumba', 'N/A', '7  years', 'sole', 'N/A', '20117', 'Naivasha', 'Mbari ya Kaniu', 'soko', 'Friends house', 'N/A', 'N/A', '', NULL, NULL),
(2, 'kka', 'eee', 'qqqqqqqqqqqw', '115455695', 'w', '1111111111111111', 'Male', 'Mr', '01/01/1999', 'f', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '', 'N/A', '', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `borrowers_group`
--

CREATE TABLE IF NOT EXISTS `borrowers_group` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrowers_id` int(10) unsigned NOT NULL,
  `group_collector_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_meeting_schedule` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `borrowers_group`
--

INSERT INTO `borrowers_group` (`group_id`, `group_name`, `borrowers_id`, `group_collector_name`, `group_meeting_schedule`, `group_description`, `token`, `created_at`, `updated_at`) VALUES
(1, 'jib', 1, '1111', '5', '5', '', NULL, NULL),
(2, 'kak', 2, '', '11', '2', '', NULL, NULL),
(3, '22', 1, '2', '2', '2', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cash`
--

CREATE TABLE IF NOT EXISTS `cash` (
  `cash_id` int(11) NOT NULL,
  `Apr` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `May` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `June` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `July` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Aug` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sep` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cashflow`
--

CREATE TABLE IF NOT EXISTS `cashflow` (
  `cash_flow_id` int(11) NOT NULL,
  `deposit` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `withdrawal` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `other_income` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_released` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `principal_repayment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `penalty_repayment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `interest_repayment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee_repayment` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expences` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deductable_loan_fee` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_capital` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `colletral`
--

CREATE TABLE IF NOT EXISTS `colletral` (
  `colletral_id` int(11) NOT NULL,
  `borrowers_id` int(11) NOT NULL,
  `type` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productname` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `register` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colletralstatus` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colletralstatus date` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serialno` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelname` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datemanufacured` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `colletracondition` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` blob NOT NULL,
  `file` blob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `expensis_id` int(11) NOT NULL,
  `Expense_Type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Expense_Amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Expense_Date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recurring` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recurring_Expense` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Receipt` blob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gaurantors`
--

CREATE TABLE IF NOT EXISTS `gaurantors` (
  `gaurantor_id` int(11) NOT NULL,
  `fname` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idno` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `busness_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipcode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `town` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `imaetmp` blob NOT NULL,
  `description` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gaurantors`
--

INSERT INTO `gaurantors` (`gaurantor_id`, `fname`, `lname`, `idno`, `busness_name`, `email`, `title`, `phone`, `gender`, `dob`, `address`, `zipcode`, `town`, `working_status`, `imaetmp`, `description`, `created_at`, `updated_at`) VALUES
(1, 'john', 'maina', '1122', '111', 'N/A', 'Mr', '111111111', 'Male', '0000-00-00', '1111', '11', '11', '1111', 0x54756c6970732e6a7067, 'ttt', NULL, NULL),
(2, 'john', 'maina', '4232', 'nn', 'N/A', 'Mr', '22222', 'Male', '0000-00-00', '22', '22', '22', '2', 0x50656e6775696e732e6a7067, 'nnn', NULL, NULL),
(3, 'florence', 'maina', '542', '111', '111', 'Mi', '111111111', 'Female', '08/01/1999', '1111', '111', '111', '1111', 0x4a656c6c79666973682e6a7067, '111', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `job_id` int(11) NOT NULL,
  `job_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `loan_id` int(11) NOT NULL,
  `borrowers_id` int(10) unsigned NOT NULL,
  `Loan_product_id` int(11) NOT NULL,
  `loan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_disbursed_by_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_principal_amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_released_date` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest_method` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest_period` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_duration` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_duration_period` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_payment_scheme_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_num_of_repayments` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_decimal_places` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest_start_date` date NOT NULL,
  `loan_first_repayment_date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_repayment_amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_repayment_amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_override_maturity_date` date NOT NULL,
  `override_each_repayment_amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_interest_schedule` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gaurantor_id` int(10) unsigned NOT NULL,
  `gaurantor_id2` int(10) unsigned NOT NULL,
  `loan_description` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_files` varchar(5000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `loan_status_id` int(11) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `borrowers_id`, `Loan_product_id`, `loan`, `loan_disbursed_by_id`, `loan_principal_amount`, `loan_released_date`, `loan_interest_method`, `loan_interest_type`, `loan_interest`, `loan_interest_period`, `loan_duration`, `loan_duration_period`, `loan_payment_scheme_id`, `loan_num_of_repayments`, `loan_decimal_places`, `loan_interest_start_date`, `loan_first_repayment_date`, `first_repayment_amount`, `last_repayment_amount`, `loan_override_maturity_date`, `override_each_repayment_amount`, `loan_interest_schedule`, `gaurantor_id`, `gaurantor_id2`, `loan_description`, `loan_files`, `loan_status_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '1', 'cash', '322', '29/04/2018', 'flat_rate', 'percentage', '14', 'Day', '1', 'Days', '12', '1', 'round_off_to_two_decimal', '0000-00-00', '', '', '', '0000-00-00', '', 'charge_interest_normally', 2, 0, '11', '', 0, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `loanproduct`
--

CREATE TABLE IF NOT EXISTS `loanproduct` (
  `Loan_prduct_id` int(11) NOT NULL,
  `Loan_prduct_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loanproduct`
--

INSERT INTO `loanproduct` (`Loan_prduct_id`, `Loan_prduct_name`) VALUES
(1, 'Wezesha loan');

-- --------------------------------------------------------

--
-- Table structure for table `loanstatus`
--

CREATE TABLE IF NOT EXISTS `loanstatus` (
  `loan_status_id` int(11) NOT NULL,
  `loan_status` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_04_11_165847_create_Loanstatus_table', 1),
(4, '2018_04_11_165847_create_borrowers_group_table', 1),
(5, '2018_04_11_165847_create_borrowers_table', 1),
(6, '2018_04_11_165847_create_cash_table', 1),
(7, '2018_04_11_165847_create_cashflow_table', 1),
(8, '2018_04_11_165847_create_ci_sessions_table', 1),
(9, '2018_04_11_165847_create_colletral_table', 1),
(10, '2018_04_11_165847_create_expenses_table', 1),
(11, '2018_04_11_165847_create_gaurantors_table', 1),
(12, '2018_04_11_165847_create_job_table', 1),
(13, '2018_04_11_165847_create_loanProduct_table', 1),
(14, '2018_04_11_165847_create_loan_table', 1),
(15, '2018_04_11_165847_create_other_income_table', 1),
(16, '2018_04_11_165847_create_payment_methond_table', 1),
(17, '2018_04_11_165847_create_payroll_table', 1),
(18, '2018_04_11_165847_create_repayments_table', 1),
(19, '2018_04_11_165847_create_role_table', 1),
(20, '2018_04_11_165847_create_saving_transactions_table', 1),
(21, '2018_04_11_165847_create_savingproduct_table', 1),
(22, '2018_04_11_165847_create_savings_table', 1),
(23, '2018_04_11_165847_create_sites_table', 1),
(24, '2018_04_11_165847_create_staff_table', 1),
(25, '2018_04_11_165853_add_foreign_keys_to_borrowers_group_table', 1),
(26, '2018_04_11_165853_add_foreign_keys_to_payroll_table', 1),
(27, '2018_04_11_165853_add_foreign_keys_to_repayments_table', 1),
(28, '2018_04_11_165853_add_foreign_keys_to_saving_transactions_table', 1),
(29, '2018_04_11_165853_add_foreign_keys_to_savings_table', 1),
(30, '2018_04_11_165853_add_foreign_keys_to_staff_table', 1),
(31, '2018_04_11_165853_add_foreign_keys_to_users_table', 1),
(32, '2018_04_11_172708_refresh', 1),
(33, '2018_04_11_173853_borrowers', 1);

-- --------------------------------------------------------

--
-- Table structure for table `other_income`
--

CREATE TABLE IF NOT EXISTS `other_income` (
  `income_id` int(11) NOT NULL,
  `Type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Transaction_Date` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recurring` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Recurring_Other_Income` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Receipt` blob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methond`
--

CREATE TABLE IF NOT EXISTS `payment_methond` (
  `payment_methond_id` int(11) NOT NULL,
  `payment_methond` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

CREATE TABLE IF NOT EXISTS `payroll` (
  `payroll_id` int(11) NOT NULL,
  `Employee_name` int(11) NOT NULL,
  `Payroll_Date` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Business_Name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Basic_Pay` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Overtime` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Paid_Leaves` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Transport_Allowance` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Medical_Allowance` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Bonus` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Other_Allowance` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Health_Insurance` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Unpaid_Leave` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Tax_Deduction` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Salary_Loan` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Total_Pay` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Total_Deductions` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Net_Pay` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Payment_Method` int(11) NOT NULL,
  `Bank_Name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Account_Number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Paid_Amount` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Comments` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `repayments`
--

CREATE TABLE IF NOT EXISTS `repayments` (
  `repayment_id` int(11) NOT NULL,
  `borrowers_id` int(10) unsigned NOT NULL,
  `amout` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collected_by` int(11) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `role`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `savingproduct`
--

CREATE TABLE IF NOT EXISTS `savingproduct` (
  `savingproduct_id` int(11) NOT NULL,
  `savingproduct` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `savingproduct`
--

INSERT INTO `savingproduct` (`savingproduct_id`, `savingproduct`) VALUES
(1, 'school fees');

-- --------------------------------------------------------

--
-- Table structure for table `savings`
--

CREATE TABLE IF NOT EXISTS `savings` (
  `saving_id` int(11) NOT NULL,
  `borrowers_id` int(10) unsigned NOT NULL,
  `savings_product` int(11) NOT NULL,
  `account_no` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_transaction` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `savings`
--

INSERT INTO `savings` (`saving_id`, `borrowers_id`, `savings_product`, `account_no`, `description`, `last_transaction`, `created_at`, `updated_at`) VALUES
(1, 0, 1, '20000', 'wwwww', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `saving_transactions`
--

CREATE TABLE IF NOT EXISTS `saving_transactions` (
  `savingst_id` int(11) NOT NULL,
  `name` int(10) unsigned NOT NULL,
  `amount` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `saving_type` int(11) NOT NULL,
  `description` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sites`
--

CREATE TABLE IF NOT EXISTS `sites` (
  `id` int(11) NOT NULL,
  `first_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) NOT NULL,
  `site` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idn` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL,
  `surname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Fname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Lname` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Employee_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Idno` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `surname`, `Fname`, `Lname`, `email`, `password`, `Employee_number`, `Idno`, `job`, `created_at`, `updated_at`) VALUES
(0, 'james', 'karuri', 'james', 'Jamderitu@gmail.com', '12345', '11', '2345', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employeeno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `staff_id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowers`
--
ALTER TABLE `borrowers`
  ADD PRIMARY KEY (`borrowers_id`);

--
-- Indexes for table `borrowers_group`
--
ALTER TABLE `borrowers_group`
  ADD PRIMARY KEY (`group_id`), ADD KEY `borrowers_id_2` (`borrowers_id`);

--
-- Indexes for table `cash`
--
ALTER TABLE `cash`
  ADD PRIMARY KEY (`cash_id`);

--
-- Indexes for table `cashflow`
--
ALTER TABLE `cashflow`
  ADD PRIMARY KEY (`cash_flow_id`);

--
-- Indexes for table `colletral`
--
ALTER TABLE `colletral`
  ADD PRIMARY KEY (`colletral_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expensis_id`);

--
-- Indexes for table `gaurantors`
--
ALTER TABLE `gaurantors`
  ADD PRIMARY KEY (`gaurantor_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`), ADD KEY `borrowers_id` (`borrowers_id`), ADD KEY `Loan_product` (`Loan_product_id`), ADD KEY `gaurantor_id` (`gaurantor_id`), ADD KEY `gaurantor_id2` (`gaurantor_id2`), ADD KEY `loan_status_id` (`loan_status_id`), ADD KEY `user_id` (`user_id`), ADD KEY `Loan_product_id` (`Loan_product_id`);

--
-- Indexes for table `loanproduct`
--
ALTER TABLE `loanproduct`
  ADD PRIMARY KEY (`Loan_prduct_id`);

--
-- Indexes for table `loanstatus`
--
ALTER TABLE `loanstatus`
  ADD PRIMARY KEY (`loan_status_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `other_income`
--
ALTER TABLE `other_income`
  ADD PRIMARY KEY (`income_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`(191));

--
-- Indexes for table `payment_methond`
--
ALTER TABLE `payment_methond`
  ADD PRIMARY KEY (`payment_methond_id`);

--
-- Indexes for table `payroll`
--
ALTER TABLE `payroll`
  ADD PRIMARY KEY (`payroll_id`), ADD KEY `Employee_name` (`Employee_name`), ADD KEY `Payment_Method` (`Payment_Method`);

--
-- Indexes for table `repayments`
--
ALTER TABLE `repayments`
  ADD PRIMARY KEY (`repayment_id`), ADD KEY `borrowers_id` (`borrowers_id`), ADD KEY `collected_by` (`collected_by`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `savingproduct`
--
ALTER TABLE `savingproduct`
  ADD PRIMARY KEY (`savingproduct_id`);

--
-- Indexes for table `savings`
--
ALTER TABLE `savings`
  ADD PRIMARY KEY (`saving_id`), ADD KEY `borrowers_id` (`borrowers_id`), ADD KEY `savings_product` (`savings_product`);

--
-- Indexes for table `saving_transactions`
--
ALTER TABLE `saving_transactions`
  ADD PRIMARY KEY (`savingst_id`), ADD KEY `name` (`name`), ADD KEY `saving_type` (`saving_type`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`), ADD KEY `job` (`job`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowers`
--
ALTER TABLE `borrowers`
  MODIFY `borrowers_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `borrowers_group`
--
ALTER TABLE `borrowers_group`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `colletral`
--
ALTER TABLE `colletral`
  MODIFY `colletral_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expensis_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gaurantors`
--
ALTER TABLE `gaurantors`
  MODIFY `gaurantor_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `loanproduct`
--
ALTER TABLE `loanproduct`
  MODIFY `Loan_prduct_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `loanstatus`
--
ALTER TABLE `loanstatus`
  MODIFY `loan_status_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `other_income`
--
ALTER TABLE `other_income`
  MODIFY `income_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment_methond`
--
ALTER TABLE `payment_methond`
  MODIFY `payment_methond_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payroll`
--
ALTER TABLE `payroll`
  MODIFY `payroll_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `repayments`
--
ALTER TABLE `repayments`
  MODIFY `repayment_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `savingproduct`
--
ALTER TABLE `savingproduct`
  MODIFY `savingproduct_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `savings`
--
ALTER TABLE `savings`
  MODIFY `saving_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `saving_transactions`
--
ALTER TABLE `saving_transactions`
  MODIFY `savingst_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sites`
--
ALTER TABLE `sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `loan`
--
ALTER TABLE `loan`
ADD CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`Loan_product_id`) REFERENCES `loanproduct` (`Loan_prduct_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
