<!DOCTYPE html>

<html>
  <head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login - Sideson Investiments
    </title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="shortcut icon"  href="<?php echo base_url()."assets/";?>b.png" type="image/x-icon"  />
    <link rel="stylesheet" href="<?php echo base_url()."assets/";?>bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo base_url()?>/https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo base_url()?>/https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url()."assets/";?>AdminLTE.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo base_url()."assets/";?>blue.css">
    <script type="text/javascript" src="<?php echo base_url()."assets/";?>jstz.min.js"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo base_url()."assets/";?>DataTables/jQuery-3.2.1/jquery-3.2.1.min.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
        <script src="<?php echo base_url()."assets/";?>https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="<?php echo base_url()."assets/";?>https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
        .prompt {
          text-align: center;
          font-size: 0.9em;
        }
    
        #hint {
          color: #B94A48;
          display: none;
          font-size: 0.9em;
        }
    
        .domain {
          color: #08c;
          font-weight: bold;
          text-decoration: underline;
        }
        .loader,
        .loader:before,
        .loader:after {
          border-radius: 50%;
        }
        .loader {
          color: #ffffff;
          font-size: 11px;
          text-indent: -99999em;
          margin: 5px auto;
          position: relative;
          width: 5em;
          height: 5em;
          box-shadow: inset 0 0 0 1em;
          -webkit-transform: translateZ(0);
          -ms-transform: translateZ(0);
          transform: translateZ(0);
        }
        .loader:before,
        .loader:after {
          position: absolute;
          content: '';
        }
        .loader:before {
          width: 2.6em;
          height: 5.1em;
          background: #0dc5c1;
          border-radius: 5.1em 0 0 5.1em;
          top: -0.1em;
          left: -0.1em;
          -webkit-transform-origin: 2.6em 2.55em;
          transform-origin: 2.6em 2.55em;
          -webkit-animation: load2 2s infinite ease 1.5s;
          animation: load2 2s infinite ease 1.5s;
        }
        .loader:after {
          width: 2.6em;
          height: 5.1em;
          background: #0dc5c1;
          border-radius: 0 5.1em 5.1em 0;
          top: -0.1em;
          left: 2.55em;
          -webkit-transform-origin: 0px 2.55em;
          transform-origin: 0px 2.55em;
          -webkit-animation: load2 2s infinite ease;
          animation: load2 2s infinite ease;
        }
        
        @-webkit-keyframes load2 {
          0% {
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
          }
          100% {
            -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
          }
        }
        @keyframes load2 {
          0% {
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
          }
          100% {
            -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
          }
        }
    </style>
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
        <b>Submit Email</b>
      </div><!-- /.login-logo -->
      <div class="login-box-body">

        <p class="login-box-msg">submit email</p>
        <div class="alert-danger"><?php echo validation_errors();?></div>
        <?php echo form_open('LoginController/email_reset_form_validation');?>
       
        <input type="hidden" name="logging_in" value="1">
         <div class="form-group has-feedback">
            <input type="email" name="email" class="form-control" placeholder="email" required>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div>
            <div class="col-xs-6 ">
              <button type="submit" name="Login" class="btn btn-primary btn-block btn-flat" >submit</button>
            </div><!-- /.col -->
          </div>
        </form>
      </div><!-- /.login-box-body --> 
    </div>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url()."assets/";?>bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url()."assets/";?>icheck.min.js"></script>
    <script>
      $(function () {
        $("input").iCheck({
          checkboxClass: "icheckbox_square-blue",
          radioClass: "iradio_square-blue",
          increaseArea: "20%" // optional
        });
      });
    </script>
  </body>
</html>