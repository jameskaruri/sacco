<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Gaurantors Read</h2>
        <table class="table">
	    <tr><td>Fname</td><td><?php echo $fname; ?></td></tr>
	    <tr><td>Lname</td><td><?php echo $lname; ?></td></tr>
	    <tr><td>Idno</td><td><?php echo $idno; ?></td></tr>
	    <tr><td>Busness Name</td><td><?php echo $busness_name; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Title</td><td><?php echo $title; ?></td></tr>
	    <tr><td>Phone</td><td><?php echo $phone; ?></td></tr>
	    <tr><td>Gender</td><td><?php echo $gender; ?></td></tr>
	    <tr><td>Dob</td><td><?php echo $dob; ?></td></tr>
	    <tr><td>Address</td><td><?php echo $address; ?></td></tr>
	    <tr><td>Zipcode</td><td><?php echo $zipcode; ?></td></tr>
	    <tr><td>Town</td><td><?php echo $town; ?></td></tr>
	    <tr><td>Working Status</td><td><?php echo $working_status; ?></td></tr>
	    <tr><td>Imaetmp</td><td><?php echo $imaetmp; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $description; ?></td></tr>
	    <tr><td>Imagetmpo</td><td><?php echo $imagetmpo; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('gaurantors') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>