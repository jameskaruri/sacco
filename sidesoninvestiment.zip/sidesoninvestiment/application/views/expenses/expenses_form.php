<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Expenses <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Expense Type <?php echo form_error('Expense_Type') ?></label>
            <input type="text" class="form-control" name="Expense_Type" id="Expense_Type" placeholder="Expense Type" value="<?php echo $Expense_Type; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Expense Amount <?php echo form_error('Expense_Amount') ?></label>
            <input type="text" class="form-control" name="Expense_Amount" id="Expense_Amount" placeholder="Expense Amount" value="<?php echo $Expense_Amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Expense Date <?php echo form_error('Expense_Date') ?></label>
            <input type="text" class="form-control" name="Expense_Date" id="Expense_Date" placeholder="Expense Date" value="<?php echo $Expense_Date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Recurring <?php echo form_error('Recurring') ?></label>
            <input type="text" class="form-control" name="Recurring" id="Recurring" placeholder="Recurring" value="<?php echo $Recurring; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Recurring Expense <?php echo form_error('Recurring_Expense') ?></label>
            <input type="text" class="form-control" name="Recurring_Expense" id="Recurring_Expense" placeholder="Recurring Expense" value="<?php echo $Recurring_Expense; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('Description') ?></label>
            <input type="text" class="form-control" name="Description" id="Description" placeholder="Description" value="<?php echo $Description; ?>" />
        </div>
	    <div class="form-group">
            <label for="blob">Receipt <?php echo form_error('Receipt') ?></label>
            <input type="text" class="form-control" name="Receipt" id="Receipt" placeholder="Receipt" value="<?php echo $Receipt; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="expensis_id" value="<?php echo $expensis_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('expenses') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>