<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <link rel="stylesheet" href="<?php echo base_url('assets/datatables/dataTables.bootstrap.css') ?>"/>
        <link rel="stylesheet" href="<?php echo base_url('assets/datatables/dataTables.bootstrap.css') ?>"/>
        <style>
            .dataTables_wrapper {
                min-height: 500px
            }
            
            .dataTables_processing {
                position: absolute;
                top: 50%;
                left: 50%;
                width: 100%;
                margin-left: -50%;
                margin-top: -25px;
                padding-top: 20px;
                text-align: center;
                font-size: 1.2em;
                color:grey;
            }
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <h2 style="margin-top:0px">Payroll List</h2>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-4 text-right">
                <?php echo anchor(site_url('payroll/create'), 'Create', 'class="btn btn-primary"'); ?>
	    </div>
        </div>
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
		    <th>Employee Name</th>
		    <th>Payroll Date</th>
		    <th>Business Name</th>
		    <th>Basic Pay</th>
		    <th>Overtime</th>
		    <th>Paid Leaves</th>
		    <th>Transport Allowance</th>
		    <th>Medical Allowance</th>
		    <th>Bonus</th>
		    <th>Other Allowance</th>
		    <th>Pension</th>
		    <th>Health Insurance</th>
		    <th>Unpaid Leave</th>
		    <th>Tax Deduction</th>
		    <th>Salary Loan</th>
		    <th>Total Pay</th>
		    <th>Total Deductions</th>
		    <th>Net Pay</th>
		    <th>Payment Method</th>
		    <th>Bank Name</th>
		    <th>Account Number</th>
		    <th>Description</th>
		    <th>Paid Amount</th>
		    <th>Comments</th>
		    <th>Time Date</th>
		    <th width="200px">Action</th>
                </tr>
            </thead>
	    
        </table>
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "payroll/json", "type": "POST"},
                    columns: [
                        {
                            "data": "payroll_id",
                            "orderable": false
                        },{"data": "Employee_name"},{"data": "Payroll_Date"},{"data": "Business_Name"},{"data": "Basic_Pay"},{"data": "Overtime"},{"data": "Paid_Leaves"},{"data": "Transport_Allowance"},{"data": "Medical_Allowance"},{"data": "Bonus"},{"data": "Other_Allowance"},{"data": "Pension"},{"data": "Health_Insurance"},{"data": "Unpaid_Leave"},{"data": "Tax_Deduction"},{"data": "Salary_Loan"},{"data": "Total_Pay"},{"data": "Total_Deductions"},{"data": "Net_Pay"},{"data": "Payment_Method"},{"data": "Bank_Name"},{"data": "Account_Number"},{"data": "Description"},{"data": "Paid_Amount"},{"data": "Comments"},{"data": "time_date"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>
    </body>
</html>