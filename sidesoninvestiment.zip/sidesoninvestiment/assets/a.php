
<!DOCTYPE html>
<html>
<head>
    <title>ajax</title>

    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="shortcut icon" href="https://www.loandisk.com/favicon.ico" type="image/x-icon" />
        <!-- Bootstrap 3.3.5 -->
         <!-- Bootstrap 3.3.5 -->
      

        </script>   
        <script type="text/javascript" language="javascript" src="js/dataTables.editor.min.js">
        </script>  
          <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js">
        </script>
          <script type="text/javascript" language="javascript" src="js/dataTables.buttons.min.js">
        </script>
        <link rel="stylesheet" type="text/css" href="css/editor.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="css/buttons.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="css/select.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="css/editor.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="resources/syntax/shCore.css">
    <link rel="stylesheet" type="text/css" href="resources/demo.css">
    <style type="text/css" class="init">
    
    </style>  
        <script type="text/javascript" language="javascript" src="resources/syntax/shCore.js">
    </script>
    <script type="text/javascript" language="javascript" src="resources/demo.js">
    </script>
    <script type="text/javascript" language="javascript" src="js/dataTables.select.min.js">
    </script>
    <script type="text/javascript" language="javascript" src="js/dataTables.editor.min.js">
    </script>
    <script type="text/javascript" language="javascript" src="resources/editor-demo.js">
    </script>
     <script type="text/javascript" language="javascript" src="jquery-1.12.4.js">
    </script>
    <script type="text/javascript" language="javascript" class="init">
           var editor; // use a global for the submit and return data rendering in the examples
 
$(document).ready(function() {
    editor = new $.fn.dataTable.Editor( {
        ajax: "staff.php",
        table: "#example",
        fields: [ {
                label: "First name:",
                name: "first_name"
            }, {
                label: "Last name:",
                name: "last_name"
            }, {
                label: "Position:",
                name: "position"
            }, {
                label: "Office:",
                name: "office"
            }, {
                label: "Extension:",
                name: "extn"
            }, {
                label: "Start date:",
                name: "start_date",
                type: "datetime"
            }, {
                label: "Salary:",
                name: "salary"
            }
        ]
    } );
 
    $('#example').DataTable( {
        dom: "Bfrtip",
        ajax: "staff.php",
        columns: [
            { data: null, render: function ( data, type, row ) {
                // Combine the first and last names into a single table field
                return data.first_name+' '+data.last_name;
            } },
            { data: "position" },
            { data: "office" },
            { data: "extn" },
            { data: "start_date" },
            { data: "salary", render: $.fn.dataTable.render.number( ',', '.', 0, '$' ) }
        ],
        select: true,
        buttons: [
            { extend: "create", editor: editor },
            { extend: "edit",   editor: editor },
            { extend: "remove", editor: editor }
        ]
    } );
} );
    </script>
   <link rel="stylesheet" type="text/css" href="DataTables/datatables.css">

</head>
<body>
<table id="example" class="display" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Office</th>
            <th>Extn.</th>
            <th>Start date</th>
            <th>Salary</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Name</th>
            <th>Position</th>
            <th>Office</th>
            <th>Extn.</th>
            <th>Start date</th>
            <th>Salary</th>
        </tr>
    </tfoot>
</table>


</body>
</html>
