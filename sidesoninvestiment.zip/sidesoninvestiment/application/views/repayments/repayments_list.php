<!doctype html>
<html>
    <head>
       
        </style>
    </head>
    <body>
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="80px">No</th>
		    <th>Borrowers Id</th>
		    <th>Amout</th>
		    <th>Method</th>
		    
		    <th>Collected By</th>
		    <th>Description</th>
		    <th>Time Date</th>
		    <th width="200px">Action</th>
                </tr>
            </thead>
	    
        </table>
        </div></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                   "dom": '<"pull-left"f>r<"pull-right"l>tip',"order": [0, 'desc'],
                "autoWidth": true,
                "lengthMenu": [[10,20, 50, 100, 250, 500, 5000], [10,20, 50, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": true,
                "responsive": true,
                    ajax: {"url": "repayments/json", "type": "POST"},
                    columns: [
                        {
                            "data": "repayment_id",
                            "orderable": false
                        },{"data": "borrowers_id"},{"data": "amout"},{"data": "method"},{"data": "collected_by"},{"data": "description"},{"data": "time_date"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>
    </body>
</html>