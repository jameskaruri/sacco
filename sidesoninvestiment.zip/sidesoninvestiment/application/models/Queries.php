<?php
/**
* 
*/
class Queries extends CI_Model
{
	public function add_borrowers($data){
		$this->db->insert('borrowers',$data);

	}
		public function login($email, $password)
	{
	 $this->db->select('email','password','role');
	 $this->db->from('staff');
	 $this->db->where('email',$email);
	 $this->db->where('password', $password );
	 $query= $this->db->get();
	 if ($query->num_rows()==1) {
	 	return true;
	 }else
	 {
	 	return false;
	 }
	}
	function update_reset_key($reset_key){
		$email= $this->input->post('email');
		$this->db->from('staff');
	    $this->db->where('email',$email);
	    $data = array('password' => $reset_key );
	    $this->db->update('users',$data);

	    if ($this->db->affected_rows()>0) {
	       return true;	
	    } else {
	    	return false;
	    }
	    
	}
	
}

	
	
