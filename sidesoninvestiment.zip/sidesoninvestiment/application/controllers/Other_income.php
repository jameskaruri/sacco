<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Other_income extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Other_income_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('other_income/other_income_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Other_income_model->json();
    }

    public function read($id) 
    {
        $row = $this->Other_income_model->get_by_id($id);
        if ($row) {
            $data = array(
		'income_id' => $row->income_id,
		'Type' => $row->Type,
		'Amount' => $row->Amount,
		'Transaction_Date' => $row->Transaction_Date,
		'Recurring' => $row->Recurring,
		'Recurring_Other_Income' => $row->Recurring_Other_Income,
		'Description' => $row->Description,
		'Receipt' => $row->Receipt,
		'time_date' => $row->time_date,
	    );
            $this->load->view('other_income/other_income_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('other_income'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('other_income/create_action'),
	    'income_id' => set_value('income_id'),
	    'Type' => set_value('Type'),
	    'Amount' => set_value('Amount'),
	    'Transaction_Date' => set_value('Transaction_Date'),
	    'Recurring' => set_value('Recurring'),
	    'Recurring_Other_Income' => set_value('Recurring_Other_Income'),
	    'Description' => set_value('Description'),
	    'Receipt' => set_value('Receipt'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('other_income/other_income_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Type' => $this->input->post('Type',TRUE),
		'Amount' => $this->input->post('Amount',TRUE),
		'Transaction_Date' => $this->input->post('Transaction_Date',TRUE),
		'Recurring' => $this->input->post('Recurring',TRUE),
		'Recurring_Other_Income' => $this->input->post('Recurring_Other_Income',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Receipt' => $this->input->post('Receipt',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Other_income_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('other_income'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Other_income_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('other_income/update_action'),
		'income_id' => set_value('income_id', $row->income_id),
		'Type' => set_value('Type', $row->Type),
		'Amount' => set_value('Amount', $row->Amount),
		'Transaction_Date' => set_value('Transaction_Date', $row->Transaction_Date),
		'Recurring' => set_value('Recurring', $row->Recurring),
		'Recurring_Other_Income' => set_value('Recurring_Other_Income', $row->Recurring_Other_Income),
		'Description' => set_value('Description', $row->Description),
		'Receipt' => set_value('Receipt', $row->Receipt),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('other_income/other_income_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('other_income'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('income_id', TRUE));
        } else {
            $data = array(
		'Type' => $this->input->post('Type',TRUE),
		'Amount' => $this->input->post('Amount',TRUE),
		'Transaction_Date' => $this->input->post('Transaction_Date',TRUE),
		'Recurring' => $this->input->post('Recurring',TRUE),
		'Recurring_Other_Income' => $this->input->post('Recurring_Other_Income',TRUE),
		'Description' => $this->input->post('Description',TRUE),
		'Receipt' => $this->input->post('Receipt',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Other_income_model->update($this->input->post('income_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('other_income'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Other_income_model->get_by_id($id);

        if ($row) {
            $this->Other_income_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('other_income'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('other_income'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Type', 'type', 'trim|required');
	$this->form_validation->set_rules('Amount', 'amount', 'trim|required');
	$this->form_validation->set_rules('Transaction_Date', 'transaction date', 'trim|required');
	$this->form_validation->set_rules('Recurring', 'recurring', 'trim|required');
	$this->form_validation->set_rules('Recurring_Other_Income', 'recurring other income', 'trim|required');
	$this->form_validation->set_rules('Description', 'description', 'trim|required');
	$this->form_validation->set_rules('Receipt', 'receipt', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('income_id', 'income_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Other_income.php */
/* Location: ./application/controllers/Other_income.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */