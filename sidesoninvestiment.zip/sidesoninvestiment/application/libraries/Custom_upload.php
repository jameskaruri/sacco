<?php 

/**
* 
*/
class Custom_upload
{
	
	function __construct()
	{

		$this->CI=&get_instance();
		$this->CI->load->library('upload');
	}

	

	public function single_upload($field_name, $config = array()){
		$upload_path=FCPATH.$config['upload_path'];
		$config = array(
          'upload_path'=>$upload_path,
          'allowed_types'=> $conf['allowed_types'],
          'max_size'=>0,
          'enctype_name'=> true
		);
		$this->CI->upload->initialize($config);
		if ($this->CI->upload->do_upload($field_name)) {
			$data= $this->CI->upload->data();
			chmod($data['full_path'], 0777);

			return $data['field_name'];
		} else {
			
		}
		

	}
	

	public function multiple_upload(){
     
	}
}