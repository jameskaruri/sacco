<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Sites extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Sites_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('sites/sites_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Sites_model->json();
    }

    public function read($id) 
    {
        $row = $this->Sites_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id' => $row->id,
		'first_name' => $row->first_name,
		'last_name' => $row->last_name,
		'phone' => $row->phone,
		'site' => $row->site,
		'idn' => $row->idn,
		'name' => $row->name,
		'time_date' => $row->time_date,
	    );
            $this->load->view('sites/sites_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('sites'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('sites/create_action'),
	    'id' => set_value('id'),
	    'first_name' => set_value('first_name'),
	    'last_name' => set_value('last_name'),
	    'phone' => set_value('phone'),
	    'site' => set_value('site'),
	    'idn' => set_value('idn'),
	    'name' => set_value('name'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('sites/sites_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'first_name' => $this->input->post('first_name',TRUE),
		'last_name' => $this->input->post('last_name',TRUE),
		'phone' => $this->input->post('phone',TRUE),
		'site' => $this->input->post('site',TRUE),
		'idn' => $this->input->post('idn',TRUE),
		'name' => $this->input->post('name',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Sites_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('sites'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Sites_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('sites/update_action'),
		'id' => set_value('id', $row->id),
		'first_name' => set_value('first_name', $row->first_name),
		'last_name' => set_value('last_name', $row->last_name),
		'phone' => set_value('phone', $row->phone),
		'site' => set_value('site', $row->site),
		'idn' => set_value('idn', $row->idn),
		'name' => set_value('name', $row->name),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('sites/sites_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('sites'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id', TRUE));
        } else {
            $data = array(
		'first_name' => $this->input->post('first_name',TRUE),
		'last_name' => $this->input->post('last_name',TRUE),
		'phone' => $this->input->post('phone',TRUE),
		'site' => $this->input->post('site',TRUE),
		'idn' => $this->input->post('idn',TRUE),
		'name' => $this->input->post('name',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Sites_model->update($this->input->post('id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('sites'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Sites_model->get_by_id($id);

        if ($row) {
            $this->Sites_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('sites'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('sites'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('first_name', 'first name', 'trim|required');
	$this->form_validation->set_rules('last_name', 'last name', 'trim|required');
	$this->form_validation->set_rules('phone', 'phone', 'trim|required');
	$this->form_validation->set_rules('site', 'site', 'trim|required');
	$this->form_validation->set_rules('idn', 'idn', 'trim|required');
	$this->form_validation->set_rules('name', 'name', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('id', 'id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Sites.php */
/* Location: ./application/controllers/Sites.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */