<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Loan_model extends CI_Model
{

    public $table = 'loan';
    public $id = 'loan_id';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // datatables
    function json() {
        $this->datatables->select('loan_id,borrowers_id,Loan_product_id,loan,loan_disbursed_by_id,loan_principal_amount,loan_released_date,loan_interest_method,loan_interest_type,loan_interest,loan_interest_period,loan_duration,loan_duration_period,loan_payment_scheme_id,loan_num_of_repayments,loan_decimal_places,loan_interest_start_date,loan_first_repayment_date,first_repayment_amount,last_repayment_amount,loan_override_maturity_date,override_each_repayment_amount,loan_interest_schedule,gaurantor_id,gaurantor_id2,loan_description,loan_files,loan_status_id,user_id');
        $this->datatables->from('loan');
        //add this line for join
        //$this->datatables->join('table2', 'loan.field = table2.field');
        $this->datatables->add_column('action', anchor(site_url('loan/read/$1'),'Read')." | ".anchor(site_url('loan/update/$1'),'Update')." | ".anchor(site_url('loan/delete/$1'),'Delete','onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'loan_id');
        return $this->datatables->generate();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('loan_id', $q);
	$this->db->or_like('borrowers_id', $q);
	$this->db->or_like('Loan_product', $q);
	$this->db->or_like('loan', $q);
	$this->db->or_like('loan_disbursed_by_id', $q);
	$this->db->or_like('loan_principal_amount', $q);
	$this->db->or_like('loan_released_date', $q);
	$this->db->or_like('loan_interest_method', $q);
	$this->db->or_like('loan_interest_type', $q);
	$this->db->or_like('loan_interest', $q);
	$this->db->or_like('loan_interest_period', $q);
	$this->db->or_like('loan_duration', $q);
	$this->db->or_like('loan_duration_period', $q);
	$this->db->or_like('loan_payment_scheme_id', $q);
	$this->db->or_like('loan_num_of_repayments', $q);
	$this->db->or_like('loan_decimal_places', $q);
	$this->db->or_like('loan_interest_start_date', $q);
	$this->db->or_like('loan_first_repayment_date', $q);
	$this->db->or_like('first_repayment_amount', $q);
	$this->db->or_like('last_repayment_amount', $q);
	$this->db->or_like('loan_override_maturity_date', $q);
	$this->db->or_like('override_each_repayment_amount', $q);
	$this->db->or_like('loan_interest_schedule', $q);
	$this->db->or_like('gaurantor_id', $q);
	$this->db->or_like('gaurantor_id2', $q);
	$this->db->or_like('loan_description', $q);
	$this->db->or_like('loan_files', $q);
	$this->db->or_like('loan_status_id', $q);
	$this->db->or_like('user_id', $q);
	$this->db->or_like('time_date', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('loan_id', $q);
	$this->db->or_like('borrowers_id', $q);
	$this->db->or_like('Loan_product', $q);
	$this->db->or_like('loan', $q);
	$this->db->or_like('loan_disbursed_by_id', $q);
	$this->db->or_like('loan_principal_amount', $q);
	$this->db->or_like('loan_released_date', $q);
	$this->db->or_like('loan_interest_method', $q);
	$this->db->or_like('loan_interest_type', $q);
	$this->db->or_like('loan_interest', $q);
	$this->db->or_like('loan_interest_period', $q);
	$this->db->or_like('loan_duration', $q);
	$this->db->or_like('loan_duration_period', $q);
	$this->db->or_like('loan_payment_scheme_id', $q);
	$this->db->or_like('loan_num_of_repayments', $q);
	$this->db->or_like('loan_decimal_places', $q);
	$this->db->or_like('loan_interest_start_date', $q);
	$this->db->or_like('loan_first_repayment_date', $q);
	$this->db->or_like('first_repayment_amount', $q);
	$this->db->or_like('last_repayment_amount', $q);
	$this->db->or_like('loan_override_maturity_date', $q);
	$this->db->or_like('override_each_repayment_amount', $q);
	$this->db->or_like('loan_interest_schedule', $q);
	$this->db->or_like('gaurantor_id', $q);
	$this->db->or_like('gaurantor_id2', $q);
	$this->db->or_like('loan_description', $q);
	$this->db->or_like('loan_files', $q);
	$this->db->or_like('loan_status_id', $q);
	$this->db->or_like('user_id', $q);
	$this->db->or_like('time_date', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
    	$this->db->query("SET FOREIGN_KEY_CHECKS = 0");
        $this->db->insert($this->table, $data);
        $this->db->query("SET FOREIGN_KEY_CHECKS = 0");
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Loan_model.php */
/* Location: ./application/models/Loan_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */