<!doctype html>
</script>
    <script src="<?php echo base_url()."assets/";?>select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });</script>
<html>
   <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Group</h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="box box-info">


        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Group Name <?php echo form_error('group_name') ?></label>
            <input type="text" class="form-control" name="group_name" id="group_name" placeholder="Group Name" value="<?php echo $group_name; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Borrowers Id <?php echo form_error('borrowers_id') ?></label>


                <div class="form-group">
                  <select data-placeholder="Choose Borrower or Search by Name" class="select2 form-control" name="borrowers_id" id="inputLoanId1" >
                                    <option></option>  
                                    <?php
                $borrowers_get = $this->db->get('borrowers')->result_array();
                foreach($borrowers_get as $row): ?>
                                <option value="<?php echo $row['borrowers_id'];?>">
                  <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                endforeach;
                ?>
                                </select>

        </div>
	    <div class="form-group">
            <label for="varchar">Group Collector Name <?php echo form_error('group_collector_name') ?></label>
            <input type="text" class="form-control" name="group_collector_name" id="group_collector_name" placeholder="Group Collector Name" value="<?php echo $group_collector_name; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Group Meeting Schedule <?php echo form_error('group_meeting_schedule') ?></label>
            <input type="text" class="form-control" name="group_meeting_schedule" id="group_meeting_schedule" placeholder="Group Meeting Schedule" value="<?php echo $group_meeting_schedule; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Group Description <?php echo form_error('group_description') ?></label>
            <textarea type="text" class="form-control" name="group_description" id="group_description" placeholder="Group Description" value="<?php echo $group_description; ?>" /></textarea>
        </div>
	    <button type="submit" class="btn btn-primary pull-right">Submit</button>
	
        <a href="<?php echo site_url('borrowers_group') ?>" class="btn btn-default">Back</a>
	</form>
    </body>
</html>
