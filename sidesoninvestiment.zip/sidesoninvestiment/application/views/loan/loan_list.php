<!doctype html>
<html></head>
<div class="content-wrapper">

          <!-- Main content -->
          <section class="content">

      <script>
  $(document).ready(function () {
    $(".slidingDiv").hide();
    $('.show_hide').click(function (e) {
      $(".slidingDiv").slideToggle("fast");
      var val = $(this).text() == "Hide" ? "Show" : "Hide";
      $(this).hide().text(val).fadeIn("fast");
      e.preventDefault();
    });
  });</script>



   <body>

   
  </div>
  </div>

      <div class="row">
          <div class="col-xs-6">
              <div class="pull-left">
                  <div id="export_button">
                  </div>
              </div>
              <div class="pull-left">
                  <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
              </div>
          </div>

          <div class="col-xs-6">
              <div class="pull-right">


              </div>
          </div>
      </div>
  <div class="box box-info">
      <div class="box-body">
          <div class="col-sm-12 table-responsive">
  <table  id="mytable" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
         <thead>
                      <tr style="background-color: #D1F9FF">
                                   <th class="not-export-col" width="80px">No</th>
		    <th>Borrowers Id</th>
		    <th>Loan Product</th>
		    <th>Loan</th>
		    <th>Loan Disbursed By Id</th>
		    <th>Loan Principal Amount</th>
		    <th>Loan Released Date</th>
		    <th>Loan Interest Method</th>
		    <th>Loan Interest Type</th>
		    <th>Loan Interest</th>
		    <th>Loan Interest Period</th>
		    <th>Loan Duration</th>
		    <th>Loan Duration Period</th>
		    <th>Loan Payment Scheme Id</th>
		    <th>Loan Num Of Repayments</th>
		    <th>Loan Decimal Places</th>
		    <th>Loan Interest Start Date</th>
		    <th>Loan First Repayment Date</th>
		    <th>First Repayment Amount</th>
		    <th>Last Repayment Amount</th>
		    <th>Loan Override Maturity Date</th>
		    <th>Override Each Repayment Amount</th>
		    <th>Loan Interest Schedule</th>
		    <th>Gaurantor Id</th>
		    <th>Gaurantor Id2</th>
		    <th>Loan Description</th>
		    <th>Loan Files</th>
		    <th>Loan Status Id</th>
		   
		  
		    <th width="200px">Action</th>
                </tr>
            </thead>

        </table>

        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    "fixedHeader": {
                    "header": true,
                    "footer": true,
                },
                  "dom": '<"pull-left"f>r<"pull-right"l>tip',
                  "autoWidth": true,
                  "responsive": true,
                  searching:true,
                  stateSave: true,
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "loan/json", "type": "POST"},
                    columns: [
                        {
                            "data": "loan_id",
                            "orderable": false
                        },{"data": "borrowers_id"},{"data": "Loan_product"},{"data": "loan"},{"data": "loan_disbursed_by_id"},{"data": "loan_principal_amount"},{"data": "loan_released_date"},{"data": "loan_interest_method"},{"data": "loan_interest_type"},{"data": "loan_interest"},{"data": "loan_interest_period"},{"data": "loan_duration"},{"data": "loan_duration_period"},{"data": "loan_payment_scheme_id"},{"data": "loan_num_of_repayments"},{"data": "loan_decimal_places"},{"data": "loan_interest_start_date"},{"data": "loan_first_repayment_date"},{"data": "first_repayment_amount"},{"data": "last_repayment_amount"},{"data": "loan_override_maturity_date"},{"data": "override_each_repayment_amount"},{"data": "loan_interest_schedule"},{"data": "gaurantor_id"},{"data": "gaurantor_id2"},{"data": "loan_description"},{"data": "loan_files"},{"data": "loan_status_id"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>
    </body>
</html>
