
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Gauranters</h1>
                </section>

            
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                    <div class="pull-left">
                        <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            <div class="btn-group-horizontal">
                <a type="button" class="btn btn-block btn-default" href="home/filter_table_columns.php?filter_type=view_savings_accounts_branch">Show/Hide Columns</a>
            </div>
                    </div>
                </div>
            </div>              
       
            <div class="row">
                <div class="col-xs">
                    <div class="pull-left  btn-default" id="export_button">

                    </div>

                    </div>
                </div>
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
                    <table id="view-savings" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
                        <thead>
                          <tr style="background-color: #D1F9FF">
                                       <th class="not-export-col" width="80px">No</th>

       <th>Name</th>
        <th>Idno</th>
        <th>Busness Name</th>
        <th>Email</th>
      
        <th>Phone</th>
       
        <th>Dob</th>
        <th>Address</th>
        <th>Zipcode</th>
        <th>Town</th>
       
        <th>Description</th>

        <th width="200px">Action</th>
                </tr>
           
                       </thead>

                    </table>
                </div>
            </div>
        </div>

           <script type="text/javascript" language="javascript">

        $(document).ready(function() {
            var dataTable = $('#view-savings').DataTable( {
                "fixedHeader": {
                    "header": true,
                    "footer": true,
                },

                "autoWidth": true,
                "lengthMenu": [[10, 20, 100, 250, 500, 5000], [10, 20, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": false,
                "responsive": true,
                searching:true,
                stateSave: true,
               ajax: {"url": "gaurantors/json", "type": "POST"},
                    columns: [
                        {
                            "data": "gaurantor_id",
                            "orderable": false
                        },{"data": null, render: function ( data, type, row ) {
            // Combine the first and last names into a single table field
            return data.title+' '+data.fname+' '+data.lname;}},{"data": "idno"},{"data": "busness_name"},{"data": "email"},{"data": "phone"},{"data": "dob"},{"data": "address"},{"data": "zipcode"},{"data": "town"},{"data": "description"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                order: [[0, 'desc']],
            } );
             var buttons = new $.fn.dataTable.Buttons(dataTable, {
               "buttons": [
                  {
                      extend: 'collection',
                      text: 'Export Data',
                      buttons: [
                          'copy',
                          'excel',
                          'pdf',
                          'print'
                      ]
                  }
              ]
            }).container().appendTo($('#export_button'));


        } );

    </script>

    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );

</script>

    </body>
</html>