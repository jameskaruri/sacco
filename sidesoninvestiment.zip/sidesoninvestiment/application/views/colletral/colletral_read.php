<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Colletral Read</h2>
        <table class="table">
	    <tr><td>Borrowers Id</td><td><?php echo $borrowers_id; ?></td></tr>
	    <tr><td>Type</td><td><?php echo $type; ?></td></tr>
	    <tr><td>Productname</td><td><?php echo $productname; ?></td></tr>
	    <tr><td>Register</td><td><?php echo $register; ?></td></tr>
	    <tr><td>Value</td><td><?php echo $value; ?></td></tr>
	    <tr><td>Colletralstatus</td><td><?php echo $colletralstatus; ?></td></tr>
	    <tr><td>Colletralstatus Date</td><td><?php echo $colletralstatus date; ?></td></tr>
	    <tr><td>Serialno</td><td><?php echo $serialno; ?></td></tr>
	    <tr><td>Modelname</td><td><?php echo $modelname; ?></td></tr>
	    <tr><td>Datemanufacured</td><td><?php echo $datemanufacured; ?></td></tr>
	    <tr><td>Colletracondition</td><td><?php echo $colletracondition; ?></td></tr>
	    <tr><td>Address</td><td><?php echo $address; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $description; ?></td></tr>
	    <tr><td>Photo</td><td><?php echo $photo; ?></td></tr>
	    <tr><td>File</td><td><?php echo $file; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('colletral') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>