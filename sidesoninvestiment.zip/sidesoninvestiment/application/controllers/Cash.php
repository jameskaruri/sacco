<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cash extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Cash_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('cash/cash_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Cash_model->json();
    }

    public function read($id) 
    {
        $row = $this->Cash_model->get_by_id($id);
        if ($row) {
            $data = array(
		'cash_id' => $row->cash_id,
		'Apr' => $row->Apr,
		'May' => $row->May,
		'June' => $row->June,
		'July' => $row->July,
		'Aug' => $row->Aug,
		'Sep' => $row->Sep,
		'Type' => $row->Type,
	    );
            $this->load->view('cash/cash_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cash'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('cash/create_action'),
	    'cash_id' => set_value('cash_id'),
	    'Apr' => set_value('Apr'),
	    'May' => set_value('May'),
	    'June' => set_value('June'),
	    'July' => set_value('July'),
	    'Aug' => set_value('Aug'),
	    'Sep' => set_value('Sep'),
	    'Type' => set_value('Type'),
	);
        $this->load->view('cash/cash_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Apr' => $this->input->post('Apr',TRUE),
		'May' => $this->input->post('May',TRUE),
		'June' => $this->input->post('June',TRUE),
		'July' => $this->input->post('July',TRUE),
		'Aug' => $this->input->post('Aug',TRUE),
		'Sep' => $this->input->post('Sep',TRUE),
		'Type' => $this->input->post('Type',TRUE),
	    );

            $this->Cash_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('cash'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Cash_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('cash/update_action'),
		'cash_id' => set_value('cash_id', $row->cash_id),
		'Apr' => set_value('Apr', $row->Apr),
		'May' => set_value('May', $row->May),
		'June' => set_value('June', $row->June),
		'July' => set_value('July', $row->July),
		'Aug' => set_value('Aug', $row->Aug),
		'Sep' => set_value('Sep', $row->Sep),
		'Type' => set_value('Type', $row->Type),
	    );
            $this->load->view('cash/cash_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cash'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('cash_id', TRUE));
        } else {
            $data = array(
		'Apr' => $this->input->post('Apr',TRUE),
		'May' => $this->input->post('May',TRUE),
		'June' => $this->input->post('June',TRUE),
		'July' => $this->input->post('July',TRUE),
		'Aug' => $this->input->post('Aug',TRUE),
		'Sep' => $this->input->post('Sep',TRUE),
		'Type' => $this->input->post('Type',TRUE),
	    );

            $this->Cash_model->update($this->input->post('cash_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('cash'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Cash_model->get_by_id($id);

        if ($row) {
            $this->Cash_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('cash'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cash'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Apr', 'apr', 'trim|required');
	$this->form_validation->set_rules('May', 'may', 'trim|required');
	$this->form_validation->set_rules('June', 'june', 'trim|required');
	$this->form_validation->set_rules('July', 'july', 'trim|required');
	$this->form_validation->set_rules('Aug', 'aug', 'trim|required');
	$this->form_validation->set_rules('Sep', 'sep', 'trim|required');
	$this->form_validation->set_rules('Type', 'type', 'trim|required');

	$this->form_validation->set_rules('cash_id', 'cash_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Cash.php */
/* Location: ./application/controllers/Cash.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:19 */
/* http://harviacode.com */