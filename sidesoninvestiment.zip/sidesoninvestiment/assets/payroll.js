 function update_summary() 
 {
        var gross_amount = 0;
        var deductions = 0;
        
        var net_pay = 0;
        
        gross_amount=0;
    	$("input[name^='hours_and_earnings_']").each(function(){
		      gross_amount+=Number($(this).val());
		});
    	
    	deductions=0;
    	$("input[name^='pre_tax_deductions_']").each(function(){
		      deductions+=Number($(this).val());
		});
		
    	$("input[name^='tax_deductions_']").each(function(){
		      deductions+=Number($(this).val());
		});
		
    	$("input[name^='after_tax_deductions_']").each(function(){
		      deductions+=Number($(this).val());
		});
		
		$("#gross_pay_amount").val(gross_amount.toFixed(2));
		$("#total_deductions_amount").val(deductions.toFixed(2));
		
		var net_pay = parseFloat(gross_amount) - parseFloat(deductions);
		
		$("#net_pay_amount").val(net_pay.toFixed(2));
		$("#paid_amount").val(net_pay.toFixed(2));
		
    }
