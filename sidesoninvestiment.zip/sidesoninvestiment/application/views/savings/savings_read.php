<!doctype html>
<html>
         <-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>view personal details</h1>
                </section>

    

     <section class="content">
    <div class="box box-info">
   
    <body>
        
        <table class="table">
	    <tr><td>Borrowers Id</td><td><?php echo $borrowers_id; ?></td></tr>
	    <tr><td>Savings Product</td><td><?php echo $savings_product; ?></td></tr>
	    <tr><td>Account No</td><td><?php echo $account_no; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $description; ?></td></tr>
	    <tr><td>Last Transaction</td><td><?php echo $last_transaction; ?></td></tr>
	    
	    <tr><td></td><td><a href="<?php echo site_url('savings') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
    </div></section>
</html>