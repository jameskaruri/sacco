<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Payroll <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Employee Name <?php echo form_error('Employee_name') ?></label>
            <input type="text" class="form-control" name="Employee_name" id="Employee_name" placeholder="Employee Name" value="<?php echo $Employee_name; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Payroll Date <?php echo form_error('Payroll_Date') ?></label>
            <input type="text" class="form-control" name="Payroll_Date" id="Payroll_Date" placeholder="Payroll Date" value="<?php echo $Payroll_Date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Business Name <?php echo form_error('Business_Name') ?></label>
            <input type="text" class="form-control" name="Business_Name" id="Business_Name" placeholder="Business Name" value="<?php echo $Business_Name; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Basic Pay <?php echo form_error('Basic_Pay') ?></label>
            <input type="text" class="form-control" name="Basic_Pay" id="Basic_Pay" placeholder="Basic Pay" value="<?php echo $Basic_Pay; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Overtime <?php echo form_error('Overtime') ?></label>
            <input type="text" class="form-control" name="Overtime" id="Overtime" placeholder="Overtime" value="<?php echo $Overtime; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Paid Leaves <?php echo form_error('Paid_Leaves') ?></label>
            <input type="text" class="form-control" name="Paid_Leaves" id="Paid_Leaves" placeholder="Paid Leaves" value="<?php echo $Paid_Leaves; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Transport Allowance <?php echo form_error('Transport_Allowance') ?></label>
            <input type="text" class="form-control" name="Transport_Allowance" id="Transport_Allowance" placeholder="Transport Allowance" value="<?php echo $Transport_Allowance; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Medical Allowance <?php echo form_error('Medical_Allowance') ?></label>
            <input type="text" class="form-control" name="Medical_Allowance" id="Medical_Allowance" placeholder="Medical Allowance" value="<?php echo $Medical_Allowance; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Bonus <?php echo form_error('Bonus') ?></label>
            <input type="text" class="form-control" name="Bonus" id="Bonus" placeholder="Bonus" value="<?php echo $Bonus; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Other Allowance <?php echo form_error('Other_Allowance') ?></label>
            <input type="text" class="form-control" name="Other_Allowance" id="Other_Allowance" placeholder="Other Allowance" value="<?php echo $Other_Allowance; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Pension <?php echo form_error('Pension') ?></label>
            <input type="text" class="form-control" name="Pension" id="Pension" placeholder="Pension" value="<?php echo $Pension; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Health Insurance <?php echo form_error('Health_Insurance') ?></label>
            <input type="text" class="form-control" name="Health_Insurance" id="Health_Insurance" placeholder="Health Insurance" value="<?php echo $Health_Insurance; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Unpaid Leave <?php echo form_error('Unpaid_Leave') ?></label>
            <input type="text" class="form-control" name="Unpaid_Leave" id="Unpaid_Leave" placeholder="Unpaid Leave" value="<?php echo $Unpaid_Leave; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Tax Deduction <?php echo form_error('Tax_Deduction') ?></label>
            <input type="text" class="form-control" name="Tax_Deduction" id="Tax_Deduction" placeholder="Tax Deduction" value="<?php echo $Tax_Deduction; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Salary Loan <?php echo form_error('Salary_Loan') ?></label>
            <input type="text" class="form-control" name="Salary_Loan" id="Salary_Loan" placeholder="Salary Loan" value="<?php echo $Salary_Loan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Total Pay <?php echo form_error('Total_Pay') ?></label>
            <input type="text" class="form-control" name="Total_Pay" id="Total_Pay" placeholder="Total Pay" value="<?php echo $Total_Pay; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Total Deductions <?php echo form_error('Total_Deductions') ?></label>
            <input type="text" class="form-control" name="Total_Deductions" id="Total_Deductions" placeholder="Total Deductions" value="<?php echo $Total_Deductions; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Net Pay <?php echo form_error('Net_Pay') ?></label>
            <input type="text" class="form-control" name="Net_Pay" id="Net_Pay" placeholder="Net Pay" value="<?php echo $Net_Pay; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Payment Method <?php echo form_error('Payment_Method') ?></label>
            <input type="text" class="form-control" name="Payment_Method" id="Payment_Method" placeholder="Payment Method" value="<?php echo $Payment_Method; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Bank Name <?php echo form_error('Bank_Name') ?></label>
            <input type="text" class="form-control" name="Bank_Name" id="Bank_Name" placeholder="Bank Name" value="<?php echo $Bank_Name; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Account Number <?php echo form_error('Account_Number') ?></label>
            <input type="text" class="form-control" name="Account_Number" id="Account_Number" placeholder="Account Number" value="<?php echo $Account_Number; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('Description') ?></label>
            <input type="text" class="form-control" name="Description" id="Description" placeholder="Description" value="<?php echo $Description; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Paid Amount <?php echo form_error('Paid_Amount') ?></label>
            <input type="text" class="form-control" name="Paid_Amount" id="Paid_Amount" placeholder="Paid Amount" value="<?php echo $Paid_Amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Comments <?php echo form_error('Comments') ?></label>
            <input type="text" class="form-control" name="Comments" id="Comments" placeholder="Comments" value="<?php echo $Comments; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="payroll_id" value="<?php echo $payroll_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('payroll') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>