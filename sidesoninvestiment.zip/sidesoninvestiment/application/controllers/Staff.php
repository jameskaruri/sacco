<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Staff extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Staff_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('staff/staff_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Staff_model->json();
    }

    public function read($id) 
    {
        $row = $this->Staff_model->get_by_id($id);
        if ($row) {
            $data = array(
		'staff_id' => $row->staff_id,
		'surname' => $row->surname,
		'Fname' => $row->Fname,
		'Lname' => $row->Lname,
		'email' => $row->email,
		'Employee_number' => $row->Employee_number,
		'Idno' => $row->Idno,
		'job' => $row->job,
		'time_date' => $row->time_date,
	    );
            $this->load->view('staff/staff_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('staff'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('staff/create_action'),
	    'staff_id' => set_value('staff_id'),
	    'surname' => set_value('surname'),
	    'Fname' => set_value('Fname'),
	    'Lname' => set_value('Lname'),
	    'email' => set_value('email'),
	    'Employee_number' => set_value('Employee_number'),
	    'Idno' => set_value('Idno'),
	    'job' => set_value('job'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('staff/staff_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'surname' => $this->input->post('surname',TRUE),
		'Fname' => $this->input->post('Fname',TRUE),
		'Lname' => $this->input->post('Lname',TRUE),
		'email' => $this->input->post('email',TRUE),
		'Employee_number' => $this->input->post('Employee_number',TRUE),
		'Idno' => $this->input->post('Idno',TRUE),
		'job' => $this->input->post('job',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Staff_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('staff'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Staff_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('staff/update_action'),
		'staff_id' => set_value('staff_id', $row->staff_id),
		'surname' => set_value('surname', $row->surname),
		'Fname' => set_value('Fname', $row->Fname),
		'Lname' => set_value('Lname', $row->Lname),
		'email' => set_value('email', $row->email),
		'Employee_number' => set_value('Employee_number', $row->Employee_number),
		'Idno' => set_value('Idno', $row->Idno),
		'job' => set_value('job', $row->job),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('staff/staff_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('staff'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('staff_id', TRUE));
        } else {
            $data = array(
		'surname' => $this->input->post('surname',TRUE),
		'Fname' => $this->input->post('Fname',TRUE),
		'Lname' => $this->input->post('Lname',TRUE),
		'email' => $this->input->post('email',TRUE),
		'Employee_number' => $this->input->post('Employee_number',TRUE),
		'Idno' => $this->input->post('Idno',TRUE),
		'job' => $this->input->post('job',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Staff_model->update($this->input->post('staff_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('staff'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Staff_model->get_by_id($id);

        if ($row) {
            $this->Staff_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('staff'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('staff'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('surname', 'surname', 'trim|required');
	$this->form_validation->set_rules('Fname', 'fname', 'trim|required');
	$this->form_validation->set_rules('Lname', 'lname', 'trim|required');
	$this->form_validation->set_rules('email', 'email', 'trim|required');
	$this->form_validation->set_rules('Employee_number', 'employee number', 'trim|required');
	$this->form_validation->set_rules('Idno', 'idno', 'trim|required');
	$this->form_validation->set_rules('job', 'job', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('staff_id', 'staff_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Staff.php */
/* Location: ./application/controllers/Staff.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */