<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Gaurantors extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Gaurantors_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
    	$this->load->view('header/link');
        $this->load->view('gaurantors/vew_gauranters');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Gaurantors_model->json();
    }

    public function read($id) 
    {
        $row = $this->Gaurantors_model->get_by_id($id);
        if ($row) {
            $data = array(
		'gaurantor_id' => $row->gaurantor_id,
		'fname' => $row->fname,
		'lname' => $row->lname,
		'idno' => $row->idno,
		'busness_name' => $row->busness_name,
		'email' => $row->email,
		'title' => $row->title,
		'phone' => $row->phone,
		'gender' => $row->gender,
		'dob' => $row->dob,
		'address' => $row->address,
		'zipcode' => $row->zipcode,
		'town' => $row->town,
		'working_status' => $row->working_status,
		'imaetmp' => $row->imaetmp,
		'description' => $row->description,
		'imagetmpo' => $row->imagetmpo,
		'time_date' => $row->time_date,
	    );
            $this->load->view('gaurantors/gaurantors_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gaurantors'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('gaurantors/create_action'),
	    'gaurantor_id' => set_value('gaurantor_id'),
	    'fname' => set_value('fname'),
	    'lname' => set_value('lname'),
	    'idno' => set_value('idno'),
	    'busness_name' => set_value('busness_name'),
	    'email' => set_value('email'),
	    'title' => set_value('title'),
	    'phone' => set_value('phone'),
	    'gender' => set_value('gender'),
	    'dob' => set_value('dob'),
	    'address' => set_value('address'),
	    'zipcode' => set_value('zipcode'),
	    'town' => set_value('town'),
	    'working_status' => set_value('working_status'),
	    'imaetmp' => set_value('imaetmp'),
	    'description' => set_value('description'),
	   
	);
        $this->load->view('header/link');
        $this->load->view('gaurantors/gaurantors_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'fname' => $this->input->post('fname',TRUE),
		'lname' => $this->input->post('lname',TRUE),
		'idno' => $this->input->post('idno',TRUE),
		'busness_name' => $this->input->post('busness_name',TRUE),
		'email' => $this->input->post('email',TRUE),
		'title' => $this->input->post('title',TRUE),
		'phone' => $this->input->post('phone',TRUE),
		'gender' => $this->input->post('gender',TRUE),
		'dob' => $this->input->post('dob',TRUE),
		'address' => $this->input->post('address',TRUE),
		'zipcode' => $this->input->post('zipcode',TRUE),
		'town' => $this->input->post('town',TRUE),
		'working_status' => $this->input->post('working_status',TRUE),
		'imaetmp' => $this->input->post('imaetmp',TRUE),
		'description' => $this->input->post('description',TRUE),
		
	    );

            $this->Gaurantors_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('gaurantors'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Gaurantors_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('gaurantors/update_action'),
		'gaurantor_id' => set_value('gaurantor_id', $row->gaurantor_id),
		'fname' => set_value('fname', $row->fname),
		'lname' => set_value('lname', $row->lname),
		'idno' => set_value('idno', $row->idno),
		'busness_name' => set_value('busness_name', $row->busness_name),
		'email' => set_value('email', $row->email),
		'title' => set_value('title', $row->title),
		'phone' => set_value('phone', $row->phone),
		'gender' => set_value('gender', $row->gender),
		'dob' => set_value('dob', $row->dob),
		'address' => set_value('address', $row->address),
		'zipcode' => set_value('zipcode', $row->zipcode),
		'town' => set_value('town', $row->town),
		'working_status' => set_value('working_status', $row->working_status),
		'imaetmp' => set_value('imaetmp', $row->imaetmp),
		'description' => set_value('description', $row->description),
		'imagetmpo' => set_value('imagetmpo', $row->imagetmpo),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('gaurantors/gaurantors_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gaurantors'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('gaurantor_id', TRUE));
        } else {
            $data = array(
		'fname' => $this->input->post('fname',TRUE),
		'lname' => $this->input->post('lname',TRUE),
		'idno' => $this->input->post('idno',TRUE),
		'busness_name' => $this->input->post('busness_name',TRUE),
		'email' => $this->input->post('email',TRUE),
		'title' => $this->input->post('title',TRUE),
		'phone' => $this->input->post('phone',TRUE),
		'gender' => $this->input->post('gender',TRUE),
		'dob' => $this->input->post('dob',TRUE),
		'address' => $this->input->post('address',TRUE),
		'zipcode' => $this->input->post('zipcode',TRUE),
		'town' => $this->input->post('town',TRUE),
		'working_status' => $this->input->post('working_status',TRUE),
		'imaetmp' => $this->input->post('imaetmp',TRUE),
		'description' => $this->input->post('description',TRUE),
		
		
	    );

            $this->Gaurantors_model->update($this->input->post('gaurantor_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('gaurantors'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Gaurantors_model->get_by_id($id);

        if ($row) {
            $this->Gaurantors_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('gaurantors'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('gaurantors'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('fname', 'fname', 'trim|required');
	$this->form_validation->set_rules('lname', 'lname', 'trim|required');
	$this->form_validation->set_rules('idno', 'idno', 'trim|required');
	$this->form_validation->set_rules('busness_name', 'busness name', 'trim|required');
	$this->form_validation->set_rules('email', 'email', 'trim|required');
	$this->form_validation->set_rules('title', 'title', 'trim|required');
	$this->form_validation->set_rules('phone', 'phone', 'trim|required');
	$this->form_validation->set_rules('gender', 'gender', 'trim|required');
	$this->form_validation->set_rules('dob', 'dob', 'trim|required');
	$this->form_validation->set_rules('address', 'address', 'trim|required');
	$this->form_validation->set_rules('zipcode', 'zipcode', 'trim|required');
	$this->form_validation->set_rules('town', 'town', 'trim|required');
	$this->form_validation->set_rules('working_status', 'working status', 'trim|required');
	$this->form_validation->set_rules('description', 'description', 'trim|required');

	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Gaurantors.php */
/* Location: ./application/controllers/Gaurantors.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */