<?php
/**
*
*/
class Insert extends CI_Controller
{

	public function __construct(){
        parent:: __construct();
        $this->load->model('Queries');

    }
		public function index(){
			$this->load->view('header/link');
	        $this->load->view('borrowers/add_borrower');
				}

	public function Add_borrowers(){
		$this->load->view('header/link');
        $this->load->view('borrowers/add_borrower');

		$data = $this->input->post();
		unset($data['submit']);

		if ($this->Queries->add_borrowers($data)) {
			 $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('borrowers'));
		}
		else{
            $this->session->set_flashdata('response', 'erro, borrower not added');
		}
	}

}
