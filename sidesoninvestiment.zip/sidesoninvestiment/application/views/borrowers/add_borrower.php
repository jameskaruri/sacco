
<!DOCTYPE html>
<html>
    <head>
           <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Member<small><a href="" target="_blank">Help</a></small></h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="box box-info">
<script type="text/javascript">
        $(document).ready(function() {
          if (window.FormData) {
              $('#data_files').bind({
                  change : function()
                  {
                      var input = document.getElementById('data_files');
                      files = input.files;

                      if (files.length > 20) {
                          alert('You can only upload max of 20 files');
                          $('#data_files').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(application/pdf|application/acrobat|applications/vnd.pdf|text/pdf|text/x-pdf|application/msword|application/x-msword|application/vnd.openxmlformats-officedocument.wordprocessingml.document|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet|text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/zip|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt|image/png|image/jpeg|image/gif|application/zip|application/x-zip|application/octet-stream|application/x-zip-compressed)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload text, word, pdf, image, zip, csv, or excel files.",
                                          type: "red"
                                        });
                                      $('#data_files').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });

                                  $('#data_files').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
              $('#photo_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('photo_file');
                      files = input.files;

                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#photo_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(image/png|image/jpeg|image/gif/image/jpg)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload png, jpeg, or gif files.",
                                          type: "red"
                                        });
                                      $('#photo_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#photo_file').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
              $('#csv_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('csv_file');
                      files = input.files;

                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#csv_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var matcher = regExp.test(file.type);
                              if (file.type != '')
                              {
                                  var filesize = file.size;
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload csv file.",
                                          type: "red"
                                        });
                                      $('#csv_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#csv_file').val("");
                                  return false;
                              }
                          }
                      }
                  }
              });
          }
        });
        </script>
        <body>

            <div class="panel panel-default"><div class="panel-body bg-gray text-bold" >Personal details:</div></div>
            <?php echo form_open_multipart($action, 'id="add_borrower_form"' ); ?>
                <table class="table table-bordered table-condensed table-hover" style="width: 100%">
                  <tr><td>
          <div class="form-group">
                <label for="varchar">Surname <?php echo form_error('borrower_surname') ?></label>
                <input type="text" class="form-control" name="borrower_surname" id="borrower_surname" placeholder="Borrower Surname" value="<?php echo $borrower_surname; ?>" required />
            </div></td><td>
          <div class="form-group">
                <label for="varchar">Borrower Firstname <?php echo form_error('borrower_firstname') ?></label>
                <input type="text" class="form-control" name="borrower_firstname" id="borrower_firstname" placeholder="Borrower Firstname" value="<?php echo $borrower_firstname; ?>" required />
            </div></td><td>

          <div class="form-group">
                <label for="varchar">Borrower Lastname <?php echo form_error('borrower_lastname') ?></label>
                <input type="text" class="form-control" name="borrower_lastname" id="borrower_lastname" placeholder="Borrower Lastname" value="<?php echo $borrower_lastname; ?>" required />
            </div></td></tr>
              <tr><td>
                <div class="form-group">
                      <label for="varchar">Borrower Id Number <?php echo form_error('borrower_id_number') ?></label>
                      <input type="text" class="form-control" name="borrower_id_number" id="borrower_id_number" placeholder="Borrower Id Number" value="<?php echo $borrower_id_number; ?>" required />
                      <span id="availability" ></span>
                  </div>
              </td>
                <td>
                  <div class="form-group">
                         <label for="varchar">Borrower Email <?php echo form_error('borrower_email') ?></label>
                         <input type="text" class="form-control" name="borrower_email" id="borrower_email" placeholder="Borrower Email" value="<?php echo $borrower_email; ?>"  />
                     </div>
                </td>
               <td>
                 <div class="form-group">
                        <label for="varchar">Borrower Mobile <?php echo form_error('borrower_mobile') ?></label>
                        <input type="text" class="form-control" name="borrower_mobile" id="borrower_mobile" placeholder="Borrower Mobile" value="<?php echo $borrower_mobile; ?>" required />
                    </div>
               </td>
              </tr>
              <tr>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Gender <?php echo form_error('borrower_gender') ?></label>
                        <select type="text" class="form-control" name="borrower_gender" id="borrower_gender" placeholder="Borrower Gender" value="" required />
                          <option value="<?php echo $borrower_gender; ?>"><?php echo $borrower_gender; ?></option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                    </div>
                </td>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Title <?php echo form_error('borrower_title') ?></label>
                        <select type="text" class="form-control" name="borrower_title" id="borrower_title" placeholder="Borrower Title" value="" required />
                          <option value="<?php echo $borrower_title; ?>"><?php echo $borrower_title; ?></option>
                          <option value="Mr">Mr</option>
                          <option value="Mrs">Mrs</option>
                          <option value="Miss">Miss</option>


                        </select>
                    </div>
                </td>
                <td>
                  <script>
                $(function() {
                    $('#borrower_dob').datepick({
                    maxDate: '',
                    defaultDate: '01/01/1999', showTrigger: '#calImg',
                    yearRange: 'c-80:c+20', showTrigger: '#calImg',

                    dateFormat: 'dd/mm/yyyy',
                    minDate: '01/01/1920'
                    });
                });

                </script>
                  <div class="form-group">
                        <label for="varchar">Borrower Dob <?php echo form_error('borrower_dob') ?></label>
                        <input type="text" class="form-control" name="borrower_dob" id="borrower_dob" placeholder="Borrower Dob" value="<?php echo $borrower_dob; ?>" required />
                    </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Address <?php echo form_error('borrower_address') ?></label>
                        <input type="text" class="form-control" name="borrower_address" id="borrower_address" placeholder="Borrower Address" value="<?php echo $borrower_address; ?>" />
                    </div>
                </td>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Zipcode <?php echo form_error('borrower_zipcode') ?></label>
                        <input type="text" class="form-control" name="borrower_zipcode" id="borrower_zipcode" placeholder="Borrower Zipcode" value="<?php echo $borrower_zipcode; ?>" />
                    </div>
                </td>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Town <?php echo form_error('borrower_town') ?></label>
                        <input type="text" class="form-control" name="borrower_town" id="borrower_town" placeholder="Borrower Town" value="<?php echo $borrower_town; ?>" required />
                    </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Street <?php echo form_error('borrower_street') ?></label>
                        <input type="text" class="form-control" name="borrower_street" id="borrower_street" placeholder="Borrower Street" value="<?php echo $borrower_street; ?>" required />
                    </div>
                </td>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Estate <?php echo form_error('borrower_estate') ?></label>
                        <input type="text" class="form-control" name="borrower_estate" id="borrower_estate" placeholder="Borrower Estate" value="<?php echo $borrower_estate; ?>" required />
                    </div>
                </td>
                  <td>
                    <div class="form-group">
                          <label for="varchar">Borrower Nearestcommonfeature <?php echo form_error('borrower_nearestcommonfeature') ?></label>
                          <input type="text" class="form-control" name="borrower_nearestcommonfeature" id="borrower_nearestcommonfeature" placeholder="Borrower Nearestcommonfeature" value="<?php echo $borrower_nearestcommonfeature; ?>" required />
                      </div>
                  </td>
              </tr>
              <tr>
                <td>
                  <div class="form-group">
                        <label for="varchar">Borrower Picture </label>
                        <input type="file" class="form-control" name="userfile" id="borrower_picture" placeholder="Borrower Picture" value="" />

                    </div>
                  <div class="form-group">
                        <label for="varchar">Borrower Description <?php echo form_error('borrower_description') ?></label>
                        <textarea type="text" class="form-control" name="borrower_description" id="borrower_description" placeholder="Borrower Description" value="<?php echo $borrower_description; ?>" required /></textarea>
                    </div>
                  <!--<div class="form-group">
                        <label for="varchar">Borrower Id </label>
                        <input type="file" class="form-control" name="borrower_id" id="borrower_id" placeholder="Borrower Id" value="" required />
                    </div>-->
                </td>
              </tr>
       </table>
       <table class="table table-bordered table-condensed table-hover" style="width: 100%">
        <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Business details:</div></div>
        <tr>
          <td>
            <div class="form-group">
                  <label for="varchar">Borrower Business Name <?php echo form_error('borrower_business_name') ?></label>
                  <input type="text" class="form-control" name="borrower_business_name" id="borrower_business_name" placeholder="Borrower Business Name" value="<?php echo $borrower_business_name; ?>"  />
              </div>
          </td>
          <td>
            <div class="form-group">
                   <label for="varchar">Borrower Business Nature <?php echo form_error('borrower_business_nature') ?></label>
                   <input type="text" class="form-control" name="borrower_business_nature" id="borrower_business_nature" placeholder="Borrower Business Nature" value="<?php echo $borrower_business_nature; ?>" required />
               </div>
          </td>
         <td>
           <div class="form-group">
                  <label for="varchar">Borrower Business Duration <?php echo form_error('borrower_business_Duration') ?></label>
                  <input type="text" class="form-control" name="borrower_business_Duration" id="borrower_business_Duration" placeholder="Borrower Business Duration" value="<?php echo $borrower_business_Duration; ?>" required />
              </div>
         </td>
        </tr>
       <tr>
        <td>
          <div class="form-group">
                <label for="varchar">Business Owner <?php echo form_error('Business_owner') ?></label>
                <input type="text" class="form-control" name="Business_owner" id="Business_owner" placeholder="Business Owner" value="<?php echo $Business_owner; ?>" required />
            </div>
        </td>
        <td>
          <div class="form-group">
                <label for="varchar">Address1 <?php echo form_error('address1') ?></label>
                <input type="text" class="form-control" name="address1" id="address1" placeholder="Address1" value="<?php echo $address1; ?>" required />
            </div>
        </td>
        <td>
          <div class="form-group">
                <label for="varchar">Zipcode1 <?php echo form_error('zipcode1') ?></label>
                <input type="text" class="form-control" name="zipcode1" id="zipcode1" placeholder="Zipcode1" value="<?php echo $zipcode1; ?>" required />
            </div>
        </td>
       </tr>
       <tr>
        <td>
          <div class="form-group">
                <label for="varchar">Town1 <?php echo form_error('town1') ?></label>
                <input type="text" class="form-control" name="town1" id="town1" placeholder="Town1" value="<?php echo $town1; ?>" required />
            </div>
        </td>
        <td>
          <div class="form-group">
                <label for="varchar">Street1 <?php echo form_error('street1') ?></label>
                <input type="text" class="form-control" name="street1" id="street1" placeholder="Street1" value="<?php echo $street1; ?>" required />
            </div>
        </td>
        <td>
          <div class="form-group">
                <label for="varchar">Estate1 <?php echo form_error('estate1') ?></label>
                <input type="text" class="form-control" name="estate1" id="estate1" placeholder="Estate1" value="<?php echo $estate1; ?>" required />
            </div>
        </td>
       </tr>
       <tr>
        <td>
          <div class="form-group">
                <label for="varchar">Nearestcommonfeature1 <?php echo form_error('nearestcommonfeature1') ?></label>
                <input type="text" class="form-control" name="nearestcommonfeature1" id="nearestcommonfeature1" placeholder="Nearestcommonfeature1" value="<?php echo $nearestcommonfeature1; ?>" required />
            </div>
        </td>
       </tr></table>
       <table class="table table-bordered table-condensed table-hover" style="width: 100%">
          <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Direction:</div>
          <tr>
            <td>
              <div class="form-group">
                    <label for="varchar">Business Location <?php echo form_error('business_location') ?></label>
                    <textarea type="text" class="form-control" name="business_location" id="business_location" placeholder="Business Location" value="<?php echo $business_location; ?>" required /></textarea>
                </div>
            </td>
            <td>
              <div class="form-group">
                    <label for="varchar">Residence Location <?php echo form_error('residence_location') ?></label>
                    <textarea type="text" class="form-control" name="residence_location" id="residence_location" placeholder="Residence Location" value="<?php echo $residence_location; ?>" required /></textarea>
                </div>
            </td>

          </tr>
          </table>
            <input type="hidden"  name="borrower_access_ids" id="borrower_access_ids" value="" required />
          <input type="hidden" name="borrowers_id" value="<?php echo $borrowers_id; ?>" required />
          <button type="submit" class="btn btn-info pull-right align" >Submit</button>
          <a href="<?php echo site_url('borrowers') ?>" class="btn btn-default">Back</a>
       <?php echo form_close(); ?>
        </body><script type="text/javascript">
          $(document).ready(function(){
      $('#borrower_id_number').change(function(){
        var idno = $('#borrower_id_number').val();
        if (idno!='') {
          $.ajax({
             url:"<?php echo site_url('borrowers/id_availability');?> ";
             method:"POST",
             data:{borrower_id_number:borrower_id_number},
             success:function(data){
              $('#availability').html(data);
             }

          });
        }
      });
    });
  </script>
    <script type="text/javascript">
    $('#add_borrower_form').on('submit', function(e) {

        $(this).find('button[type=submit]').prop('disabled', true);
        $('.btn').prop('disabled', true);
        $('.btn').button('loading');
        return true;
    });
    </script>
                </div><!-- /.box-footer -->
            </div>
        </form>
    </div>
    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>






    </body>
</html>
