<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Other_income <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Type <?php echo form_error('Type') ?></label>
            <input type="text" class="form-control" name="Type" id="Type" placeholder="Type" value="<?php echo $Type; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Amount <?php echo form_error('Amount') ?></label>
            <input type="text" class="form-control" name="Amount" id="Amount" placeholder="Amount" value="<?php echo $Amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Transaction Date <?php echo form_error('Transaction_Date') ?></label>
            <input type="text" class="form-control" name="Transaction_Date" id="Transaction_Date" placeholder="Transaction Date" value="<?php echo $Transaction_Date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Recurring <?php echo form_error('Recurring') ?></label>
            <input type="text" class="form-control" name="Recurring" id="Recurring" placeholder="Recurring" value="<?php echo $Recurring; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Recurring Other Income <?php echo form_error('Recurring_Other_Income') ?></label>
            <input type="text" class="form-control" name="Recurring_Other_Income" id="Recurring_Other_Income" placeholder="Recurring Other Income" value="<?php echo $Recurring_Other_Income; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('Description') ?></label>
            <input type="text" class="form-control" name="Description" id="Description" placeholder="Description" value="<?php echo $Description; ?>" />
        </div>
	    <div class="form-group">
            <label for="longblob">Receipt <?php echo form_error('Receipt') ?></label>
            <input type="text" class="form-control" name="Receipt" id="Receipt" placeholder="Receipt" value="<?php echo $Receipt; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="income_id" value="<?php echo $income_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('other_income') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>