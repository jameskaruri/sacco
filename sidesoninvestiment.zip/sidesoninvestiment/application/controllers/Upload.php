<?php

class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();

        }

        public function index()
        {
                $this->load->library('custom_upload');
                $this->load->view('upload', array('error' => ' ' ));
        }

        public function do_upload()
        {   $data=  $this->custom_upload->single_upload('userfile', $config = array(
          'upload_path'=>'upload',
          'allowed_types'=> 'jpg|jpeg|bpn|png|gif',
        ) );
                       $data = array('upload_data' => $this->upload->data());

                        $this->load->view('view_image', $data);
                }
        }

?>
