
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>View Savings Accounts</h1>
                </section>

                <!-- Main content -->
                <section class="content">
        <script>
        $(document).ready(function () {
          $(".slidingDiv").hide();       
          $('.show_hide').click(function (e) {
            $(".slidingDiv").slideToggle("fast");
            var val = $(this).text() == "Hide" ? "Show" : "Hide";
            $(this).hide().text(val).fadeIn("fast");
            e.preventDefault();
          });
        });
        </script>
        <p><b>Advanced Search: <a href="#" class="show_hide">Show</a></b></p>
        <div class="slidingDiv" style="display: none;">
                
        <div class="box box-success">
            
            <form class="form-horizontal" method="get" enctype="multipart/form-data">
                <input type="hidden" name="search_savings" value="1">
                <div class="box-body">
                  <p>All fields are optional. You can type or select as many fields as you like.</p>
                </div><!-- /.box-body -->

                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-6">
                        <input type="text" name="savings_borrower_name" class="form-control" id="inputSavingsBorrowerName" placeholder="Borrower Name or Business Name" value="">
                    </div>
                    <div class="col-xs-6">
                        <input type="text" name="savings_account_number" class="form-control" id="inputSavingsAccountNumber" placeholder="Savings Account #" value="">
                    </div>
                 </div>
                </div><!-- /.box-body -->
                
                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-6">
                    </div>
                  </div>
                </div><!-- /.box-body -->
                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-12">
                        <span class="input-group-btn">
                          <button type="button" class="btn bg-purple btn-flat pull-right" onClick="parent.location='savings/view_savings_branch.php'">Reset!</button>
                          <button type="submit" class="btn bg-olive btn-flat pull-right">Search!</button>
                        </span>
                    </div>
                  </div>
                </div><!-- /.box-body -->
            </form>
          </div><!-- /.box -->
          </div>
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                    <div class="pull-left">
                        <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            <div class="btn-group-horizontal">
                <a type="button" class="btn btn-block btn-default" href="home/filter_table_columns.php?filter_type=view_savings_accounts_branch">Show/Hide Columns</a>
            </div>
                    </div>
                </div>
            </div>              
       
            <div class="row">
                <div class="col-xs">
                    <div class="pull-left  btn-default" id="export_button">

                    </div>

                    </div>
                </div>
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
                    <table id="view-savings" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
                        <thead>
                          <tr style="background-color: #D1F9FF">
                                       <th class="not-export-col" width="80px">No</th>

                                      <th>Borrowers Id</th>
            <th>Savings Product</th>
            <th>Account No</th>
            <th>Description</th>
            <th>Last Transaction</th>
           
            <th width="200px">Action</th>
              </tr>
                       </thead>

                    </table>
                </div>
            </div>
        </div>

           <script type="text/javascript" language="javascript">

        $(document).ready(function() {
            var dataTable = $('#view-savings').DataTable( {
                "fixedHeader": {
                    "header": true,
                    "footer": true,
                },

                "autoWidth": true,
                "lengthMenu": [[10, 20, 100, 250, 500, 5000], [10, 20, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": false,
                "responsive": true,
                searching:true,
                stateSave: true,
                ajax: {"url": "savings/json", "type": "POST"},
                    columns: [
                        {
                            "data": "saving_id",
                            "orderable": false
                        },{"data": "borrowers_id"},{"data": "savings_product"},{"data": "account_no"},{"data": "description"},{"data": "last_transaction"},
                    {
                        "data" : "action",
                        "orderable": false,
                        "className" : "text-center"
                    }
                ],
                order: [[0, 'desc']],
            } );
             var buttons = new $.fn.dataTable.Buttons(dataTable, {
               "buttons": [
                  {
                      extend: 'collection',
                      text: 'Export Data',
                      buttons: [
                          'copy',
                          'excel',
                          'pdf',
                          'print'
                      ]
                  }
              ]
            }).container().appendTo($('#export_button'));


        } );

    </script>

    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );

</script>

    </body>
</html>