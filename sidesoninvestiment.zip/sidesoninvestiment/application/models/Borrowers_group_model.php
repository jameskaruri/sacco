<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Borrowers_group_model extends CI_Model
{

    public $table = 'borrowers_group';
    public $id = 'group_id';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // datatables
    function json() {
            $this->datatables->select('group_id,group_name,borrowers_group.borrowers_id,group_collector_name,group_meeting_schedule,group_description');
        $this->datatables->from('borrowers_group');
       
         $this->datatables->join('borrowers', 'borrowers_group.borrowers_id = borrowers.borrower_surname','LEFT');

        $this->datatables->add_column('action', anchor(site_url('borrowers_group/read/$1'),'view','class="btn btn-primary btn-xs"')." | ".anchor(site_url('borrowers_group/update/$1'),'Edit','class="btn btn-info btn-xs"')." | ".anchor(site_url('borrowers_group/delete/$1'),'Delete','class="btn btn-danger btn-xs"','onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'group_id');
        return $this->datatables->generate();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }

    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('group_id', $q);
	$this->db->or_like('group_name', $q);
	$this->db->or_like('borrowers_id', $q);
	$this->db->or_like('group_collector_name', $q);
	$this->db->or_like('group_meeting_schedule', $q);
	$this->db->or_like('group_description', $q);
	$this->db->or_like('time_date', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('group_id', $q);
	$this->db->or_like('group_name', $q);
	$this->db->or_like('borrowers_id', $q);
	$this->db->or_like('group_collector_name', $q);
	$this->db->or_like('group_meeting_schedule', $q);
	$this->db->or_like('group_description', $q);
	$this->db->or_like('time_date', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }
    function get_id(){
    $this->db->select('*');
     $this->db->where('borrowers');;
    $query= $this->db->get();
    return $query->row_array();

    }

    // insert data
    function insert($data)
    {
        $this->db->query("SET FOREIGN_KEY_CHECKS = 0");
        $this->db->insert($this->table, $data);
       $this->db->query("SET FOREIGN_KEY_CHECKS = 1");
    }

    // update data
    function update($id, $data)
    {
        
        $this->db->where($this->id, $id);

        $this->db->update($this->table, $data);
       
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }
    function join(){
        $this->db->select('*');
        $this->db->where('borrower');
        $this->db->join('borrowers_group', 'borrower.borrowers_id = borrowers_group.borrowers_id');
        $query= $this->db->get();
        foreach ($query->result() as $row) {
            echo $row->borrower_surname;
        }

    }

}
