<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Repayments <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="int">Borrowers Id <?php echo form_error('borrowers_id') ?></label>
            <input type="text" class="form-control" name="borrowers_id" id="borrowers_id" placeholder="Borrowers Id" value="<?php echo $borrowers_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Amout <?php echo form_error('amout') ?></label>
            <input type="text" class="form-control" name="amout" id="amout" placeholder="Amout" value="<?php echo $amout; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Method <?php echo form_error('method') ?></label>
            <input type="text" class="form-control" name="method" id="method" placeholder="Method" value="<?php echo $method; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Date Collected <?php echo form_error('date_collected') ?></label>
            <input type="text" class="form-control" name="date_collected" id="date_collected" placeholder="Date Collected" value="<?php echo $date_collected; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Collected By <?php echo form_error('collected_by') ?></label>
            <input type="text" class="form-control" name="collected_by" id="collected_by" placeholder="Collected By" value="<?php echo $collected_by; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Description <?php echo form_error('description') ?></label>
            <input type="text" class="form-control" name="description" id="description" placeholder="Description" value="<?php echo $description; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="repayment_id" value="<?php echo $repayment_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('repayments') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>