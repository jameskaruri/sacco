<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Repayments extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Repayments_model');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
     {
        $this->load->view('header/link');
        $this->load->view('repayments/view_repayments_branch');
    }

    public function json() {
        header('Content-Type: application/json');
        echo $this->Repayments_model->json();
    }

    public function read($id)
    {
        $row = $this->Repayments_model->get_by_id($id);
        if ($row) {
            $data = array(
		'repayment_id' => $row->repayment_id,
		'borrowers_id' => $row->borrowers_id,
		'amout' => $row->amout,
		'method' => $row->method,
		
		'collected_by' => $row->collected_by,
		'description' => $row->description,
		'time_date' => $row->time_date,
	    );
            $this->load->view('repayments/repayments_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('repayments'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('repayments/create_action'),
	    'repayment_id' => set_value('repayment_id'),
	    'borrowers_id' => set_value('borrowers_id'),
	    'amout' => set_value('amout'),
	    'method' => set_value('method'),
	    
	    'collected_by' => set_value('collected_by'),
	    'description' => set_value('description'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('repayments/repayments_form', $data);
    }

    public function create_action()
    {
        

        if ( $this->Repayments_model->insert($_post) == FALSE &&  $this->Repayments_model->insert($_post['borrowers_id'])) {
            $this->create();
        } else {
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('repayments'));
        }
    }

    public function update($id)
    {
        $row = $this->Repayments_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('repayments/update_action'),
		'repayment_id' => set_value('repayment_id', $row->repayment_id),
		'borrowers_id' => set_value('borrowers_id', $row->borrowers_id),
		'amout' => set_value('amout', $row->amout),
		'method' => set_value('method', $row->method),
		
		'collected_by' => set_value('collected_by', $row->collected_by),
		'description' => set_value('description', $row->description),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('repayments/repayments_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('repayments'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('repayment_id', TRUE));
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'amout' => $this->input->post('amout',TRUE),
		'method' => $this->input->post('method',TRUE),
		
		'collected_by' => $this->input->post('collected_by',TRUE),
		'description' => $this->input->post('description',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Repayments_model->update($this->input->post('repayment_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('repayments'));
        }
    }

    public function delete($id)
    {
        $row = $this->Repayments_model->get_by_id($id);

        if ($row) {
            $this->Repayments_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('repayments'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('repayments'));
        }
    }

   

}

