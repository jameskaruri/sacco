
<!DOCTYPE html>
<html>
  
      <body>
    
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Loan<small><a href="17000013919-add-loan-and-edit-loan" target="_blank">Help</a></small></h1>
                </section>

                <!-- Main content -->
                <section class="content">
        <div class="box box-info">  
        <form action = "<?php echo $action; ?>" class="form-horizontal" method="post"  enctype="multipart/form-data" name="form" id="form">
            <input type="hidden" name="back_url" value="">
            <input type="hidden" name="left_menu_add_loan" value="">
            <input type="hidden" name="borrower_id" value="">
            <input type="hidden" name="add_loan" value=""><script type="text/javascript" src="add_edit_loan_updated.js"></script>
            <div class="box-body">
                    <div class="form-group">
                        <label for="inputBorrowerId" class="col-sm-3 control-label">Borrower</label>                      
                        <div class="col-sm-5">
                            <select data-placeholder="Choose Borrower or Search by Name"  class="form-control select2" name="borrowers_id" id="inputBorrowerId" style="width: 100%;" required>
                                <option></option>
                                  <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
    <script src="<?php echo base_url()."assets/";?>select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });
    </script>
                            </select>
                        </div>
                    </div>
                    
                <div class="form-group">
                    <label for="inputLoanType"  class="col-sm-3 control-label">Loan Product</label>
                    <div class="col-sm-3">
                        <select class="form-control" name="Loan_product_id" id="inputLoanType" >
                          
                          
                             <?php
                                $borrowers_get = $this->db->get('loanproduct')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['Loan_prduct_id'];?>">
                                    <?php echo $row['Loan_prduct_name'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
                         
                        </select>
                    </div> </div>
                <div class="form-group">
                    
                    <label for="inputLoanApplicationId" class="col-sm-3 control-label">Loan #</label>                      
                    <div class="col-sm-4">
                      
                        <input type="text" name="loan" class="form-control" id="inputLoanApplicationId"  required value="">
                    </div>
                </div>
                <hr>
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Loan Terms (required fields):</div></div>
                <p class="text-red margin"><b>Principal:</b></p>
                <div class="form-group">
                    <label for="inputDisbursedById"  class="col-sm-3 control-label">Disbursed By</label>
                    <div class="col-sm-3">
                        <select class="form-control" name="loan_disbursed_by_id" id="inputDisbursedById" required>
                            <option value="cash" >Cash</option>
                            <option value="cheque" >Cheque</option>
                            
                        </select>
                    </div>  
                    <div class="col-sm-4">
                       
                    </div>           
                </div>
                <div class="form-group">
                    
                    <label for="inputLoanPrincipalAmount" class="col-sm-3 control-label">Principal Amount</label>                      
                    <div class="col-sm-4">
                        <input type="text" name="loan_principal_amount" class="form-control decimal-2-places" id="inputLoanPrincipalAmount" placeholder="Principal Amount" required value="">
                        
                    </div>
                </div>
                
        <script>
        $(function() {
            $('#inputLoanReleasedDate').datepick({
             
            defaultDate: '', showTrigger: '#calImg',
            yearRange: 'c-20:c+20', showTrigger: '#calImg',
            
            dateFormat: 'dd/mm/yyyy',
            minDate: '01/01/1980'
            });
        });
        
        </script>
                <div class="form-group">
                    <label for="inputLoanReleasedDate" class="col-sm-3 control-label">Loan Release Date</label>
                    <div class="col-sm-4">
                        <input type="text" name="loan_released_date" class="form-control" id="inputLoanReleasedDate" placeholder="dd/mm/yyyy" value="" required>
                    </div>
                </div>
                <hr>
                <p class="text-red margin"><b>Interest:</b></p>
                <div class="form-group">
                    <label for="inputLoanInterestMethod" class="col-sm-3 control-label">Interest Method</label>                      
                    <div class="col-sm-4">
                        <select class="form-control" name="loan_interest_method" id="inputLoanInterestMethod" required onChange="enableDisableMethod();">
                            <option value="flat_rate" > Flat Rate</option>
                            <option value="reducing_rate_equal_installments" >Reducing Balance - Equal Installments</option>
                            <option value="reducing_rate_equal_principal" >Reducing Balance - Equal Principal</option>
                            <option value="interest_only" >Interest-Only</option>
                            <option value="compound_interest" >Compound Interest</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputLoanInterestType" class="col-sm-3 control-label">Interest Type</label>  
                    <div class="col-sm-5">
                        <div class="radio">
                            <label>
                              <input type="radio" name="loan_interest_type" id="inputInterestTypePercentage" value="percentage"  onclick="checkITPRRadio()" checked> I want Interest to be percentage % based
                                
                            </label>
                        </div>                       
                        <div class="radio">
                            <label>
                              <input type="radio" name="loan_interest_type" id="inputInterestTypeFixed" value="fixed"  onclick="checkITPRRadio()"> I want Interest to be a fixed amount Per Cycle
                                
                            </label>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputLoanInterest" id="inputLoanInterestLabel" class="col-sm-3 control-label">Loan Interest %</label>                      
                    <div class="col-sm-2">    
                        <input type="text" name="loan_interest" class="form-control decimal-4-places" id="inputLoanInterest" placeholder=" %" value="" required>
                        
                    </div>
                    <div class="col-sm-2">
                        <select class="form-control" name="loan_interest_period" id="inputInterestPeriod" onChange="check();">
                            <option value="Day"  >Per Day</option>
                            <option value="Week"  >Per Week</option>
                            <option value="Month"  >Per Month</option>
                            <option value="Year"  >Per Year</option>
                        </select>
                    </div>             
                </div>
                <hr>
                <p class="text-red margin"><b>Duration:</b></p>
                <div class="form-group">
                    
                    <label for="inputLoanDuration" class="col-sm-3 control-label">Loan Duration</label>                      
                    <div class="col-sm-2">
                        <select class="form-control" name="loan_duration" id="inputLoanDuration"  onChange="setNumofRep();">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                            <option value="16" >16</option>
                            <option value="17" >17</option>
                            <option value="18" >18</option>
                            <option value="19" >19</option>
                            <option value="20" >20</option>
                            <option value="21" >21</option>
                            <option value="22" >22</option>
                            <option value="23" >23</option>
                            <option value="24" >24</option>
                            <option value="25" >25</option>
                            <option value="26" >26</option>
                            <option value="27" >27</option>
                            <option value="28" >28</option>
                            <option value="29" >29</option>
                            <option value="30" >30</option>
                            <option value="31" >31</option>
                            <option value="32" >32</option>
                            <option value="33" >33</option>
                            <option value="34" >34</option>
                            <option value="35" >35</option>
                            <option value="36" >36</option>
                            <option value="37" >37</option>
                            <option value="38" >38</option>
                            <option value="39" >39</option>
                            <option value="40" >40</option>
                            <option value="41" >41</option>
                            <option value="42" >42</option>
                            <option value="43" >43</option>
                            <option value="44" >44</option>
                            <option value="45" >45</option>
                            <option value="46" >46</option>
                            <option value="47" >47</option>
                            <option value="48" >48</option>
                            <option value="49" >49</option>
                            <option value="50" >50</option>
                            <option value="51" >51</option>
                            <option value="52" >52</option>
                            <option value="53" >53</option>
                            <option value="54" >54</option>
                            <option value="55" >55</option>
                            <option value="56" >56</option>
                            <option value="57" >57</option>
                            <option value="58" >58</option>
                            <option value="59" >59</option>
                            <option value="60" >60</option>
                            <option value="61" >61</option>
                            <option value="62" >62</option>
                            <option value="63" >63</option>
                            <option value="64" >64</option>
                            <option value="65" >65</option>
                            <option value="66" >66</option>
                            <option value="67" >67</option>
                            <option value="68" >68</option>
                            <option value="69" >69</option>
                            <option value="70" >70</option>
                            <option value="71" >71</option>
                            <option value="72" >72</option>
                            <option value="73" >73</option>
                            <option value="74" >74</option>
                            <option value="75" >75</option>
                            <option value="76" >76</option>
                            <option value="77" >77</option>
                            <option value="78" >78</option>
                            <option value="79" >79</option>
                            <option value="80" >80</option>
                            <option value="81" >81</option>
                            <option value="82" >82</option>
                            <option value="83" >83</option>
                            <option value="84" >84</option>
                            <option value="85" >85</option>
                            <option value="86" >86</option>
                            <option value="87" >87</option>
                            <option value="88" >88</option>
                            <option value="89" >89</option>
                            <option value="90" >90</option>
                            <option value="91" >91</option>
                            <option value="92" >92</option>
                            <option value="93" >93</option>
                            <option value="94" >94</option>
                            <option value="95" >95</option>
                            <option value="96" >96</option>
                            <option value="97" >97</option>
                            <option value="98" >98</option>
                            <option value="99" >99</option>
                            <option value="100" >100</option>
                            <option value="101" >101</option>
                            <option value="102" >102</option>
                            <option value="103" >103</option>
                            <option value="104" >104</option>
                            <option value="105" >105</option>
                            <option value="106" >106</option>
                            <option value="107" >107</option>
                            <option value="108" >108</option>
                            <option value="109" >109</option>
                            <option value="110" >110</option>
                            <option value="111" >111</option>
                            <option value="112" >112</option>
                            <option value="113" >113</option>
                            <option value="114" >114</option>
                            <option value="115" >115</option>
                            <option value="116" >116</option>
                            <option value="117" >117</option>
                            <option value="118" >118</option>
                            <option value="119" >119</option>
                            <option value="120" >120</option>
                            <option value="121" >121</option>
                            <option value="122" >122</option>
                            <option value="123" >123</option>
                            <option value="124" >124</option>
                            <option value="125" >125</option>
                            <option value="126" >126</option>
                            <option value="127" >127</option>
                            <option value="128" >128</option>
                            <option value="129" >129</option>
                            <option value="130" >130</option>
                            <option value="131" >131</option>
                            <option value="132" >132</option>
                            <option value="133" >133</option>
                            <option value="134" >134</option>
                            <option value="135" >135</option>
                            <option value="136" >136</option>
                            <option value="137" >137</option>
                            <option value="138" >138</option>
                            <option value="139" >139</option>
                            <option value="140" >140</option>
                            <option value="141" >141</option>
                            <option value="142" >142</option>
                            <option value="143" >143</option>
                            <option value="144" >144</option>
                            <option value="145" >145</option>
                            <option value="146" >146</option>
                            <option value="147" >147</option>
                            <option value="148" >148</option>
                            <option value="149" >149</option>
                            <option value="150" >150</option>
                            <option value="151" >151</option>
                            <option value="152" >152</option>
                            <option value="153" >153</option>
                            <option value="154" >154</option>
                            <option value="155" >155</option>
                            <option value="156" >156</option>
                            <option value="157" >157</option>
                            <option value="158" >158</option>
                            <option value="159" >159</option>
                            <option value="160" >160</option>
                            <option value="161" >161</option>
                            <option value="162" >162</option>
                            <option value="163" >163</option>
                            <option value="164" >164</option>
                            <option value="165" >165</option>
                            <option value="166" >166</option>
                            <option value="167" >167</option>
                            <option value="168" >168</option>
                            <option value="169" >169</option>
                            <option value="170" >170</option>
                            <option value="171" >171</option>
                            <option value="172" >172</option>
                            <option value="173" >173</option>
                            <option value="174" >174</option>
                            <option value="175" >175</option>
                            <option value="176" >176</option>
                            <option value="177" >177</option>
                            <option value="178" >178</option>
                            <option value="179" >179</option>
                            <option value="180" >180</option>
                            <option value="181" >181</option>
                            <option value="182" >182</option>
                            <option value="183" >183</option>
                            <option value="184" >184</option>
                            <option value="185" >185</option>
                            <option value="186" >186</option>
                            <option value="187" >187</option>
                            <option value="188" >188</option>
                            <option value="189" >189</option>
                            <option value="190" >190</option>
                            <option value="191" >191</option>
                            <option value="192" >192</option>
                            <option value="193" >193</option>
                            <option value="194" >194</option>
                            <option value="195" >195</option>
                            <option value="196" >196</option>
                            <option value="197" >197</option>
                            <option value="198" >198</option>
                            <option value="199" >199</option>
                            <option value="200" >200</option>
                            <option value="201" >201</option>
                            <option value="202" >202</option>
                            <option value="203" >203</option>
                            <option value="204" >204</option>
                            <option value="205" >205</option>
                            <option value="206" >206</option>
                            <option value="207" >207</option>
                            <option value="208" >208</option>
                            <option value="209" >209</option>
                            <option value="210" >210</option>
                            <option value="211" >211</option>
                            <option value="212" >212</option>
                            <option value="213" >213</option>
                            <option value="214" >214</option>
                            <option value="215" >215</option>
                            <option value="216" >216</option>
                            <option value="217" >217</option>
                            <option value="218" >218</option>
                            <option value="219" >219</option>
                            <option value="220" >220</option>
                            <option value="221" >221</option>
                            <option value="222" >222</option>
                            <option value="223" >223</option>
                            <option value="224" >224</option>
                            <option value="225" >225</option>
                            <option value="226" >226</option>
                            <option value="227" >227</option>
                            <option value="228" >228</option>
                            <option value="229" >229</option>
                            <option value="230" >230</option>
                            <option value="231" >231</option>
                            <option value="232" >232</option>
                            <option value="233" >233</option>
                            <option value="234" >234</option>
                            <option value="235" >235</option>
                            <option value="236" >236</option>
                            <option value="237" >237</option>
                            <option value="238" >238</option>
                            <option value="239" >239</option>
                            <option value="240" >240</option>
                            <option value="241" >241</option>
                            <option value="242" >242</option>
                            <option value="243" >243</option>
                            <option value="244" >244</option>
                            <option value="245" >245</option>
                            <option value="246" >246</option>
                            <option value="247" >247</option>
                            <option value="248" >248</option>
                            <option value="249" >249</option>
                            <option value="250" >250</option>
                            <option value="251" >251</option>
                            <option value="252" >252</option>
                            <option value="253" >253</option>
                            <option value="254" >254</option>
                            <option value="255" >255</option>
                            <option value="256" >256</option>
                            <option value="257" >257</option>
                            <option value="258" >258</option>
                            <option value="259" >259</option>
                            <option value="260" >260</option>
                            <option value="261" >261</option>
                            <option value="262" >262</option>
                            <option value="263" >263</option>
                            <option value="264" >264</option>
                            <option value="265" >265</option>
                            <option value="266" >266</option>
                            <option value="267" >267</option>
                            <option value="268" >268</option>
                            <option value="269" >269</option>
                            <option value="270" >270</option>
                            <option value="271" >271</option>
                            <option value="272" >272</option>
                            <option value="273" >273</option>
                            <option value="274" >274</option>
                            <option value="275" >275</option>
                            <option value="276" >276</option>
                            <option value="277" >277</option>
                            <option value="278" >278</option>
                            <option value="279" >279</option>
                            <option value="280" >280</option>
                            <option value="281" >281</option>
                            <option value="282" >282</option>
                            <option value="283" >283</option>
                            <option value="284" >284</option>
                            <option value="285" >285</option>
                            <option value="286" >286</option>
                            <option value="287" >287</option>
                            <option value="288" >288</option>
                            <option value="289" >289</option>
                            <option value="290" >290</option>
                            <option value="291" >291</option>
                            <option value="292" >292</option>
                            <option value="293" >293</option>
                            <option value="294" >294</option>
                            <option value="295" >295</option>
                            <option value="296" >296</option>
                            <option value="297" >297</option>
                            <option value="298" >298</option>
                            <option value="299" >299</option>
                            <option value="300" >300</option>
                            <option value="301" >301</option>
                            <option value="302" >302</option>
                            <option value="303" >303</option>
                            <option value="304" >304</option>
                            <option value="305" >305</option>
                            <option value="306" >306</option>
                            <option value="307" >307</option>
                            <option value="308" >308</option>
                            <option value="309" >309</option>
                            <option value="310" >310</option>
                            <option value="311" >311</option>
                            <option value="312" >312</option>
                            <option value="313" >313</option>
                            <option value="314" >314</option>
                            <option value="315" >315</option>
                            <option value="316" >316</option>
                            <option value="317" >317</option>
                            <option value="318" >318</option>
                            <option value="319" >319</option>
                            <option value="320" >320</option>
                            <option value="321" >321</option>
                            <option value="322" >322</option>
                            <option value="323" >323</option>
                            <option value="324" >324</option>
                            <option value="325" >325</option>
                            <option value="326" >326</option>
                            <option value="327" >327</option>
                            <option value="328" >328</option>
                            <option value="329" >329</option>
                            <option value="330" >330</option>
                            <option value="331" >331</option>
                            <option value="332" >332</option>
                            <option value="333" >333</option>
                            <option value="334" >334</option>
                            <option value="335" >335</option>
                            <option value="336" >336</option>
                            <option value="337" >337</option>
                            <option value="338" >338</option>
                            <option value="339" >339</option>
                            <option value="340" >340</option>
                            <option value="341" >341</option>
                            <option value="342" >342</option>
                            <option value="343" >343</option>
                            <option value="344" >344</option>
                            <option value="345" >345</option>
                            <option value="346" >346</option>
                            <option value="347" >347</option>
                            <option value="348" >348</option>
                            <option value="349" >349</option>
                            <option value="350" >350</option>
                            <option value="351" >351</option>
                            <option value="352" >352</option>
                            <option value="353" >353</option>
                            <option value="354" >354</option>
                            <option value="355" >355</option>
                            <option value="356" >356</option>
                            <option value="357" >357</option>
                            <option value="358" >358</option>
                            <option value="359" >359</option>
                            <option value="360" >360</option>
                            <option value="361" >361</option>
                            <option value="362" >362</option>
                            <option value="363" >363</option>
                            <option value="364" >364</option>
                            <option value="365" >365</option>
                        </select>
                        
                        
                     </div>
                     <div class="col-sm-2">
                        <select class="form-control" name="loan_duration_period" id="inputLoanDurationPeriod" required onChange="setNumofRep();">
                            <option value=""></option>
                            <option value="Days"  >Days</option>
                            <option value="Weeks"  >Weeks</option>
                            <option value="Months"  >Months</option>
                            <option value="Years"  >Years</option>
                        </select>
                    </div>
                </div>
                <hr>
                <p class="text-red margin"><b>Repayments:</b></p>
                <div class="form-group">
                    <label for="inputLoanPaymentSchemeId"  class="col-sm-3 control-label">Repayment Cycle</label>
                    <div class="col-sm-2">
                        <select class="form-control" name="loan_payment_scheme_id" id="inputLoanPaymentSchemeId" required onChange=" disableNumRepayments(); setNumofRep();">
                            <option value=""></option>
                            <option value="6" >Daily</option>
                            <option value="4" >Weekly</option>
                            <option value="9" >Biweekly</option>
                            <option value="3" >Monthly</option>
                            <option value="12" >Bimonthly</option>
                            <option value="13" >Quarterly</option>
                            <option value="14" >Semi-Annual</option>
                            <option value="11" >Yearly</option>
                            <option value="10" >Lump-Sum</option>
                        </select>
                    </div>
                    
                    
                
                
                <div class="form-group">
                    <label for="inputLoanNumOfRepayments" class="col-sm-3 control-label">Number of Repayments</label>                      
                    <div class="col-sm-2">
                        <select class="form-control" name="loan_num_of_repayments" id="inputLoanNumOfRepayments" required onChange="removeNumRepaymentsMessage()">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                            <option value="16" >16</option>
                            <option value="17" >17</option>
                            <option value="18" >18</option>
                            <option value="19" >19</option>
                            <option value="20" >20</option>
                            <option value="21" >21</option>
                            <option value="22" >22</option>
                            <option value="23" >23</option>
                            <option value="24" >24</option>
                            <option value="25" >25</option>
                            <option value="26" >26</option>
                            <option value="27" >27</option>
                            <option value="28" >28</option>
                            <option value="29" >29</option>
                            <option value="30" >30</option>
                            <option value="31" >31</option>
                            <option value="32" >32</option>
                            <option value="33" >33</option>
                            <option value="34" >34</option>
                            <option value="35" >35</option>
                            <option value="36" >36</option>
                            <option value="37" >37</option>
                            <option value="38" >38</option>
                            <option value="39" >39</option>
                            <option value="40" >40</option>
                            <option value="41" >41</option>
                            <option value="42" >42</option>
                            <option value="43" >43</option>
                            <option value="44" >44</option>
                            <option value="45" >45</option>
                            <option value="46" >46</option>
                            <option value="47" >47</option>
                            <option value="48" >48</option>
                            <option value="49" >49</option>
                            <option value="50" >50</option>
                            <option value="51" >51</option>
                            <option value="52" >52</option>
                            <option value="53" >53</option>
                            <option value="54" >54</option>
                            <option value="55" >55</option>
                            <option value="56" >56</option>
                            <option value="57" >57</option>
                            <option value="58" >58</option>
                            <option value="59" >59</option>
                            <option value="60" >60</option>
                            <option value="61" >61</option>
                            <option value="62" >62</option>
                            <option value="63" >63</option>
                            <option value="64" >64</option>
                            <option value="65" >65</option>
                            <option value="66" >66</option>
                            <option value="67" >67</option>
                            <option value="68" >68</option>
                            <option value="69" >69</option>
                            <option value="70" >70</option>
                            <option value="71" >71</option>
                            <option value="72" >72</option>
                            <option value="73" >73</option>
                            <option value="74" >74</option>
                            <option value="75" >75</option>
                            <option value="76" >76</option>
                            <option value="77" >77</option>
                            <option value="78" >78</option>
                            <option value="79" >79</option>
                            <option value="80" >80</option>
                            <option value="81" >81</option>
                            <option value="82" >82</option>
                            <option value="83" >83</option>
                            <option value="84" >84</option>
                            <option value="85" >85</option>
                            <option value="86" >86</option>
                            <option value="87" >87</option>
                            <option value="88" >88</option>
                            <option value="89" >89</option>
                            <option value="90" >90</option>
                            <option value="91" >91</option>
                            <option value="92" >92</option>
                            <option value="93" >93</option>
                            <option value="94" >94</option>
                            <option value="95" >95</option>
                            <option value="96" >96</option>
                            <option value="97" >97</option>
                            <option value="98" >98</option>
                            <option value="99" >99</option>
                            <option value="100" >100</option>
                            <option value="101" >101</option>
                            <option value="102" >102</option>
                            <option value="103" >103</option>
                            <option value="104" >104</option>
                            <option value="105" >105</option>
                            <option value="106" >106</option>
                            <option value="107" >107</option>
                            <option value="108" >108</option>
                            <option value="109" >109</option>
                            <option value="110" >110</option>
                            <option value="111" >111</option>
                            <option value="112" >112</option>
                            <option value="113" >113</option>
                            <option value="114" >114</option>
                            <option value="115" >115</option>
                            <option value="116" >116</option>
                            <option value="117" >117</option>
                            <option value="118" >118</option>
                            <option value="119" >119</option>
                            <option value="120" >120</option>
                            <option value="121" >121</option>
                            <option value="122" >122</option>
                            <option value="123" >123</option>
                            <option value="124" >124</option>
                            <option value="125" >125</option>
                            <option value="126" >126</option>
                            <option value="127" >127</option>
                            <option value="128" >128</option>
                            <option value="129" >129</option>
                            <option value="130" >130</option>
                            <option value="131" >131</option>
                            <option value="132" >132</option>
                            <option value="133" >133</option>
                            <option value="134" >134</option>
                            <option value="135" >135</option>
                            <option value="136" >136</option>
                            <option value="137" >137</option>
                            <option value="138" >138</option>
                            <option value="139" >139</option>
                            <option value="140" >140</option>
                            <option value="141" >141</option>
                            <option value="142" >142</option>
                            <option value="143" >143</option>
                            <option value="144" >144</option>
                            <option value="145" >145</option>
                            <option value="146" >146</option>
                            <option value="147" >147</option>
                            <option value="148" >148</option>
                            <option value="149" >149</option>
                            <option value="150" >150</option>
                            <option value="151" >151</option>
                            <option value="152" >152</option>
                            <option value="153" >153</option>
                            <option value="154" >154</option>
                            <option value="155" >155</option>
                            <option value="156" >156</option>
                            <option value="157" >157</option>
                            <option value="158" >158</option>
                            <option value="159" >159</option>
                            <option value="160" >160</option>
                            <option value="161" >161</option>
                            <option value="162" >162</option>
                            <option value="163" >163</option>
                            <option value="164" >164</option>
                            <option value="165" >165</option>
                            <option value="166" >166</option>
                            <option value="167" >167</option>
                            <option value="168" >168</option>
                            <option value="169" >169</option>
                            <option value="170" >170</option>
                            <option value="171" >171</option>
                            <option value="172" >172</option>
                            <option value="173" >173</option>
                            <option value="174" >174</option>
                            <option value="175" >175</option>
                            <option value="176" >176</option>
                            <option value="177" >177</option>
                            <option value="178" >178</option>
                            <option value="179" >179</option>
                            <option value="180" >180</option>
                            <option value="181" >181</option>
                            <option value="182" >182</option>
                            <option value="183" >183</option>
                            <option value="184" >184</option>
                            <option value="185" >185</option>
                            <option value="186" >186</option>
                            <option value="187" >187</option>
                            <option value="188" >188</option>
                            <option value="189" >189</option>
                            <option value="190" >190</option>
                            <option value="191" >191</option>
                            <option value="192" >192</option>
                            <option value="193" >193</option>
                            <option value="194" >194</option>
                            <option value="195" >195</option>
                            <option value="196" >196</option>
                            <option value="197" >197</option>
                            <option value="198" >198</option>
                            <option value="199" >199</option>
                            <option value="200" >200</option>
                            <option value="201" >201</option>
                            <option value="202" >202</option>
                            <option value="203" >203</option>
                            <option value="204" >204</option>
                            <option value="205" >205</option>
                            <option value="206" >206</option>
                            <option value="207" >207</option>
                            <option value="208" >208</option>
                            <option value="209" >209</option>
                            <option value="210" >210</option>
                            <option value="211" >211</option>
                            <option value="212" >212</option>
                            <option value="213" >213</option>
                            <option value="214" >214</option>
                            <option value="215" >215</option>
                            <option value="216" >216</option>
                            <option value="217" >217</option>
                            <option value="218" >218</option>
                            <option value="219" >219</option>
                            <option value="220" >220</option>
                            <option value="221" >221</option>
                            <option value="222" >222</option>
                            <option value="223" >223</option>
                            <option value="224" >224</option>
                            <option value="225" >225</option>
                            <option value="226" >226</option>
                            <option value="227" >227</option>
                            <option value="228" >228</option>
                            <option value="229" >229</option>
                            <option value="230" >230</option>
                            <option value="231" >231</option>
                            <option value="232" >232</option>
                            <option value="233" >233</option>
                            <option value="234" >234</option>
                            <option value="235" >235</option>
                            <option value="236" >236</option>
                            <option value="237" >237</option>
                            <option value="238" >238</option>
                            <option value="239" >239</option>
                            <option value="240" >240</option>
                            <option value="241" >241</option>
                            <option value="242" >242</option>
                            <option value="243" >243</option>
                            <option value="244" >244</option>
                            <option value="245" >245</option>
                            <option value="246" >246</option>
                            <option value="247" >247</option>
                            <option value="248" >248</option>
                            <option value="249" >249</option>
                            <option value="250" >250</option>
                            <option value="251" >251</option>
                            <option value="252" >252</option>
                            <option value="253" >253</option>
                            <option value="254" >254</option>
                            <option value="255" >255</option>
                            <option value="256" >256</option>
                            <option value="257" >257</option>
                            <option value="258" >258</option>
                            <option value="259" >259</option>
                            <option value="260" >260</option>
                            <option value="261" >261</option>
                            <option value="262" >262</option>
                            <option value="263" >263</option>
                            <option value="264" >264</option>
                            <option value="265" >265</option>
                            <option value="266" >266</option>
                            <option value="267" >267</option>
                            <option value="268" >268</option>
                            <option value="269" >269</option>
                            <option value="270" >270</option>
                            <option value="271" >271</option>
                            <option value="272" >272</option>
                            <option value="273" >273</option>
                            <option value="274" >274</option>
                            <option value="275" >275</option>
                            <option value="276" >276</option>
                            <option value="277" >277</option>
                            <option value="278" >278</option>
                            <option value="279" >279</option>
                            <option value="280" >280</option>
                            <option value="281" >281</option>
                            <option value="282" >282</option>
                            <option value="283" >283</option>
                            <option value="284" >284</option>
                            <option value="285" >285</option>
                            <option value="286" >286</option>
                            <option value="287" >287</option>
                            <option value="288" >288</option>
                            <option value="289" >289</option>
                            <option value="290" >290</option>
                            <option value="291" >291</option>
                            <option value="292" >292</option>
                            <option value="293" >293</option>
                            <option value="294" >294</option>
                            <option value="295" >295</option>
                            <option value="296" >296</option>
                            <option value="297" >297</option>
                            <option value="298" >298</option>
                            <option value="299" >299</option>
                            <option value="300" >300</option>
                            <option value="301" >301</option>
                            <option value="302" >302</option>
                            <option value="303" >303</option>
                            <option value="304" >304</option>
                            <option value="305" >305</option>
                            <option value="306" >306</option>
                            <option value="307" >307</option>
                            <option value="308" >308</option>
                            <option value="309" >309</option>
                            <option value="310" >310</option>
                            <option value="311" >311</option>
                            <option value="312" >312</option>
                            <option value="313" >313</option>
                            <option value="314" >314</option>
                            <option value="315" >315</option>
                            <option value="316" >316</option>
                            <option value="317" >317</option>
                            <option value="318" >318</option>
                            <option value="319" >319</option>
                            <option value="320" >320</option>
                            <option value="321" >321</option>
                            <option value="322" >322</option>
                            <option value="323" >323</option>
                            <option value="324" >324</option>
                            <option value="325" >325</option>
                            <option value="326" >326</option>
                            <option value="327" >327</option>
                            <option value="328" >328</option>
                            <option value="329" >329</option>
                            <option value="330" >330</option>
                            <option value="331" >331</option>
                            <option value="332" >332</option>
                            <option value="333" >333</option>
                            <option value="334" >334</option>
                            <option value="335" >335</option>
                            <option value="336" >336</option>
                            <option value="337" >337</option>
                            <option value="338" >338</option>
                            <option value="339" >339</option>
                            <option value="340" >340</option>
                            <option value="341" >341</option>
                            <option value="342" >342</option>
                            <option value="343" >343</option>
                            <option value="344" >344</option>
                            <option value="345" >345</option>
                            <option value="346" >346</option>
                            <option value="347" >347</option>
                            <option value="348" >348</option>
                            <option value="349" >349</option>
                            <option value="350" >350</option>
                            <option value="351" >351</option>
                            <option value="352" >352</option>
                            <option value="353" >353</option>
                            <option value="354" >354</option>
                            <option value="355" >355</option>
                            <option value="356" >356</option>
                            <option value="357" >357</option>
                            <option value="358" >358</option>
                            <option value="359" >359</option>
                            <option value="360" >360</option>
                            <option value="361" >361</option>
                            <option value="362" >362</option>
                            <option value="363" >363</option>
                            <option value="364" >364</option>
                            <option value="365" >365</option>
                            <option value="366" >366</option>
                            <option value="367" >367</option>
                            <option value="368" >368</option>
                            <option value="369" >369</option>
                            <option value="370" >370</option>
                            <option value="371" >371</option>
                            <option value="372" >372</option>
                            <option value="373" >373</option>
                            <option value="374" >374</option>
                            <option value="375" >375</option>
                            <option value="376" >376</option>
                            <option value="377" >377</option>
                            <option value="378" >378</option>
                            <option value="379" >379</option>
                            <option value="380" >380</option>
                            <option value="381" >381</option>
                            <option value="382" >382</option>
                            <option value="383" >383</option>
                            <option value="384" >384</option>
                            <option value="385" >385</option>
                            <option value="386" >386</option>
                            <option value="387" >387</option>
                            <option value="388" >388</option>
                            <option value="389" >389</option>
                            <option value="390" >390</option>
                            <option value="391" >391</option>
                            <option value="392" >392</option>
                            <option value="393" >393</option>
                            <option value="394" >394</option>
                            <option value="395" >395</option>
                            <option value="396" >396</option>
                            <option value="397" >397</option>
                            <option value="398" >398</option>
                            <option value="399" >399</option>
                            <option value="400" >400</option>
                            <option value="401" >401</option>
                            <option value="402" >402</option>
                            <option value="403" >403</option>
                            <option value="404" >404</option>
                            <option value="405" >405</option>
                            <option value="406" >406</option>
                            <option value="407" >407</option>
                            <option value="408" >408</option>
                            <option value="409" >409</option>
                            <option value="410" >410</option>
                            <option value="411" >411</option>
                            <option value="412" >412</option>
                            <option value="413" >413</option>
                            <option value="414" >414</option>
                            <option value="415" >415</option>
                            <option value="416" >416</option>
                            <option value="417" >417</option>
                            <option value="418" >418</option>
                            <option value="419" >419</option>
                            <option value="420" >420</option>
                            <option value="421" >421</option>
                            <option value="422" >422</option>
                            <option value="423" >423</option>
                            <option value="424" >424</option>
                            <option value="425" >425</option>
                            <option value="426" >426</option>
                            <option value="427" >427</option>
                            <option value="428" >428</option>
                            <option value="429" >429</option>
                            <option value="430" >430</option>
                            <option value="431" >431</option>
                            <option value="432" >432</option>
                            <option value="433" >433</option>
                            <option value="434" >434</option>
                            <option value="435" >435</option>
                            <option value="436" >436</option>
                            <option value="437" >437</option>
                            <option value="438" >438</option>
                            <option value="439" >439</option>
                            <option value="440" >440</option>
                            <option value="441" >441</option>
                            <option value="442" >442</option>
                            <option value="443" >443</option>
                            <option value="444" >444</option>
                            <option value="445" >445</option>
                            <option value="446" >446</option>
                            <option value="447" >447</option>
                            <option value="448" >448</option>
                            <option value="449" >449</option>
                            <option value="450" >450</option>
                            <option value="451" >451</option>
                            <option value="452" >452</option>
                            <option value="453" >453</option>
                            <option value="454" >454</option>
                            <option value="455" >455</option>
                            <option value="456" >456</option>
                            <option value="457" >457</option>
                            <option value="458" >458</option>
                            <option value="459" >459</option>
                            <option value="460" >460</option>
                            <option value="461" >461</option>
                            <option value="462" >462</option>
                            <option value="463" >463</option>
                            <option value="464" >464</option>
                            <option value="465" >465</option>
                            <option value="466" >466</option>
                            <option value="467" >467</option>
                            <option value="468" >468</option>
                            <option value="469" >469</option>
                            <option value="470" >470</option>
                            <option value="471" >471</option>
                            <option value="472" >472</option>
                            <option value="473" >473</option>
                            <option value="474" >474</option>
                            <option value="475" >475</option>
                            <option value="476" >476</option>
                            <option value="477" >477</option>
                            <option value="478" >478</option>
                            <option value="479" >479</option>
                            <option value="480" >480</option>
                            <option value="481" >481</option>
                            <option value="482" >482</option>
                            <option value="483" >483</option>
                            <option value="484" >484</option>
                            <option value="485" >485</option>
                            <option value="486" >486</option>
                            <option value="487" >487</option>
                            <option value="488" >488</option>
                            <option value="489" >489</option>
                            <option value="490" >490</option>
                            <option value="491" >491</option>
                            <option value="492" >492</option>
                            <option value="493" >493</option>
                            <option value="494" >494</option>
                            <option value="495" >495</option>
                            <option value="496" >496</option>
                            <option value="497" >497</option>
                            <option value="498" >498</option>
                            <option value="499" >499</option>
                            <option value="500" >500</option>
                            <option value="501" >501</option>
                            <option value="502" >502</option>
                            <option value="503" >503</option>
                            <option value="504" >504</option>
                            <option value="505" >505</option>
                            <option value="506" >506</option>
                            <option value="507" >507</option>
                            <option value="508" >508</option>
                            <option value="509" >509</option>
                            <option value="510" >510</option>
                            <option value="511" >511</option>
                            <option value="512" >512</option>
                            <option value="513" >513</option>
                            <option value="514" >514</option>
                            <option value="515" >515</option>
                            <option value="516" >516</option>
                            <option value="517" >517</option>
                            <option value="518" >518</option>
                            <option value="519" >519</option>
                            <option value="520" >520</option>
                            <option value="521" >521</option>
                            <option value="522" >522</option>
                            <option value="523" >523</option>
                            <option value="524" >524</option>
                            <option value="525" >525</option>
                            <option value="526" >526</option>
                            <option value="527" >527</option>
                            <option value="528" >528</option>
                            <option value="529" >529</option>
                            <option value="530" >530</option>
                            <option value="531" >531</option>
                            <option value="532" >532</option>
                            <option value="533" >533</option>
                            <option value="534" >534</option>
                            <option value="535" >535</option>
                            <option value="536" >536</option>
                            <option value="537" >537</option>
                            <option value="538" >538</option>
                            <option value="539" >539</option>
                            <option value="540" >540</option>
                            <option value="541" >541</option>
                            <option value="542" >542</option>
                            <option value="543" >543</option>
                            <option value="544" >544</option>
                            <option value="545" >545</option>
                            <option value="546" >546</option>
                            <option value="547" >547</option>
                            <option value="548" >548</option>
                            <option value="549" >549</option>
                            <option value="550" >550</option>
                            <option value="551" >551</option>
                            <option value="552" >552</option>
                            <option value="553" >553</option>
                            <option value="554" >554</option>
                            <option value="555" >555</option>
                            <option value="556" >556</option>
                            <option value="557" >557</option>
                            <option value="558" >558</option>
                            <option value="559" >559</option>
                            <option value="560" >560</option>
                            <option value="561" >561</option>
                            <option value="562" >562</option>
                            <option value="563" >563</option>
                            <option value="564" >564</option>
                            <option value="565" >565</option>
                            <option value="566" >566</option>
                            <option value="567" >567</option>
                            <option value="568" >568</option>
                            <option value="569" >569</option>
                            <option value="570" >570</option>
                            <option value="571" >571</option>
                            <option value="572" >572</option>
                            <option value="573" >573</option>
                            <option value="574" >574</option>
                            <option value="575" >575</option>
                            <option value="576" >576</option>
                            <option value="577" >577</option>
                            <option value="578" >578</option>
                            <option value="579" >579</option>
                            <option value="580" >580</option>
                            <option value="581" >581</option>
                            <option value="582" >582</option>
                            <option value="583" >583</option>
                            <option value="584" >584</option>
                            <option value="585" >585</option>
                            <option value="586" >586</option>
                            <option value="587" >587</option>
                            <option value="588" >588</option>
                            <option value="589" >589</option>
                            <option value="590" >590</option>
                            <option value="591" >591</option>
                            <option value="592" >592</option>
                            <option value="593" >593</option>
                            <option value="594" >594</option>
                            <option value="595" >595</option>
                            <option value="596" >596</option>
                            <option value="597" >597</option>
                            <option value="598" >598</option>
                            <option value="599" >599</option>
                            <option value="600" >600</option>
                            <option value="601" >601</option>
                            <option value="602" >602</option>
                            <option value="603" >603</option>
                            <option value="604" >604</option>
                            <option value="605" >605</option>
                            <option value="606" >606</option>
                            <option value="607" >607</option>
                            <option value="608" >608</option>
                            <option value="609" >609</option>
                            <option value="610" >610</option>
                            <option value="611" >611</option>
                            <option value="612" >612</option>
                            <option value="613" >613</option>
                            <option value="614" >614</option>
                            <option value="615" >615</option>
                            <option value="616" >616</option>
                            <option value="617" >617</option>
                            <option value="618" >618</option>
                            <option value="619" >619</option>
                            <option value="620" >620</option>
                            <option value="621" >621</option>
                            <option value="622" >622</option>
                            <option value="623" >623</option>
                            <option value="624" >624</option>
                            <option value="625" >625</option>
                            <option value="626" >626</option>
                            <option value="627" >627</option>
                            <option value="628" >628</option>
                            <option value="629" >629</option>
                            <option value="630" >630</option>
                            <option value="631" >631</option>
                            <option value="632" >632</option>
                            <option value="633" >633</option>
                            <option value="634" >634</option>
                            <option value="635" >635</option>
                            <option value="636" >636</option>
                            <option value="637" >637</option>
                            <option value="638" >638</option>
                            <option value="639" >639</option>
                            <option value="640" >640</option>
                            <option value="641" >641</option>
                            <option value="642" >642</option>
                            <option value="643" >643</option>
                            <option value="644" >644</option>
                            <option value="645" >645</option>
                            <option value="646" >646</option>
                            <option value="647" >647</option>
                            <option value="648" >648</option>
                            <option value="649" >649</option>
                            <option value="650" >650</option>
                            <option value="651" >651</option>
                            <option value="652" >652</option>
                            <option value="653" >653</option>
                            <option value="654" >654</option>
                            <option value="655" >655</option>
                            <option value="656" >656</option>
                            <option value="657" >657</option>
                            <option value="658" >658</option>
                            <option value="659" >659</option>
                            <option value="660" >660</option>
                            <option value="661" >661</option>
                            <option value="662" >662</option>
                            <option value="663" >663</option>
                            <option value="664" >664</option>
                            <option value="665" >665</option>
                            <option value="666" >666</option>
                            <option value="667" >667</option>
                            <option value="668" >668</option>
                            <option value="669" >669</option>
                            <option value="670" >670</option>
                            <option value="671" >671</option>
                            <option value="672" >672</option>
                            <option value="673" >673</option>
                            <option value="674" >674</option>
                            <option value="675" >675</option>
                            <option value="676" >676</option>
                            <option value="677" >677</option>
                            <option value="678" >678</option>
                            <option value="679" >679</option>
                            <option value="680" >680</option>
                            <option value="681" >681</option>
                            <option value="682" >682</option>
                            <option value="683" >683</option>
                            <option value="684" >684</option>
                            <option value="685" >685</option>
                            <option value="686" >686</option>
                            <option value="687" >687</option>
                            <option value="688" >688</option>
                            <option value="689" >689</option>
                            <option value="690" >690</option>
                            <option value="691" >691</option>
                            <option value="692" >692</option>
                            <option value="693" >693</option>
                            <option value="694" >694</option>
                            <option value="695" >695</option>
                            <option value="696" >696</option>
                            <option value="697" >697</option>
                            <option value="698" >698</option>
                            <option value="699" >699</option>
                            <option value="700" >700</option>
                            <option value="701" >701</option>
                            <option value="702" >702</option>
                            <option value="703" >703</option>
                            <option value="704" >704</option>
                            <option value="705" >705</option>
                            <option value="706" >706</option>
                            <option value="707" >707</option>
                            <option value="708" >708</option>
                            <option value="709" >709</option>
                            <option value="710" >710</option>
                            <option value="711" >711</option>
                            <option value="712" >712</option>
                            <option value="713" >713</option>
                            <option value="714" >714</option>
                            <option value="715" >715</option>
                            <option value="716" >716</option>
                            <option value="717" >717</option>
                            <option value="718" >718</option>
                            <option value="719" >719</option>
                            <option value="720" >720</option>
                        </select>
                        
                    </div>
                    
                    <div class="col-sm-2" id="inputLoanNumOfRepaymentsChanged">
                    </div>
                </div>
               
                <script>
                $(document).ready(function () {                
                   $(".slidingDivAdvanceSettings").hide();                      
                  $('.show_hide_advance_settings').click(function (e) {
                    $(".slidingDivAdvanceSettings").slideToggle("fast");
                    var val = $(this).text() == "Hide" ? "Show" : "Hide";
                    $(this).hide().text(val).fadeIn("fast");
                    e.preventDefault();
                  });
                });
                </script>
                <hr>
                
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Advance Settings: <a href="#" class="show_hide_advance_settings">Show</a></div></div>
                <div class="slidingDivAdvanceSettings" style="display: none;">
                    <p>These are <u>optional</u> fields</p>
                    <div class="form-group">
                        <label for="inputLoanDecimalPlaces" class="col-sm-3 control-label">Decimal Places</label>                      
                        <div class="col-sm-4">
                            <select class="form-control" name="loan_decimal_places" id="inputLoanDecimalPlaces">
                                <option value="round_off_to_two_decimal" >Round Off to 2 Decimal Places</option>
                                <option value="round_off_to_integer" >Round Off to Integer</option>
                            </select>
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#decimal_places">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="decimal_places" class="collapse">
                                <p><u><strong>Decimal Places</strong></u>
                                    <br>This is an optional field. Select if the repayment amounts should be calculated/shown in decimals or as integers (whole amounts without decimals). You can select from</p>

                                <ul>
                                    <li><strong>Round Off to 2 Decimal Places</strong>
                                        <br>- This is the default option. For example 2.359 will be rounded off to 2.36</li>
                                    <li><strong>Round Off to Integer</strong>
                                        <br>- This will round off the value to an integer. For example 2.539 will be rounded off to 3.00
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     
        <script>
        $(function() {
            $('#inputLoanInterestStartDate').datepick({
             
            defaultDate: '18/09/2017', showTrigger: '#calImg',
            yearRange: 'c-20:c+20', showTrigger: '#calImg',
            
            dateFormat: 'dd/mm/yyyy',
            minDate: '01/01/1980'
            });
        });
        
        </script>
                    <div class="form-group">
                        <label for="inputLoanInterestStartDate" class="col-sm-3 control-label">Interest Start Date</label>
                        <div class="col-sm-4">
                            <input type="text" name="loan_interest_start_date" class="form-control" id="inputLoanInterestStartDate" placeholder="dd/mm/yyyy" value="">
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#loan_interest_start_date">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="loan_interest_start_date" class="collapse">
                                <p><u><strong>Interest Start Date (optional)</strong></u></p>
                                <p>This is an optional field. You can select the date when interest will start to be calculated on the <strong>Principal Amount</strong> above. If you leave this field empty, the interest would start from the <strong>Loan Release Date</strong> selected above.</p>
                                <p>For example, if you select weekly repayment and <b>Loan Release Date</b> is 1st January and you put <b>Interest Start Date</b> as 5th January, then the first repayment would be on 12th January (5+7). But if <b>Interest Start Date</b> is empty, then first repayment would be on 8th Jan (1+7).
                                </p>
                                <p>Some lending companies charge interest at a later date and give a few days interest free at the start of the loan. For example, if you release the loan on the night of 31st January, you might want interest to begin calculating on 1st February since there are only a few hours left in 31st January.</p>
                            </div>
                        </div>
                    </div>
                    
        <script>
        $(function() {
            $('#inputLoanFirstRepaymentDate').datepick({
             
            defaultDate: '18/09/2017', showTrigger: '#calImg',
            yearRange: 'c-20:c+20', showTrigger: '#calImg',
            
            dateFormat: 'dd/mm/yyyy',
            minDate: '01/01/1980'
            });
        });
        
        </script>
                    <div class="form-group">
                        <label for="inputLoanFirstRepaymentDate" class="col-sm-3 control-label">First Repayment Date</label>
                        <div class="col-sm-4">
                            <input type="text" name="loan_first_repayment_date" class="form-control" id="inputLoanFirstRepaymentDate" placeholder="dd/mm/yyyy" value="">
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#loan_first_repayment_date">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="loan_first_repayment_date" class="collapse">
                               <p><u><strong>First Repayment Date (optional)</strong></u>
                               
                               <br>This is an optional field. You can select the date of the first repayment. If you leave this field empty, the first repayment date would be calculated based on the <strong>Repayment Cycle</strong> above.</p>
                                <p>For example, if you select weekly repayment and <b>Loan Release Date</b> is 1st January and you put <b>First Repayment Date</b> as 5th January, then the second repayment would be on 12th January (5+7). But if <b>First Repayment Date</b> is empty, then first repayment would be on 8th Jan (1+7).
                                </p>
                               
                               <p>Some lending companies charge the first repayment at an earlier date to reduce risk. For example, if the <strong>Repayment Cycle</strong> is <strong>Weekly</strong>, then the system would automatically set the repayments every week and the first repayment would be 1 week from the <strong>Loan Release Date&nbsp;</strong> But, you might want the first repayment earlier than 1 week to reduce risk or to follow a certain schedule. If you do select a date here, the repayment schedule will be calculated from the <strong>First Repayment Date</strong>.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        
                        <label for="inputFirstRepaymentAmount" class="col-sm-3 control-label">First Repayment Amount</label>                      
                        <div class="col-sm-4">
                            <input type="text" name="first_repayment_amount" class="form-control decimal-2-places" id="inputFirstRepaymentAmount" placeholder="First Repayment Amount" value=""  >
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#first_repayment_amount">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="first_repayment_amount" class="collapse">
                                <p><u><strong>First Repayment Amount (optional)</strong></u></p>
                                
                                <p>This is an optional field. Only valid for <strong>Flat-Rate</strong> interest method. You can type an amount that will be charged on the first repayment. If you leave this field empty, the first repayment amount would be calculated based on the <strong>Loan Interest</strong> and <strong>Loan Duration</strong> fields above.</p>

                                <p>Some lending companies charge a higher amount on the first repayment to reduce risk. If you do type an amount here, the <strong>First Repayment Amount</strong> will be subtracted from the total loan due amount and the remaining amount will be divided in the repayment cycle as per the <strong>Interest Method</strong> above.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        
                        <label for="inputLastRepaymentAmount" class="col-sm-3 control-label">Last Repayment Amount</label>                      
                        <div class="col-sm-4">
                            <input type="text" name="last_repayment_amount" class="form-control decimal-2-places" id="inputLastRepaymentAmount" placeholder="Last Repayment Amount" value=""  >
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#last_repayment_amount">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="last_repayment_amount" class="collapse">
                                <p><u><strong>Last Repayment Amount (optional)</strong></u></p>
                                
                                <p>This is an optional field. Only valid for <strong>Flat-Rate</strong> interest method. You can type an amount that will be charged on the last repayment. If you leave this field empty, the last repayment amount would be calculated based on the <strong>Loan Interest</strong> and <strong>Loan Duration</strong> fields above.</p>
                            </div>
                        </div>
                    </div>
                    
        <script>
        $(function() {
            $('#inputLoanOverrideMaturityDate').datepick({
             
            defaultDate: '18/09/2017', showTrigger: '#calImg',
            yearRange: 'c-20:c+20', showTrigger: '#calImg',
            
            dateFormat: 'dd/mm/yyyy',
            minDate: '01/01/1980'
            });
        });
        
        </script>
                    <div class="form-group">
                        <label for="inputLoanOverrideMaturityDate" class="col-sm-3 control-label">Override Maturity Date</label>
                        <div class="col-sm-4">
                            <input type="text" name="loan_override_maturity_date" class="form-control" id="inputLoanOverrideMaturityDate" placeholder="dd/mm/yyyy" value="">
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#loan_override_maturity_date">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="loan_override_maturity_date" class="collapse">
                                <p><strong><u>Override Maturity Date</u></strong>
                                    <br>This is an optional field. You can specify a maturity date for the loan. If you leave this field empty, the system will calculate maturity date as per the <strong>Repayment Cycle</strong> selected above.
                                </p>
                                <p>Some lending companies have specific maturity dates. For example, let's say you have a 1 month loan with daily repayments that starts on 15th May and ends on 14th June. But you don't want to count the days between the start and end date every time you add a loan since months have different number of days. In this example, you can select a really high value in <strong>Repayment Cycle</strong> like 60 Days and put 14th June in <strong>Override Maturity Date</strong>. The system will automatically stop the loan schedule at 14th June and divide the due amounts accordingly. Please note that the total due amounts will not change.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="inputOverrideEachRepaymentAmount" class="col-sm-3 control-label">Override Each Repayment Amount to</label>                      
                        <div class="col-sm-4">
                            <input type="text" name="override_each_repayment_amount" class="form-control decimal-2-places" id="inputOverrideEachRepaymentAmount" placeholder="Repayment Amount" value=""  >
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#override_each_repayment_amount">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="override_each_repayment_amount" class="collapse">
                                <p><strong><u>Override Each Repayment Amount to</u></strong>
                                    <br>This is an optional field. Only valid for <strong>Flat-Rate</strong> interest method. You can specify the total amount for each repayment cycle. If you leave this field empty, the system will calculate repayment amount as per the <strong>Repayment Cycle</strong> selected above.</p>
                                    <p>Some lending companies don't calculate the exact interest amount for each repayment cycle. Consider a scenario where you give a borrower $5000 for 24 weeks and agree to a total repayment of $288.75 for each week. If you multiply $288.75 by 24 weeks, you get $6930. So the total interest charged is $6930-$5000 = $1930. If you divide $1930 by 24 weeks, you get 80.416666666666 interest for each repayment cycle. If you enter that in <strong>Loan Interest</strong> field above (such as 80.41 or 80.42), the due amount for each repayment would not all be the same due to the rounding off error. Hence for this type of loan, you can put $288.75 in <strong>Override Each Repayment Amount to</strong> and the system will automatically calculate the interest for each repayment and do the proper rounding off. In this case, you can put 0 in <strong>Loan Interest</strong> above.</p>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputLoanInterestSchedule" class="col-sm-3 control-label">How should Interest be charged in Loan Schedule?</label>
                        <div class="col-sm-4">
                            <select class="form-control" name="loan_interest_schedule" id="inputLoanInterestSchedule">
                                <option value="charge_interest_normally" >Include interest normally as per Interest Method</option>
                                <option value="charge_interest_on_released_date" >Charge All Interest on the Released Date</option>
                                <option value="charge_interest_on_first_repayment" >Charge All Interest on the First Repayment</option>
                                <option value="charge_interest_on_last_repayment" >Charge All Interest on the Last Repayment</option>
                            </select>
                        </div>
                        <div class="col-sm-4">
                            <a class="btn btn-primary btn-sm"  data-toggle="collapse" data-target="#loan_interest_schedule">Help</a>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-8">
                            <div id="loan_interest_schedule" class="collapse">
                                <p><strong><u>How should Interest be charged in Loan Schedule?</u></strong>
                                    <br>This is an optional field. Select how the total interest should be charged in the loan schedule. You can select from</p>

                                <ul>
                                    <li><strong>Include interest normally as per Interest Method</strong>
                                        <br>- The interest will be shown as per the <strong>Interest Method</strong> above.</li>
                                    <li><strong>Charge All Interest on the Released Date</strong>
                                        <br>- All the interest will be charged on the released date.</li>
                                    <li><strong>Charge All Interest on the First Repayment</strong>
                                        <br>- All interest will be charged on the first repayment date as per the schedule.</li>
                                    <li><strong>Charge All Interest on the Last Repayment</strong>
                                        <br>- All interest will be charged on the last repayment date as per the schedule.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
               
                <script>
                $(document).ready(function () {                
                   $(".slidingDivAutomatedPayments").hide();                      
                  $('.show_hide_automated_payments').click(function (e) {
                    $(".slidingDivAutomatedPayments").slideToggle("fast");
                    var val = $(this).text() == "Hide" ? "Show" : "Hide";
                    $(this).hide().text(val).fadeIn("fast");
                    e.preventDefault();
                  });
                });
                </script>
                <hr>
                
                
                
               <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Other (optional):</div></div>
                 <div class="form-group">
                        <label for="inputBorrowerId" class="col-sm-3 control-label">Gaerantor</label>                      
                        <div class="col-sm-5">
                            <select data-placeholder="Choose guarantor"  class="form-control select2" name="gaurantor_id" id="inputBorrowerId" style="width: 100%;" required>
                                <option value=""></option>
                               
                                    <?php
                                $borrowers_get = $this->db->get('gaurantors')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['gaurantor_id'];?>">
                                    <?php echo $row['title'];?>&nbsp&nbsp<?php echo $row['fname'];?>&nbsp&nbsp<?php echo $row['lname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?></select>
                        </script>
                    </div>
                    <div class="col-sm-3">
                       <div class="pull-left" style="margin-top:5px">
                            <a href="view_guarantors_branch.php" target="_blank">Add/Edit Guarantors</a>
                       </div>
                    </div>      
                </div>                 
                <div class="form-group" >
                    <label for="inputLoanDescription" class="col-sm-3 control-label">Description</label>                      
                    <div class="col-sm-5">
                        <textarea name="loan_description" class="form-control" id="inputLoanDescription" rows="3"></textarea>
                    </div>
                </div>                                 
                <div class="form-group">
                    <label for="loan_files" class="col-sm-3 control-label">Loan Files<br>(text, word, pdf, image, zip, csv, or excel)</label>
                    <div class="col-sm-9">    
                        <input type="file" id="data_files" name="loan_files" multiple>
                    </div>
                                
<script type="text/javascript">
        $(document).ready(function() {
          if (window.FormData) {
              $('#data_files').bind({
                  change : function()
                  {
                      var input = document.getElementById('data_files');
                      files = input.files;
                      
                      if (files.length > 20) {
                          alert('You can only upload max of 20 files');
                          $('#data_files').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(application/pdf|application/acrobat|applications/vnd.pdf|text/pdf|text/x-pdf|application/msword|application/x-msword|application/vnd.openxmlformats-officedocument.wordprocessingml.document|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet|text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/zip|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt|image/png|image/jpeg|image/gif|application/zip|application/x-zip|application/octet-stream|application/x-zip-compressed)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload text, word, pdf, image, zip, csv, or excel files.",
                                          type: "red"
                                        });
                                      $('#data_files').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                        
                                  $('#data_files').val("");
                                  return false;
                              }
                          }
                      } 
                  }
              });
              $('#photo_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('photo_file');
                      files = input.files;
                      
                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#photo_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(image/png|image/jpeg|image/gif)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var filesize = file.size;
                              if (file.type != '')
                              {
                                  var matcher = regExp.test(file.type);
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload png, jpeg, or gif files.",
                                          type: "red"
                                        });
                                      $('#photo_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#photo_file').val("");
                                  return false;
                              }
                          }
                      } 
                  }
              });
              $('#csv_file').bind({
                  change : function()
                  {
                      var input = document.getElementById('csv_file');
                      files = input.files;
                      
                      if (files.length > 1) {
                          $.alert({
                              title: "Error",
                              content: "You can only upload max of 1 file.",
                              type: "red"
                            });
                          $('#csv_file').val("");
                          return false;
                      }
                      else {
                          var regExp = new RegExp('(text/csv|text/plain|application/csv|application/x-csv|text/comma-separated-values|application/excel|application/ms-excel|application/vnd.ms-excel|application/vnd.msexcel|text/anytext|application/octet-stream|application/txt)', 'i');
                          for (var i = 0; i < files.length; i++)
                          {
                              var file = files[i];
                              var matcher = regExp.test(file.type);
                              if (file.type != '')
                              {
                                  var filesize = file.size;
                                  if (!matcher)
                                  {
                                      $.alert({
                                          title: "Error",
                                          content: "You can only upload csv file.",
                                          type: "red"
                                        });
                                      $('#csv_file').val("");
                                      return false;
                                  }
                              }
                              if (filesize > 30000000)
                              {
                                  $.alert({
                                          title: "Error",
                                          content: "File must not be more than 30mb.",
                                          type: "red"
                                        });
                                  $('#csv_file').val("");
                                  return false;
                              }
                          }
                      } 
                  }
              });
          }
        });
        </script>
 
                </div>
                <div class="form-group">
                    <label for="inputStatusId" class="col-sm-3 control-label">Loan Status</label>
                    <div class="col-sm-4">
                        <select class="form-control" name="loan_status_id" id="inputStatusId">
                        <option value="Processing">Processing</option>
                        <option value="Open" selected>Open</option>
                        <option value="Defaulted">Defaulted</option>
                        <option value="Fraud">Fraud</option>
                        <option value="Denied">Denied</option>
                        </select>
                    </div>
                </div>
               
                <div class="box-footer">
                    <button type="button" class="btn btn-default"  onClick="parent.location=''">Back</button>
                    <button type="submit" id="submit" class="btn btn-info pull-right" data-loading-text="<i class='fa fa-spinner fa-spin '></i> Please Wait">Submit</button>
                    
    <script type="text/javascript">
    $('#form').on('submit', function(e) {
        
        $(this).find('button[type=submit]').prop('disabled', true);
        $('.btn').prop('disabled', true);
        $('.btn').button('loading');
        return true;
    });
    </script>
                </div><!-- /.box-footer -->
            </div>                
        </form>
    </div>
    <script>
    $( "#pre_loader" ).hide();
    </script>
    
                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>
           
            
    </body>
	 <script type="text/javascript">
       $(document).ready(function(){
           $("#submit").click(function(){
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_loan_type= $("#inputLoanType").var();
            var loan_application_id= $("#inputLoanApplicationId").var();
            var disbursed_by= $("#inputDisbursedById").var();
            var loan_application_id= $("#inputLoanApplicationId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            var borrower_id= $("#inputBorrowerId").var();
            

           });
       });

                    
                </script>
</html>