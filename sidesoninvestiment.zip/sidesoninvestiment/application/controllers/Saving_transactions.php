<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Saving_transactions extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Saving_transactions_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('saving_transactions/saving_transactions_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Saving_transactions_model->json();
    }

    public function read($id) 
    {
        $row = $this->Saving_transactions_model->get_by_id($id);
        if ($row) {
            $data = array(
		'savingst_id' => $row->savingst_id,
		'name' => $row->name,
		'amount' => $row->amount,
		'saving_type' => $row->saving_type,
		'description' => $row->description,
		'user_id' => $row->user_id,
		'time_date' => $row->time_date,
	    );
            $this->load->view('saving_transactions/saving_transactions_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('saving_transactions'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('saving_transactions/create_action'),
	    'savingst_id' => set_value('savingst_id'),
	    'name' => set_value('name'),
	    'amount' => set_value('amount'),
	    'saving_type' => set_value('saving_type'),
	    'description' => set_value('description'),
	    'user_id' => set_value('user_id'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('saving_transactions/saving_transactions_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'name' => $this->input->post('name',TRUE),
		'amount' => $this->input->post('amount',TRUE),
		'saving_type' => $this->input->post('saving_type',TRUE),
		'description' => $this->input->post('description',TRUE),
		'user_id' => $this->input->post('user_id',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Saving_transactions_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('saving_transactions'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Saving_transactions_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('saving_transactions/update_action'),
		'savingst_id' => set_value('savingst_id', $row->savingst_id),
		'name' => set_value('name', $row->name),
		'amount' => set_value('amount', $row->amount),
		'saving_type' => set_value('saving_type', $row->saving_type),
		'description' => set_value('description', $row->description),
		'user_id' => set_value('user_id', $row->user_id),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('saving_transactions/saving_transactions_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('saving_transactions'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('savingst_id', TRUE));
        } else {
            $data = array(
		'name' => $this->input->post('name',TRUE),
		'amount' => $this->input->post('amount',TRUE),
		'saving_type' => $this->input->post('saving_type',TRUE),
		'description' => $this->input->post('description',TRUE),
		'user_id' => $this->input->post('user_id',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Saving_transactions_model->update($this->input->post('savingst_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('saving_transactions'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Saving_transactions_model->get_by_id($id);

        if ($row) {
            $this->Saving_transactions_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('saving_transactions'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('saving_transactions'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('name', 'name', 'trim|required');
	$this->form_validation->set_rules('amount', 'amount', 'trim|required');
	$this->form_validation->set_rules('saving_type', 'saving type', 'trim|required');
	$this->form_validation->set_rules('description', 'description', 'trim|required');
	$this->form_validation->set_rules('user_id', 'user id', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('savingst_id', 'savingst_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Saving_transactions.php */
/* Location: ./application/controllers/Saving_transactions.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */