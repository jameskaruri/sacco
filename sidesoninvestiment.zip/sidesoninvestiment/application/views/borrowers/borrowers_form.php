<!doctype html>
<html>
     <div class="content-wrapper">
         <!-- Content Header (Page header) -->
         <section class="content-header"><h1>Add Borrower<small><a href="" target="_blank">Help</a></small></h1>
         </section>

         <!-- Main content -->
         <section class="content">
<div class="box box-info">
    <body>

        <div class="panel panel-default"><div class="panel-body bg-gray text-bold" >Personal details:</div></div>

        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data">
            <table class="table table-bordered table-condensed table-hover" style="width: 100%">
              <tr><td>
	    <div class="form-group">
            <label for="varchar">Surname <?php echo form_error('borrower_surname') ?></label>
            <input type="text" class="form-control" name="borrower_surname" id="borrower_surname" placeholder="Borrower Surname" value="<?php echo $borrower_surname; ?>" />
        </div></td><td>
	    <div class="form-group">
            <label for="varchar">Borrower Firstname <?php echo form_error('borrower_firstname') ?></label>
            <input type="text" class="form-control" name="borrower_firstname" id="borrower_firstname" placeholder="Borrower Firstname" value="<?php echo $borrower_firstname; ?>" />
        </div></td><td>

	    <div class="form-group">
            <label for="varchar">Borrower Lastname <?php echo form_error('borrower_lastname') ?></label>
            <input type="text" class="form-control" name="borrower_lastname" id="borrower_lastname" placeholder="Borrower Lastname" value="<?php echo $borrower_lastname; ?>" />
        </div></td></tr>
          <tr><td>
            <div class="form-group">
                  <label for="varchar">Borrower Id Number <?php echo form_error('borrower_id_number') ?></label>
                  <input type="text" class="form-control" name="borrower_id_number" id="borrower_id_number" placeholder="Borrower Id Number" value="<?php echo $borrower_id_number; ?>" />
                  <span id="availability" ></span>
              </div>
          </td>
            <td>
              <div class="form-group">
                     <label for="varchar">Borrower Email <?php echo form_error('borrower_email') ?></label>
                     <input type="text" class="form-control" name="borrower_email" id="borrower_email" placeholder="Borrower Email" value="<?php echo $borrower_email; ?>" />
                 </div>
            </td>
           <td>
             <div class="form-group">
                    <label for="varchar">Borrower Mobile <?php echo form_error('borrower_mobile') ?></label>
                    <input type="text" class="form-control" name="borrower_mobile" id="borrower_mobile" placeholder="Borrower Mobile" value="<?php echo $borrower_mobile; ?>" />
                </div>
           </td>
          </tr>
          <tr>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Gender <?php echo form_error('borrower_gender') ?></label>
                    <select type="text" class="form-control" name="borrower_gender" id="borrower_gender" placeholder="Borrower Gender" value="" />
                      <option value="<?php echo $borrower_gender; ?>"><?php echo $borrower_gender; ?></option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                </div>
            </td>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Title <?php echo form_error('borrower_title') ?></label>
                    <select type="text" class="form-control" name="borrower_title" id="borrower_title" placeholder="Borrower Title" value="" />
                      <option value="<?php echo $borrower_title; ?>"><?php echo $borrower_title; ?></option>
                      <option value="Mr">Mr</option>
                      <option value="Mrs">Mrs</option>
                      <option value="Miss">Miss</option>


                    </select>
                </div>
            </td>
            <td>
              <script>
            $(function() {
                $('#borrower_dob').datepick({
                maxDate: '',
                defaultDate: '', showTrigger: '#calImg',
                yearRange: 'c-80:c+20', showTrigger: '#calImg',

                dateFormat: 'dd/mm/yyyy',
                minDate: '01/01/1920'
                });
            });

            </script>
              <div class="form-group">
                    <label for="varchar">Borrower Dob <?php echo form_error('borrower_dob') ?></label>
                    <input type="text" class="form-control" name="borrower_dob" id="borrower_dob" placeholder="Borrower Dob" value="<?php echo $borrower_dob; ?>" />
                </div>
            </td>
          </tr>
          <tr>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Address <?php echo form_error('borrower_address') ?></label>
                    <input type="text" class="form-control" name="borrower_address" id="borrower_address" placeholder="Borrower Address" value="<?php echo $borrower_address; ?>" />
                </div>
            </td>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Zipcode <?php echo form_error('borrower_zipcode') ?></label>
                    <input type="text" class="form-control" name="borrower_zipcode" id="borrower_zipcode" placeholder="Borrower Zipcode" value="<?php echo $borrower_zipcode; ?>" />
                </div>
            </td>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Town <?php echo form_error('borrower_town') ?></label>
                    <input type="text" class="form-control" name="borrower_town" id="borrower_town" placeholder="Borrower Town" value="<?php echo $borrower_town; ?>" />
                </div>
            </td>
          </tr>
          <tr>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Street <?php echo form_error('borrower_street') ?></label>
                    <input type="text" class="form-control" name="borrower_street" id="borrower_street" placeholder="Borrower Street" value="<?php echo $borrower_street; ?>" />
                </div>
            </td>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Estate <?php echo form_error('borrower_estate') ?></label>
                    <input type="text" class="form-control" name="borrower_estate" id="borrower_estate" placeholder="Borrower Estate" value="<?php echo $borrower_estate; ?>" />
                </div>
            </td>
              <td>
                <div class="form-group">
                      <label for="varchar">Borrower Nearestcommonfeature <?php echo form_error('borrower_nearestcommonfeature') ?></label>
                      <input type="text" class="form-control" name="borrower_nearestcommonfeature" id="borrower_nearestcommonfeature" placeholder="Borrower Nearestcommonfeature" value="<?php echo $borrower_nearestcommonfeature; ?>" />
                  </div>
              </td>
          </tr>
          <tr>
            <td>
              <div class="form-group">
                    <label for="varchar">Borrower Picture <?php echo form_error('borrower_picture') ?></label>
                    <input type="file" class="form-control" name="borrower_picture" id="borrower_picture" placeholder="Borrower Picture" value="<?php echo $borrower_picture; ?>" />

                </div>
        	    <div class="form-group">
                    <label for="varchar">Borrower Description <?php echo form_error('borrower_description') ?></label>
                    <textarea type="text" class="form-control" name="borrower_description" id="borrower_description" placeholder="Borrower Description" value="<?php echo $borrower_description; ?>" /></textarea>
                </div>
        	    <div class="form-group">
                    <label for="varchar">Borrower Id <?php echo form_error('borrower_id') ?></label>
                    <input type="file" class="form-control" name="borrower_id" id="borrower_id" placeholder="Borrower Id" value="<?php echo $borrower_id; ?>" />
                </div>
            </td>
          </tr>
</table>
<table class="table table-bordered table-condensed table-hover" style="width: 100%">
    <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Business details:</div></div>
    <tr>
      <td>
        <div class="form-group">
              <label for="varchar">Borrower Business Name <?php echo form_error('borrower_business_name') ?></label>
              <input type="text" class="form-control" name="borrower_business_name" id="borrower_business_name" placeholder="Borrower Business Name" value="<?php echo $borrower_business_name; ?>" />
          </div>
      </td>
      <td>
        <div class="form-group">
               <label for="varchar">Borrower Business Nature <?php echo form_error('borrower_business_nature') ?></label>
               <input type="text" class="form-control" name="borrower_business_nature" id="borrower_business_nature" placeholder="Borrower Business Nature" value="<?php echo $borrower_business_nature; ?>" />
           </div>
      </td>
     <td>
       <div class="form-group">
              <label for="varchar">Borrower Business Duration <?php echo form_error('borrower_business_Duration') ?></label>
              <input type="text" class="form-control" name="borrower_business_Duration" id="borrower_business_Duration" placeholder="Borrower Business Duration" value="<?php echo $borrower_business_Duration; ?>" />
          </div>
     </td>
    </tr>
  <tr>
    <td>
      <div class="form-group">
            <label for="varchar">Business Owner <?php echo form_error('Business_owner') ?></label>
            <input type="text" class="form-control" name="Business_owner" id="Business_owner" placeholder="Business Owner" value="<?php echo $Business_owner; ?>" />
        </div>
    </td>
    <td>
      <div class="form-group">
            <label for="varchar">Address1 <?php echo form_error('address1') ?></label>
            <input type="text" class="form-control" name="address1" id="address1" placeholder="Address1" value="<?php echo $address1; ?>" />
        </div>
    </td>
    <td>
      <div class="form-group">
            <label for="varchar">Zipcode1 <?php echo form_error('zipcode1') ?></label>
            <input type="text" class="form-control" name="zipcode1" id="zipcode1" placeholder="Zipcode1" value="<?php echo $zipcode1; ?>" />
        </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="form-group">
            <label for="varchar">Town1 <?php echo form_error('town1') ?></label>
            <input type="text" class="form-control" name="town1" id="town1" placeholder="Town1" value="<?php echo $town1; ?>" />
        </div>
    </td>
    <td>
      <div class="form-group">
            <label for="varchar">Street1 <?php echo form_error('street1') ?></label>
            <input type="text" class="form-control" name="street1" id="street1" placeholder="Street1" value="<?php echo $street1; ?>" />
        </div>
    </td>
    <td>
      <div class="form-group">
            <label for="varchar">Estate1 <?php echo form_error('estate1') ?></label>
            <input type="text" class="form-control" name="estate1" id="estate1" placeholder="Estate1" value="<?php echo $estate1; ?>" />
        </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="form-group">
            <label for="varchar">Nearestcommonfeature1 <?php echo form_error('nearestcommonfeature1') ?></label>
            <input type="text" class="form-control" name="nearestcommonfeature1" id="nearestcommonfeature1" placeholder="Nearestcommonfeature1" value="<?php echo $nearestcommonfeature1; ?>" />
        </div>
    </td>
  </tr></table>
  <table class="table table-bordered table-condensed table-hover" style="width: 100%">
      <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Direction:</div>
      <tr>
        <td>
          <div class="form-group">
                <label for="varchar">Business Location <?php echo form_error('business_location') ?></label>
                <textarea type="text" class="form-control" name="business_location" id="business_location" placeholder="Business Location" value="<?php echo $business_location; ?>" /></textarea>
            </div>
        </td>
        <td>
          <div class="form-group">
                <label for="varchar">Residence Location <?php echo form_error('residence_location') ?></label>
                <textarea type="text" class="form-control" name="residence_location" id="residence_location" placeholder="Residence Location" value="<?php echo $residence_location; ?>" /></textarea>
            </div>
        </td>

      </tr>
      </table>
        <input type="hidden"  name="borrower_access_ids" id="borrower_access_ids" value="<?php echo $borrower_access_ids; ?>" />
	    <input type="hidden" name="borrowers_id" value="<?php echo $borrowers_id; ?>" />
	    <button type="submit" class="btn btn-info pull-right align" >Submit</button>
	    <a href="<?php echo site_url('borrowers') ?>" class="btn btn-default">Back</a>
	</form>
  <script type="text/javascript">
    $(document).ready(function(){
      $('#borrower_id_number').change(function(){
        var idno = $('#borrower_id_number').val();
        if (idno!='') {
          $.ajax({
             url:"borrowers/id_availability";
             method:"POST",
             data:{borrower_id_number:borrower_id_number},
             success:function(data){
              $('#availability').html(data);
             }

          });
        }
      });
    });
  </script>
    </body>
</html>
