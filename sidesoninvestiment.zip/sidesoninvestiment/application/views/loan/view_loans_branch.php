    <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>View All Loans<small><a href="http://support.loandisk.com/support/solutions/articles/17000013916-view-all-loans-branch" target="_blank">Help</a></small></h1>
                </section>

                <!-- Main content -->
                <section class="content">
        <script>
        $(document).ready(function () {
          $(".slidingDiv").hide();       
          $('.show_hide').click(function (e) {
            $(".slidingDiv").slideToggle("fast");
            var val = $(this).text() == "Hide" ? "Show" : "Hide";
            $(this).hide().text(val).fadeIn("fast");
            e.preventDefault();
          });
        });
        </script>
        <p><b>Advanced Search: <a href="#" class="show_hide">Show</a></b></p>
        <div class="slidingDiv" style="display: none;">
                
        <div class="box box-success">
            
            <form class="form-horizontal" method="get" enctype="multipart/form-data">
                <input type="hidden" name="search_loans" value="1">
                <div class="box-body">
                  <p>All fields are optional. You can type or select as many fields as you like.</p>
                  <div class="row">
                    <div class="col-xs-6">
                            <select class="form-control" name="loan_status_id" id="inputStatusId">
                                <option value="0">All Loan Status</option>
                                <option value="8">Processing</option>
                                <option value="1">Open</option>
                                <option value="5">----Missed Repayment</option>
                                <option value="6">----Past Maturity</option>
                                <option value="4">Restructured</option>
                                <option value="2">Fully Paid</option>
                                <option value="3">Defaulted</option>
                                <option value="7">----Fraud</option>
                                <option value="9">Denied</option>
                            </select>
                    </div>
                    <div class="col-xs-6">
                            <select class="form-control" name="loan_scheme_id" id="inputSchemeId">
                                <option value="0">All Repayment Methods</option>
                                <option value="6">Daily</option>
                                <option value="4">Weekly</option>
                                <option value="9">Biweekly</option>
                                <option value="3">Monthly</option>
                                <option value="12">Bimonthly</option>
                                <option value="13">Quarterly</option>
                                <option value="14">Semi-Annual</option>
                                <option value="11">Yearly</option>
                                <option value="10">Lump-Sum</option>
                            </select>
                    </div>
                  </div>
                </div><!-- /.box-body -->

                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-6">
                        <input type="text" name="loan_borrower_name" class="form-control" id="inputLoanBorrowerName" placeholder="Borrower Name or Business Name" value="">
                    </div>
                    <div class="col-xs-6">
                        <input type="text" name="loan_application_id" class="form-control" id="inputLoanApplicationId" placeholder="Loan#" value="">
                    </div>
                 </div>
                </div><!-- /.box-body -->
                
                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-6">
                            <select class="form-control" name="loan_product_id" id="inputProductId">
                                <option value="0">All Loan Products</option>
                                <option value="11971">Business Loan</option>
                                <option value="11973">Overseas Worker Loan</option>
                                <option value="11974">Pensioner Loan</option>
                                <option value="11970">Personal Loan</option>
                                <option value="11972">Student Loan</option>
                            </select>
                    </div>
                    <div class="col-xs-6">
                            <select class="form-control" name="collector_access_id" id="inputStaffId">
                                <option value="0">All Loan Officers</option>
                                <option value="3160">james karuri
                                </option>
                            </select>
                    </div>
                  </div>
                </div><!-- /.box-body -->
                <div class="box-body">
                  <div class="row">
                    <div class="col-xs-3">
                        <script>
                        $(function() {
                            $('#inputLoanSearchFromDate,#inputLoanSearchToDate').datepick({ 
                                onSelect: customRange, showTrigger: '#calImg',
                                dateFormat: 'dd/mm/yyyy'});
                                function customRange(dates) { 
                                    if (this.id == 'inputLoanSearchFromDate') { 
                                        $('#inputLoanSearchToDate').datepick('option', 'minDate', dates[0] || null); 
                                    } 
                                    else { 
                                        $('#inputLoanSearchFromDate').datepick('option', 'maxDate', dates[0] || null); 
                                    } 
                                }
                        });                    
                        </script>
                        <input type="text" name="loan_search_from_date" class="form-control" id="inputLoanSearchFromDate" placeholder="From Date: dd/mm/yyyy" value=""  onclick="setSens('inputLoanSearchToDate', 'max');">
                    </div>
                    <div class="col-xs-3">
                            <input type="text" name="loan_search_to_date" class="form-control" id="inputLoanSearchToDate" placeholder="To Date: dd/mm/yyyy" value=""  onclick="setSens('inputLoanSearchFromDate', 'min');">
                    </div>
                    <div class="col-xs-6">
                            <select class="form-control" name="collateral_status_id" id="inputCollateralStatusId">
                                <option value="0">All Collateral Status</option>
                                <option value="1">Deposited into Branch</option>
                                <option value="2">Collateral with Borrower</option>
                                <option value="3">Returned to Borrower</option>
                                <option value="6">Repossession Initiated</option>
                                <option value="7">Repossesed</option>
                                <option value="4">Sold</option>
                                <option value="5">Lost</option>
                            </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class=col-xs-6 pull-right">
                        <label>
                             <input type="radio" name="loan_search_date_type" id="inputLoanSearchTypeDate"  value="released" checked> 
                             Released &nbsp;&nbsp;
                        </label>
                        <label>
                            <input type="radio" name="loan_search_date_type"  id="inputLoanSearchTypeDate" value="maturity">
                            Maturity
                        </label>
                    </div>
                  </div>
                  
                  <div class="row">
                    <div class="col-xs-12">
                        <span class="input-group-btn">
                          <button type="button" class="btn bg-purple btn-flat pull-right" onClick="parent.location='https://x.loandisk.com/loans/view_loans_branch.php'">Reset!</button>
                          <button type="submit" class="btn bg-olive btn-flat pull-right">Search!</button>
                        </span>
                    </div>
                  </div>
                </div><!-- /.box-body -->
            </form>
          </div><!-- /.box -->
          </div>
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                    <div class="pull-left">
                        <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
                    </div>
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            <div class="btn-group-horizontal">
                <a type="button" class="btn btn-block btn-default" href="filter_table_columns.php?filter_type=loans">Show/Hide Columns</a>
            </div>
                    </div>
                </div>
            </div>              
       <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
                    <table id="view-loans" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
                        <thead>
                            <tr style="background-color: #D1F9FF">
                                     <th class="not-export-col" width="80px">No</th>
            <th>Borrowers Id</th>
            <th>Loan Product</th>
            <th>Loan</th>
            <th> Amount</th>
            <th>Loan Released Date</th>
           
         
    
            
            <th>Loan Duration</th>
            <th>Loan Duration Period</th>
          

            
            <th>First Repayment Amount</th>
            <th>Last Repayment Amount</th>
 
            <th>Loan Status </th>
           
          
            <th width="200px">Action</th
                            </tr>
                       </thead>
                      
                    </table>
                </div>
            </div>
        </div>
     <script type="text/javascript" language="javascript">
        
        $(document).ready(function() {
            var dataTable = $('#view-loans').DataTable( {
                "fixedHeader": {
                    "header": true,
                    "footer": true,
                },
                "dom": '<"pull-left"f>r<"pull-right"l>tip',
                "autoWidth": true,
                "lengthMenu": [[10, 20, 100, 250, 500, 5000], [10, 20, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": false,
                "responsive": true,
                searching:true,
                stateSave: true,
                ajax: {"url": "loan/json", "type": "POST"},
                    columns: [
                        {
                            "data": "loan_id",
                            "orderable": false
                        },{"data": "borrowers_id"},{"data": "Loan_product_id"},{"data": "loan"},{"data": "loan_principal_amount"},{"data": "loan_released_date"},{"data": "loan_duration"},{"data": "loan_duration_period"},{"data": "first_repayment_amount"},{"data": "last_repayment_amount"},{"data": "loan_status_id"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
            } );
             var buttons = new $.fn.dataTable.Buttons(dataTable, {
                   "buttons": [
            {
                extend: 'collection',
                text: 'Export',
                buttons: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print'
                ]
            }
        ]
            }).container().appendTo($('#export_button'));
            
            $("#view-loans").unbind().on('click', '.confirm_action', function(e){
                e.preventDefault();
                var href_value = $(this).attr('href');
                var confirm_text = $(this).attr('actionconfirm');
                $.confirm({
                    title: 'Please Confirm',
                    content: 'Are you sure you want to ' + confirm_text + '?',
                    type: 'green',
                    buttons: {
                        confirm: function () {
                            window.location = href_value;
                            return true;
                        },
                        cancel: function () {
                            return true;
                        }
                    }  
                });
            });
        } );
    </script>
    
    <script>
    $( "#pre_loader" ).hide();
    </script>
    
                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>
            
            
    </body>
</html>