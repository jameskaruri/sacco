<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Loan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Loan_model');
        $this->load->library('form_validation');
	$this->load->library('datatables');
    }

    public function index()
    {
      $this->load->View('header/link');

        $this->load->view('loan/View_loans_branch');
    }

    public function json() {
        header('Content-Type: application/json');
        echo $this->Loan_model->json();
    }

    public function read($id)
    {
        $row = $this->Loan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'loan_id' => $row->loan_id,
		'borrowers_id' => $row->borrowers_id,
		'Loan_product_id' => $row->Loan_product_id,
		'loan' => $row->loan,
		'loan_disbursed_by_id' => $row->loan_disbursed_by_id,
		'loan_principal_amount' => $row->loan_principal_amount,
		'loan_released_date' => $row->loan_released_date,
		'loan_interest_method' => $row->loan_interest_method,
		'loan_interest_type' => $row->loan_interest_type,
		'loan_interest' => $row->loan_interest,
		'loan_interest_period' => $row->loan_interest_period,
		'loan_duration' => $row->loan_duration,
		'loan_duration_period' => $row->loan_duration_period,
		'loan_payment_scheme_id' => $row->loan_payment_scheme_id,
		'loan_num_of_repayments' => $row->loan_num_of_repayments,
		'loan_decimal_places' => $row->loan_decimal_places,
		'loan_interest_start_date' => $row->loan_interest_start_date,
		'loan_first_repayment_date' => $row->loan_first_repayment_date,
		'first_repayment_amount' => $row->first_repayment_amount,
		'last_repayment_amount' => $row->last_repayment_amount,
		'loan_override_maturity_date' => $row->loan_override_maturity_date,
		'override_each_repayment_amount' => $row->override_each_repayment_amount,
		'loan_interest_schedule' => $row->loan_interest_schedule,
		'gaurantor_id' => $row->gaurantor_id,
		'gaurantor_id2' => $row->gaurantor_id2,
		'loan_description' => $row->loan_description,
		'loan_files' => $row->loan_files,
		'loan_status_id' => $row->loan_status_id,
		
		
	    );
      $this->load->View('header/link');
            $this->load->view('loan/loan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('loan'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('loan/create_action'),
	    'loan_id' => set_value('loan_id'),
	    'borrowers_id' => set_value('borrowers_id'),
	    'Loan_product_id' => set_value('Loan_product_id'),
	    'loan' => set_value('loan'),
	    'loan_disbursed_by_id' => set_value('loan_disbursed_by_id'),
	    'loan_principal_amount' => set_value('loan_principal_amount'),
	    'loan_released_date' => set_value('loan_released_date'),
	    'loan_interest_method' => set_value('loan_interest_method'),
	    'loan_interest_type' => set_value('loan_interest_type'),
	    'loan_interest' => set_value('loan_interest'),
	    'loan_interest_period' => set_value('loan_interest_period'),
	    'loan_duration' => set_value('loan_duration'),
	    'loan_duration_period' => set_value('loan_duration_period'),
	    'loan_payment_scheme_id' => set_value('loan_payment_scheme_id'),
	    'loan_num_of_repayments' => set_value('loan_num_of_repayments'),
	    'loan_decimal_places' => set_value('loan_decimal_places'),
	    'loan_interest_start_date' => set_value('loan_interest_start_date'),
	    'loan_first_repayment_date' => set_value('loan_first_repayment_date'),
	    'first_repayment_amount' => set_value('first_repayment_amount'),
	    'last_repayment_amount' => set_value('last_repayment_amount'),
	    'loan_override_maturity_date' => set_value('loan_override_maturity_date'),
	    'override_each_repayment_amount' => set_value('override_each_repayment_amount'),
	    'loan_interest_schedule' => set_value('loan_interest_schedule'),
	    'gaurantor_id' => set_value('gaurantor_id'),
	   
	    'loan_description' => set_value('loan_description'),
	    
	    'loan_status_id' => set_value('loan_status_id')

	);
  $this->load->View('header/link');
        $this->load->view('loan/add_loan', $data);
    }

    public function create_action()
    {
        $this->_rules();


        if ($this->form_validation->run() == TRUE) {
            $this->create();
           
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'Loan_product_id' => $this->input->post('Loan_product_id',TRUE),
		'loan' => $this->input->post('loan',TRUE),
		'loan_disbursed_by_id' => $this->input->post('loan_disbursed_by_id',TRUE),
		'loan_principal_amount' => $this->input->post('loan_principal_amount',TRUE),
		'loan_released_date' => $this->input->post('loan_released_date',TRUE),
		'loan_interest_method' => $this->input->post('loan_interest_method',TRUE),
		'loan_interest_type' => $this->input->post('loan_interest_type',TRUE),
		'loan_interest' => $this->input->post('loan_interest',TRUE),
		'loan_interest_period' => $this->input->post('loan_interest_period',TRUE),
		'loan_duration' => $this->input->post('loan_duration',TRUE),
		'loan_duration_period' => $this->input->post('loan_duration_period',TRUE),
		'loan_payment_scheme_id' => $this->input->post('loan_payment_scheme_id',TRUE),
		'loan_num_of_repayments' => $this->input->post('loan_num_of_repayments',TRUE),
		'loan_decimal_places' => $this->input->post('loan_decimal_places',TRUE),
		'loan_interest_start_date' => $this->input->post('loan_interest_start_date',TRUE),
		'loan_first_repayment_date' => $this->input->post('loan_first_repayment_date',TRUE),
		'first_repayment_amount' => $this->input->post('first_repayment_amount',TRUE),
		'last_repayment_amount' => $this->input->post('last_repayment_amount',TRUE),
		'loan_override_maturity_date' => $this->input->post('loan_override_maturity_date',TRUE),
		'override_each_repayment_amount' => $this->input->post('override_each_repayment_amount',TRUE),
		'loan_interest_schedule' => $this->input->post('loan_interest_schedule',TRUE),
		'gaurantor_id' => $this->input->post('gaurantor_id',TRUE),
		
		'loan_description' => $this->input->post('loan_description',TRUE),
		
		'loan_status_id' => $this->input->post('loan_status_id',TRUE),
		
		
	    );

            $this->Loan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('loan'));
        }

    }


    public function update($id)
    {
        $row = $this->Loan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('loan/update_action'),
		'loan_id' => set_value('loan_id', $row->loan_id),
		'borrowers_id' => set_value('borrowers_id', $row->borrowers_id),
		'Loan_product_id' => set_value('Loan_product_id', $row->Loan_product_id),
		'loan' => set_value('loan', $row->loan),
		'loan_disbursed_by_id' => set_value('loan_disbursed_by_id', $row->loan_disbursed_by_id),
		'loan_principal_amount' => set_value('loan_principal_amount', $row->loan_principal_amount),
		'loan_released_date' => set_value('loan_released_date', $row->loan_released_date),
		'loan_interest_method' => set_value('loan_interest_method', $row->loan_interest_method),
		'loan_interest_type' => set_value('loan_interest_type', $row->loan_interest_type),
		'loan_interest' => set_value('loan_interest', $row->loan_interest),
		'loan_interest_period' => set_value('loan_interest_period', $row->loan_interest_period),
		'loan_duration' => set_value('loan_duration', $row->loan_duration),
		'loan_duration_period' => set_value('loan_duration_period', $row->loan_duration_period),
		'loan_payment_scheme_id' => set_value('loan_payment_scheme_id', $row->loan_payment_scheme_id),
		'loan_num_of_repayments' => set_value('loan_num_of_repayments', $row->loan_num_of_repayments),
		'loan_decimal_places' => set_value('loan_decimal_places', $row->loan_decimal_places),
		'loan_interest_start_date' => set_value('loan_interest_start_date', $row->loan_interest_start_date),
		'loan_first_repayment_date' => set_value('loan_first_repayment_date', $row->loan_first_repayment_date),
		'first_repayment_amount' => set_value('first_repayment_amount', $row->first_repayment_amount),
		'last_repayment_amount' => set_value('last_repayment_amount', $row->last_repayment_amount),
		'loan_override_maturity_date' => set_value('loan_override_maturity_date', $row->loan_override_maturity_date),
		'override_each_repayment_amount' => set_value('override_each_repayment_amount', $row->override_each_repayment_amount),
		'loan_interest_schedule' => set_value('loan_interest_schedule', $row->loan_interest_schedule),
		'gaurantor_id' => set_value('gaurantor_id', $row->gaurantor_id),
		'gaurantor_id2' => set_value('gaurantor_id2', $row->gaurantor_id2),
		'loan_description' => set_value('loan_description', $row->loan_description),
		'loan_files' => set_value('loan_files', $row->loan_files),
		'loan_status_id' => set_value('loan_status_id', $row->loan_status_id),
		'user_id' => set_value('user_id', $row->user_id),
		'time_date' => set_value('time_date', $row->time_date),
	    );
      $this->load->View('header/link');
            $this->load->view('loan/loan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('loan'));
        }
    }

    public function update_action()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('loan_id', TRUE));
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'Loan_product_id' => $this->input->post('Loan_product_id',TRUE),
		'loan' => $this->input->post('loan',TRUE),
		'loan_disbursed_by_id' => $this->input->post('loan_disbursed_by_id',TRUE),
		'loan_principal_amount' => $this->input->post('loan_principal_amount',TRUE),
		'loan_released_date' => $this->input->post('loan_released_date',TRUE),
		'loan_interest_method' => $this->input->post('loan_interest_method',TRUE),
		'loan_interest_type' => $this->input->post('loan_interest_type',TRUE),
		'loan_interest' => $this->input->post('loan_interest',TRUE),
		'loan_interest_period' => $this->input->post('loan_interest_period',TRUE),
		'loan_duration' => $this->input->post('loan_duration',TRUE),
		'loan_duration_period' => $this->input->post('loan_duration_period',TRUE),
		'loan_payment_scheme_id' => $this->input->post('loan_payment_scheme_id',TRUE),
		'loan_num_of_repayments' => $this->input->post('loan_num_of_repayments',TRUE),
		'loan_decimal_places' => $this->input->post('loan_decimal_places',TRUE),
		'loan_interest_start_date' => $this->input->post('loan_interest_start_date',TRUE),
		'loan_first_repayment_date' => $this->input->post('loan_first_repayment_date',TRUE),
		'first_repayment_amount' => $this->input->post('first_repayment_amount',TRUE),
		'last_repayment_amount' => $this->input->post('last_repayment_amount',TRUE),
		'loan_override_maturity_date' => $this->input->post('loan_override_maturity_date',TRUE),
		'override_each_repayment_amount' => $this->input->post('override_each_repayment_amount',TRUE),
		'loan_interest_schedule' => $this->input->post('loan_interest_schedule',TRUE),
		'gaurantor_id' => $this->input->post('gaurantor_id',TRUE),
		'gaurantor_id2' => $this->input->post('gaurantor_id2',TRUE),
		'loan_description' => $this->input->post('loan_description',TRUE),
		'loan_files' => $this->input->post('loan_files',TRUE),
		'loan_status_id' => $this->input->post('loan_status_id',TRUE),
		'user_id' => $this->input->post('user_id',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Loan_model->update($this->input->post('loan_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('loan'));
        }
    }

    public function delete($id)
    {
        $row = $this->Loan_model->get_by_id($id);

        if ($row) {
            $this->Loan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('loan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('loan'));
        }
    }

    public function _rules()
    {
	
    }

}
