<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Loanstatus <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Loan Status <?php echo form_error('loan_status') ?></label>
            <input type="text" class="form-control" name="loan_status" id="loan_status" placeholder="Loan Status" value="<?php echo $loan_status; ?>" />
        </div>
	    <input type="hidden" name="loan_status_id" value="<?php echo $loan_status_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('loanstatus') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>