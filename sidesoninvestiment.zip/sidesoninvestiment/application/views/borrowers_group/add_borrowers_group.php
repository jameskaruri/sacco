
<!DOCTYPE html>
<html>
    

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Group</h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="box box-info">

          <script>
          $(function() {
              
              $('#inputBorrowerIds').on('change',function() {
                  var selected_val = $( "#inputGroupLeader" ).val();
                  var selected_text = $( "#inputGroupLeader" ).text();
                  $('#inputGroupLeader option[value!=selected_val]').remove();
                  $("#inputBorrowerIds option:selected").each(function () {
                    
                    var $this = $(this);
                    if ($this.length) {
                        var optionExists = ($('#inputGroupLeader option[value=' + $(this).val() + ']').length > 0);
                        if(!optionExists)
                        {
                            $('#inputGroupLeader').append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
                            var exists = 0 != $('#inputGroupLeader option[value='+selected_val+']').length;
                            
                            if (exists)
                                $("#inputGroupLeader").val(selected_val);
                            else
                                $("#inputGroupLeader").val($("#inputGroupLeader option:first").val());
                        }
                    }
                    
                });
              });
            });
          </script></div>
        <form action ="add_borrowers_group.php" class="form-horizontal" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="add_borrowers_group.php">
            <input type="hidden" name="add_group" value="1">        
            <div class="box-body">
                <p>If you give group loans, you can use this page to create group of borrowers.</p>
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Required Fields:</div></div>  
                <div class="form-group">
                    <label for="inputGroupName" class="col-sm-2 control-label">Group Name</label>                      
                    <div class="col-sm-10">
                        <input type="text" name="group_name" class="form-control" id="inputGroupName" placeholder="Group Name" value="" required>
                    </div>
                </div>
                
                            <script src="hosen.jquery.min.js" type="text/javascript"></script>
                              <script type="text/javascript">
                                  $(".borrowers_select").chosen({
                                    disable_search_threshold: 1000,
                                    no_results_text: "No borrower found!",
                                    width: "95%",
                                    search_contains: true
                                  });
                              </script>
                    </div>
                </div>                
                <div class="panel panel-default"><div class="panel-body bg-gray text-bold">Optional Fields:</div></div>  
                 <div class="box-body">
                    <div class="form-group">
                        <label for="inputBorrowerId" class="col-sm-2 control-label">Group leader</label>                      
                        <div class="col-sm-10">
                            <select data-placeholder="Choose roup leader"  class="form-control select2" name="borrower_id" id="inputBorrowerId" style="width: 100%;" required>
                                <option value=""></option>
                                       <option></option>  
                                    <?php
                $borrowers_get = $this->db->get('borrowers')->result_array();
                foreach($borrowers_get as $row): ?>
                                <option value="<?php echo $row['borrowers_id'];?>">
                  <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                endforeach;
                ?>
                                </select>                         
    <script src="select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });
    </script></select></div>
                </div>
                <div class="form-group">
                    <label for="inputCollectorName" class="col-sm-2 control-label">Collector Name</label>                      
                    <div class="col-sm-10">
                        <input type="text" name="group_collector_name" class="form-control" id="inputCollectorName" placeholder="Collector Name" value="">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputMeetingSchedule" class="col-sm-2 control-label">Meeting Schedule</label>                      
                    <div class="col-sm-10">
                        <input type="text" name="group_meeting_schedule" class="form-control" id="inputMeetingSchedule" placeholder="Meeting Schedule" value="">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputGroupDescription" class="col-sm-2 control-label">Description</label>                      
                    <div class="col-sm-10">
                        <textarea name="group_description" class="form-control" id="inputGroupDescription" rows="3"></textarea>
                    </div>
                </div>
                    
                <div class="box-footer">
                    <button type="button" class="btn btn-default"  onClick="parent.location='/borrowers/groups/add_borrowers_group.php'">Back</button>
                    <button type="submit" class="btn btn-info pull-right">Submit</button>
                </div><!-- /.box-footer -->
            </div>        
        </form>
    </div></section>
    <script>
    $( "#pre_loader" ).hide();
    </script>
    
                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );
            </script>
           
            
    </body>
</html>