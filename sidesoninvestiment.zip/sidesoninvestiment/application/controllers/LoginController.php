<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
*
*/
class LoginController extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Queries');

    }
    public function index()
    {
        $this->load->view('admin/login');
    }
    public function checklogin(){
        $this->form_validation->set_rules('email','email','required|valid_email');
        $this->form_validation->set_rules('password','password','required|callback_verifyUser');
        if ($this->form_validation->run()==false) {
            $this->load->view('admin/login');
        }

        }
        public function verifyUser(){
           
            $email=$this->input->post('email');
            $password=$this->input->post('password');
            $user_id = $this->Queries->login($email, $password);
             if ($user_id ) {
              $session_data = array('id' => $user_id ->id,
           'email' => $user_id ->email,
           'password' => $user_id ->password,
           'role' => $user_id ->role,
          );
              $this->session->set_userdata($session_data);
            redirect('Dashboard');

            }
            else {
                $this->form_validation->set_message('verifyUser', 'incorrect email or password, please try again.');
                return false;

            }
        }
       
           function logout() {
        $this->session->sess_destroy();
        $this->session->set_flashdata('logout_notification', 'logged_out');
        redirect(base_url(), 'refresh');
    }

    public function reset_password(){
      $this->load->view('admin/reset_password');
    }
    function email_reset_form_validation(){
      $this->form_validation->set_rules('email','Email','required|trim|valid_email');

      if ($this->form_validation->run()) {
        $reset_key = md5(uniqid());
      if ($this->Queries->update_reset_key($reset_key)){
        $this->email->from('jamderitu@gmail.com','localhost/sidesoninvestiment/');
        $this->email->to($this->input->post('email'));
        $this->email->subject('reset your password');
        $message="<p> you or someone else requested to change the password </p> ";
        $message.="<a href='".base_url(). "reset_password/" . $reset_key."'> click here to reset your password </a> ";
        $this->email->message($message);
        if ($this->email->send()) {
         echo 'kindly check your email '.$this->input->post('email').' to reset your password ';
        } else {
           echo "error";
        }
        
      }
      else{
        $this->load->view('admin/reset_password');
      }

      } else {
        $this->load->view('admin/reset_password');
      }
      
    }
        
  }
