<!doctype html>
<html>
    <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1>Add Gaurantors</h1>
                </section>

                <!-- Main content -->
                <section class="content">
    <div class="box box-info">

          <script>
          $(function() {
              
              $('#inputBorrowerIds').on('change',function() {
                  var selected_val = $( "#inputGroupLeader" ).val();
                  var selected_text = $( "#inputGroupLeader" ).text();
                  $('#inputGroupLeader option[value!=selected_val]').remove();
                  $("#inputBorrowerIds option:selected").each(function () {
                    
                    var $this = $(this);
                    if ($this.length) {
                        var optionExists = ($('#inputGroupLeader option[value=' + $(this).val() + ']').length > 0);
                        if(!optionExists)
                        {
                            $('#inputGroupLeader').append("<option value='"+$(this).val()+"'>"+$(this).text()+"</option>");
                            var exists = 0 != $('#inputGroupLeader option[value='+selected_val+']').length;
                            
                            if (exists)
                                $("#inputGroupLeader").val(selected_val);
                            else
                                $("#inputGroupLeader").val($("#inputGroupLeader option:first").val());
                        }
                    }
                    
                });
              });
            });
          </script></div>
    <body>
        <h2 style="margin-top:0px"></h2>
        <form action="<?php echo $action; ?>" method="post">
    <table class="table table-bordered table-condensed table-hover" style="width: 100%"><tbody><tr><td>
        <div class="form-group">
            <label for="varchar">Fname <?php echo form_error('fname') ?></label>
            <input type="text" class="form-control" name="fname" id="fname" placeholder="Fname" value="<?php echo $fname; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Lname <?php echo form_error('lname') ?></label>
            <input type="text" class="form-control" name="lname" id="lname" placeholder="Lname" value="<?php echo $lname; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Idno <?php echo form_error('idno') ?></label>
            <input type="text" class="form-control" name="idno" id="idno" placeholder="Idno" value="<?php echo $idno; ?>" required/>
        </div>
    </td><td>
         
        <div class="form-group">
            <label for="varchar">Busness Name <?php echo form_error('busness_name') ?></label>
            <input type="text" class="form-control" name="busness_name" id="busness_name" placeholder="Busness Name" value="<?php echo $busness_name; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Email <?php echo form_error('email') ?></label>
            <input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" required/>
        </div>
        
         <div class="form-group">
                        <label for="varchar">Title <?php echo form_error('title') ?></label>
                        <select type="text" class="form-control" name="title" id="title" placeholder=" Title" value="" required />
                          <option value="<?php echo $title; ?>"><?php echo $title; ?></option>
                          <option value="Mr">Mr</option>
                          <option value="Mrs">Mrs</option>
                          <option value="Miss">Miss</option>


                        </select>
                    </div>
    </td>
       
                
    </tr><tr><td>
         
        <div class="form-group">
            <label for="varchar">Phone <?php echo form_error('phone') ?></label>
            <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone" value="<?php echo $phone; ?>" required/>
        </div>
        
        <div class="form-group">
                        <label for="varchar">Gender <?php echo form_error('gender') ?></label>
                        <select type="text" class="form-control" name="gender" id="gender" placeholder="Gender" value="" required />
                          <option value="<?php echo $gender; ?>"><?php echo $gender; ?></option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                    </div>
                     <script>
                $(function() {
                    $('#dob').datepick({
                    maxDate: '',
                    defaultDate: '01/01/1999', showTrigger: '#calImg',
                    yearRange: 'c-80:c+20', showTrigger: '#calImg',

                    dateFormat: 'dd/mm/yyyy',
                    minDate: '01/01/1920'
                    });
                });
</script>
        <div class="form-group">
            <label for="date">Date of Birth <?php echo form_error('dob') ?></label>
            <input type="text" class="form-control" name="dob" id="dob" placeholder="Dob" value="<?php echo $dob; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Address <?php echo form_error('address') ?></label>
            <input type="text" class="form-control" name="address" id="address" placeholder="Address" value="<?php echo $address; ?>" required/>
        </div>
         <div class="form-group">
            <label for="varchar">Zipcode <?php echo form_error('zipcode') ?></label>
            <input type="text" class="form-control" name="zipcode" id="zipcode" placeholder="Zipcode" value="<?php echo $zipcode; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Town <?php echo form_error('town') ?></label>
            <input type="text" class="form-control" name="town" id="town" placeholder="Town" value="<?php echo $town; ?>" required/>
        </div>
        <div class="form-group">
            <label for="varchar">Working Status <?php echo form_error('working_status') ?></label>
            <input type="text" class="form-control" name="working_status" id="working_status" placeholder="Working Status" value="<?php echo $working_status; ?>" required/>
        </div>
    </td>
       <td>
             <div class="form-group">
                        <label for="varchar">Picture </label>
                        <input type="file" class="form-control" name="imaetmp" id="imaetmp" placeholder="Borrower Picture" value="" />

                    </div>
    
        <div class="form-group">
            <label for="varchar">Description <?php echo form_error('description') ?></label>
            <input type="text" class="form-control" name="description" id="description" placeholder="Description" value="<?php echo $description; ?>" required/>
        </div>
     
       </td>
        
    </tr>
	    </tbody>
	 </table>
	    <button type="submit" class="btn btn-primary pull-right">submit</button> 
	    <a href="<?php echo site_url('gaurantors') ?>" class="btn btn-default">Back</a>
	</form>
    </body>
</html>