
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Sideson Investiments</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="shortcut icon"  href="<?php echo base_url()."assets/";?>b.png" type="image/x-icon"  />
           <!-- Bootstrap 3.3.5 -->
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>bootstrap.min.css">
        <!-- Font Awesome -->
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
         <script type="text/javascript" charset="utf8" src="<?php echo base_url()."assets/";?>DataTables/jQuery-3.2.1/jquery-3.2.1.min.js"></script>
         <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>DataTables/datatables.min.css">
          <script type="text/javascript" src="<?php echo base_url()."assets/";?>DataTables/datatables.min.js"></script>
          <link rel="stylesheet" href="<?php echo base_url()."assets/";?>DataTables/DataTables-1.10.16/css/dataTables.bootstrap.min.css">


            <script src="<?php echo base_url()."assets/";?>DataTables/DataTables-1.10.16/js/dataTables.bootstrap.min.js"></script>
            <script src="<?php echo base_url()."assets/";?>DataTables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
            <script src="<?php echo base_url()."assets/";?>DataTables/DataTables-1.10.16/js/jquery.dataTables.min.js"></script>
            <script src="<?php echo base_url()."assets/";?>dist/js/bootstrap-select.js"></script>

        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>AdminLTE.css">
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>skin-blue.min.css">
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>select2.min.css">
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>dataTables.bootstrap.css">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>fixedHeader.dataTables.min.css">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>select.dataTables.min.css">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>buttons.dataTables.min.css">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>scroller.dataTables.min.css">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

            <script src="<?php echo base_url()."assets/";?>html5shiv.min.js"></script>
            <script src="<?php echo base_url()."assets/";?>respond.min.js"></script>

        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>style.css">
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>billing_plans.css">
        <link rel="stylesheet" href="<?php echo base_url()."assets/";?>chosen.min.css">
        <script src="<?php echo base_url()."assets/";?>jquery-confirm.min.js"></script>
        <script src="<?php echo base_url()."assets/";?>confirm_dialog.js"></script>
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>jquery-confirm.min.css">
       <link rel="stylesheet" type="text/css" href="<?php echo base_url()."assets/";?>jquery.datepick.css">
        <script type="text/javascript" src="<?php echo base_url()."assets/";?>jquery.plugin.js"></script>
        <script type="text/javascript" src="<?php echo base_url()."assets/";?>jquery.datepick.js"></script>
        <script type="text/javascript" src="<?php echo base_url()."assets/";?>jquery.numeric.js"></script>
                <script type="text/javascript" src="<?php echo base_url()."assets/";?>numbers.decimals.validation.js"></script>
        <script src="<?php echo base_url()."assets/";?>jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url()."assets/";?>dataTables.fixedHeader.min.js"></script>
        <script src="<?php echo base_url()."assets/";?>dataTables.bootstrap.min.js"></script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>dataTables.scroller.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>dataTables.buttons.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>buttons.flash.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>jszip.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>pdfmake.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>vfs_fonts.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>buttons.html5.min.js">
        </script>
       <script type="text/javascript" src="<?php echo base_url()."assets/";?>buttons.print.min.js">

        </script>


            <!-- Bootstrap 3.3.5 -->
            <script src="<?php echo base_url()."assets/";?>bootstrap.min.js"></script>
            <!-- AdminLTE App -->
            <script src="<?php echo base_url()."assets/";?>app.min.js"></script>

            <script src="<?php echo base_url()."assets/";?>Chart.min.js"></script>
            <script src="<?php echo base_url()."assets/";?>fastclick.min.js"></script>
    </head>
     <body class="hold-transition skin-blue sidebar-mini" >
      <div class="preload"></div>
        <div class="wrapper">
            <!-- Main Header -->
            <header class="main-header">

            <!-- Logo -->
             <a href="<?php echo base_url ()?>index.php/pages/welcome" class="logo">
                <!-- mini logo for sidebar mini 50x50 pixels -->
                <!-- logo for regular state and mobile devices -->
                 <span class="logo-lg"><b>sideson</b> investiment</span>
            </a>

            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->

                <div class="navbar-header">
                     <a href="<?php echo base_url ()?>index.php/pages/#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        Left Menu
                    </a>
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                        <i class="fa fa-bars">Top Menu</i>
                    </button>
                </div>
                <!-- Navbar Right Menu -->
                <div class="collapse navbar-collapse pull-right" id="navbar-collapse">

                    <!-- Top Menu -->
                    <ul class="nav navbar-nav">

                            <li class="dropdown">
                                 <a href="<?php echo base_url ()?>index.php/pages/#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-link"></i> <span>Settings</span> <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/billing"><i class="fa fa-circle-o"></i> Billing</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/change_password"><i class="fa fa-circle-o"></i> Change Password</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/LoginController/Logout"><i class="fa fa-circle-o"></i> Logout</a>
                                   </li>
                                </ul>
                            </li>
                            <li>
                                 <a href="<?php echo base_url ()?>index.php/pages/support_login" target="_blank"><i class="fa fa-support"></i> <span>Help</span></a>
                            </li>
                        </ul>
                </div>

            </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
           <aside class="main-sidebar">
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">

                    <!-- Sidebar user panel (optional) -->
                    <div class="user-panel">
                        <div class="pull-left image">
                            <img src="a.png" class="img-circle" alt="User Image">
                        </div>
                        <div class="pull-left info">

                            <!-- Trial -->
                            <span class="text-red text-bold"></span>
                        </div>
                    </div>
                    <!-- Sidebar Menu -->
                    <ul class="sidebar-menu">
                            <li>
                                 <a href="<?php echo base_url ()?>index.php/pages/change_branch"><i class="fa fa-eye"></i> <span>View Another Branch</span></a>
                            </li>
                            <li style="border-top: 1px solid #000;"> <a href="<?php echo base_url ()?>index.php/pages/home_branch"><i class="fa fa-circle-o text-aqua"></i> <span>Branch #1</span></a></li>
                            <li>
                                 <a href="<?php echo base_url ()?>index.php/pages/home_branch"><i class="fa fa-home"></i> <span>Home Branch</span></a>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-user"></i> <span>Users</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/staff"><i class="fa fa-circle-o"></i> View staff</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_borrower"><i class="fa fa-circle-o"></i> Add  staff</a>
                                   </li>
                                   <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_borrower"><i class="fa fa-circle-o"></i> Add User</a>
                                   </li>
                                    </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-user"></i> <span>Borrowers</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/borrowers"><i class="fa fa-circle-o"></i> View Borrowers</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/borrowers/create"><i class="fa fa-circle-o"></i> Add Borrower</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/borrowers_group"><i class="fa fa-circle-o"></i> View Borrower Groups</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/borrowers_group/create"><i class="fa fa-circle-o"></i> Add Borrowers Group</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/send_sms_to_all_borrowers"><i class="fa fa-circle-o"></i> Send SMS to All Borrowers</a>
                                   </li>

                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-balance-scale"></i> <span>Loans</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/Loan"><i class="fa fa-circle-o"></i> View All Loans</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/loan/create"><i class="fa fa-circle-o"></i> Add Loan</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/due_loans"><i class="fa fa-circle-o"></i> Due Loans</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/missed_repayments"><i class="fa fa-circle-o"></i> Missed Repayments</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_loans_past_maturity_date_branch"><i class="fa fa-circle-o"></i> Past Maturity Date</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_loans_late_1month_branch"><i class="fa fa-circle-o"></i> 1 Month Late Loans</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_loans_late_3months_branch"><i class="fa fa-circle-o"></i> 3 Months Late Loans</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/loan_calculator"><i class="fa fa-circle-o"></i> Loan Calculator</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_guarantors_branch"><i class="fa fa-circle-o"></i> Guarantors</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-dollar"></i> <span>Repayments</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/repayments"><i class="fa fa-circle-o"></i> View Repayments</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_bulk_repayments"><i class="fa fa-circle-o"></i> Add Bulk Repayments</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_bulk_repayments_csv"><i class="fa fa-circle-o"></i> Upload Repayments from CSV file</a>
                                   </li>
                                </ul>
                            </li>
                            <li>
                                 <a href="<?php echo base_url ()?>index.php/pages/collateral_register"><i class="fa fa-list"></i> <span>Collateral Register</span></a>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-file-text-o"></i> <span>Collection Sheets</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/manage_daily_collection_sheet.php?view_daily_collection=1"><i class="fa fa-circle-o"></i> Daily Collection Sheet</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/manage_daily_collection_sheet.php?view_missed_repayments_sheet=1"><i class="fa fa-circle-o"></i> Missed Repayment Sheet</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/manage_daily_collection_sheet.php?view_past_maturity_date=1"><i class="fa fa-circle-o"></i> Past Maturity Date Loans</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/send_sms"><i class="fa fa-circle-o"></i> Send SMS</a>
                                   </li>

                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-bank"></i> <span>Savings</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li class="active">
                                         <a href="<?php echo base_url ()?>index.php/savings"><i class="fa fa-circle-o"></i> View Savings Accounts</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/savings/create"><i class="fa fa-circle-o"></i> Add Savings Account</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_bulk_transactions"><i class="fa fa-circle-o"></i> Add Bulk Transactions</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_savings_transactions"><i class="fa fa-circle-o"></i> View Savings Transactions</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/savings_charts"><i class="fa fa-circle-o"></i> Savings Charts</a>
                                   </li>
                                    <li >
                                         <a href="<?php echo base_url ()?>index.php/pages/savings_report"><i class="fa fa-circle-o"></i> Savings Report</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-paypal"></i> <span>Payroll</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_payroll_branch"><i class="fa fa-circle-o"></i> View Payroll</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/select_staff"><i class="fa fa-circle-o"></i> Add Payroll</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-share"></i> <span>Expenses</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_expenses_branch"><i class="fa fa-circle-o"></i> View Expenses</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_expense"><i class="fa fa-circle-o"></i> Add Expense</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-plus"></i> <span>Other Income</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_other_income_branch"><i class="fa fa-circle-o"></i> View Other Income</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_other_income"><i class="fa fa-circle-o"></i> Add Other Income</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-suitcase"></i> <span>Asset Management</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_asset_management_branch"><i class="fa fa-circle-o"></i> View Asset Management</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/add_asset_management"><i class="fa fa-circle-o"></i> Add Asset Management</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-industry"></i> <span>Reports</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/balance_due_report.php?report_type=borrowers"><i class="fa fa-circle-o"></i> Borrowers Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_collections_report_branch"><i class="fa fa-circle-o"></i> Collections Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/collector_report"><i class="fa fa-circle-o"></i> Collector Report (Staff)</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/deferred_income"><i class="fa fa-circle-o"></i> Deferred Income</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/disbursement_report"><i class="fa fa-circle-o"></i> Disbursement Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/fees_report"><i class="fa fa-circle-o"></i> Fees Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/balance_due_report.php?report_type=loan_officers"><i class="fa fa-circle-o"></i> Loan Officer Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/balance_due_report.php?report_type=loan_products"><i class="fa fa-circle-o"></i> Loan Products Report</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/mfrs_ratios"><i class="fa fa-circle-o"></i> MFRS Ratios</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/portfolio_at_risk"><i class="fa fa-circle-o"></i> Portfolio At Risk (PAR)</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/all_entries"><i class="fa fa-circle-o"></i> All Entries</a>
                                   </li>
                                </ul>
                            </li>
                            <li class="treeview">
                                 <a href="<?php echo base_url ()?>index.php/pages/#"><i class="fa fa-book"></i> <span>Accounting</span> <i class="fa fa-angle-left pull-right"></i></a>
                                <ul class="treeview-menu">
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_cash_flow_branch"><i class="fa fa-circle-o"></i> Cash flow Accumulated</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_cash_flow_monthly_branch"><i class="fa fa-circle-o"></i> Cash Flow Monthly</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_cash_flow_projection_branch"><i class="fa fa-circle-o"></i> Cash Flow Projection</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/view_profit_loss_branch"><i class="fa fa-circle-o"></i> Profit / Loss</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/balance_sheet"><i class="fa fa-circle-o"></i> Balance Sheet</a>
                                   </li>
                                    <li>
                                         <a href="<?php echo base_url ()?>index.php/pages/index"><i class="fa fa-circle-o"></i> Accounting Integration</a>
                                   </li>
                                </ul>
                            </li>
                        </ul>
                </section>
            </aside>


</html>
