<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Cash <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Apr <?php echo form_error('Apr') ?></label>
            <input type="text" class="form-control" name="Apr" id="Apr" placeholder="Apr" value="<?php echo $Apr; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">May <?php echo form_error('May') ?></label>
            <input type="text" class="form-control" name="May" id="May" placeholder="May" value="<?php echo $May; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">June <?php echo form_error('June') ?></label>
            <input type="text" class="form-control" name="June" id="June" placeholder="June" value="<?php echo $June; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">July <?php echo form_error('July') ?></label>
            <input type="text" class="form-control" name="July" id="July" placeholder="July" value="<?php echo $July; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Aug <?php echo form_error('Aug') ?></label>
            <input type="text" class="form-control" name="Aug" id="Aug" placeholder="Aug" value="<?php echo $Aug; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Sep <?php echo form_error('Sep') ?></label>
            <input type="text" class="form-control" name="Sep" id="Sep" placeholder="Sep" value="<?php echo $Sep; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Type <?php echo form_error('Type') ?></label>
            <input type="text" class="form-control" name="Type" id="Type" placeholder="Type" value="<?php echo $Type; ?>" />
        </div>
	    <input type="hidden" name="cash_id" value="<?php echo $cash_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('cash') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>