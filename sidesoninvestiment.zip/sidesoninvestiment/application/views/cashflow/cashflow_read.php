<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Cashflow Read</h2>
        <table class="table">
	    <tr><td>Deposit</td><td><?php echo $deposit; ?></td></tr>
	    <tr><td>Withdrawal</td><td><?php echo $withdrawal; ?></td></tr>
	    <tr><td>Other Income</td><td><?php echo $other_income; ?></td></tr>
	    <tr><td>Loan Released</td><td><?php echo $loan_released; ?></td></tr>
	    <tr><td>Principal Repayment</td><td><?php echo $principal_repayment; ?></td></tr>
	    <tr><td>Penalty Repayment</td><td><?php echo $penalty_repayment; ?></td></tr>
	    <tr><td>Interest Repayment</td><td><?php echo $interest_repayment; ?></td></tr>
	    <tr><td>Fee Repayment</td><td><?php echo $fee_repayment; ?></td></tr>
	    <tr><td>Expences</td><td><?php echo $expences; ?></td></tr>
	    <tr><td>Deductable Loan Fee</td><td><?php echo $deductable_loan_fee; ?></td></tr>
	    <tr><td>Branch Capital</td><td><?php echo $branch_capital; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('cashflow') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>