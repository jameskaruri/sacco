<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Payroll Read</h2>
        <table class="table">
	    <tr><td>Employee Name</td><td><?php echo $Employee_name; ?></td></tr>
	    <tr><td>Payroll Date</td><td><?php echo $Payroll_Date; ?></td></tr>
	    <tr><td>Business Name</td><td><?php echo $Business_Name; ?></td></tr>
	    <tr><td>Basic Pay</td><td><?php echo $Basic_Pay; ?></td></tr>
	    <tr><td>Overtime</td><td><?php echo $Overtime; ?></td></tr>
	    <tr><td>Paid Leaves</td><td><?php echo $Paid_Leaves; ?></td></tr>
	    <tr><td>Transport Allowance</td><td><?php echo $Transport_Allowance; ?></td></tr>
	    <tr><td>Medical Allowance</td><td><?php echo $Medical_Allowance; ?></td></tr>
	    <tr><td>Bonus</td><td><?php echo $Bonus; ?></td></tr>
	    <tr><td>Other Allowance</td><td><?php echo $Other_Allowance; ?></td></tr>
	    <tr><td>Pension</td><td><?php echo $Pension; ?></td></tr>
	    <tr><td>Health Insurance</td><td><?php echo $Health_Insurance; ?></td></tr>
	    <tr><td>Unpaid Leave</td><td><?php echo $Unpaid_Leave; ?></td></tr>
	    <tr><td>Tax Deduction</td><td><?php echo $Tax_Deduction; ?></td></tr>
	    <tr><td>Salary Loan</td><td><?php echo $Salary_Loan; ?></td></tr>
	    <tr><td>Total Pay</td><td><?php echo $Total_Pay; ?></td></tr>
	    <tr><td>Total Deductions</td><td><?php echo $Total_Deductions; ?></td></tr>
	    <tr><td>Net Pay</td><td><?php echo $Net_Pay; ?></td></tr>
	    <tr><td>Payment Method</td><td><?php echo $Payment_Method; ?></td></tr>
	    <tr><td>Bank Name</td><td><?php echo $Bank_Name; ?></td></tr>
	    <tr><td>Account Number</td><td><?php echo $Account_Number; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $Description; ?></td></tr>
	    <tr><td>Paid Amount</td><td><?php echo $Paid_Amount; ?></td></tr>
	    <tr><td>Comments</td><td><?php echo $Comments; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('payroll') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>