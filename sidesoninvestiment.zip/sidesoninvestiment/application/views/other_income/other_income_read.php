<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Other_income Read</h2>
        <table class="table">
	    <tr><td>Type</td><td><?php echo $Type; ?></td></tr>
	    <tr><td>Amount</td><td><?php echo $Amount; ?></td></tr>
	    <tr><td>Transaction Date</td><td><?php echo $Transaction_Date; ?></td></tr>
	    <tr><td>Recurring</td><td><?php echo $Recurring; ?></td></tr>
	    <tr><td>Recurring Other Income</td><td><?php echo $Recurring_Other_Income; ?></td></tr>
	    <tr><td>Description</td><td><?php echo $Description; ?></td></tr>
	    <tr><td>Receipt</td><td><?php echo $Receipt; ?></td></tr>
	    <tr><td>Time Date</td><td><?php echo $time_date; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('other_income') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>