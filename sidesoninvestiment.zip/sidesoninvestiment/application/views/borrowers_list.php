<!doctype html>
<!DOCTYPE html>
<html>
    <head>

      <div class="content-wrapper">

                <!-- Main content -->
                <section class="content">

            <script>
        $(document).ready(function () {
          $(".slidingDiv").hide();
          $('.show_hide').click(function (e) {
            $(".slidingDiv").slideToggle("fast");
            var val = $(this).text() == "Hide" ? "Show" : "Hide";
            $(this).hide().text(val).fadeIn("fast");
            e.preventDefault();
          });
        });</script>



         <body>

           <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <h2 style="margin-top:0px"><b>Borrowers List</b></h2>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div>
            <div class="col-md-4 text-right">
                <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div><?php echo anchor(site_url('borrowers/create'), 'Add', 'class="btn btn-primary"'); ?>

        </div>
        </div>

            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                    <div class="pull-left">
                        <small>(Select <b>All</b> in <b>Show</b> to export all data)</small>
                    </div>
                </div>

                <div class="col-xs-6">
                    <div class="pull-right">


                    </div>
                </div>
            </div>
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
        <table  id="mytable" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
               <thead>
                            <tr style="background-color: #D1F9FF">
                                         <th class="not-export-col" width="80px">No</th>
        <th>Borrower Picture</th>
		    <th>Name</th>

		    <th>Mobile</th>
            <th>Age</th>




		    <th width="200px">Action</th>
                </tr>
            </thead>

        </table>
        </div></div></div>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();

                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },

                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    "fixedHeader": {
                    "header": true,
                    "footer": true,
                },
                
                autoWidth: true,
                responsive: true,
                searching:true,
                    processing: true,
                    serverSide: true,
                stateSave: true,
                    ajax: {"url": "borrowers/json", "type": "POST"},
                    columns: [
                        {
                            "data": "borrowers_id",
                            "orderable": false,
                        },{"data": "borrower_picture","render":function(data,type,row,meta){
                            return'<img src="'+data+'<?php echo base_url('upload') ?>"/>';
                        }},{"data": null, render: function ( data, type, row ) {
                // Combine the first and last names into a single table field
                return data.borrower_title+' '+data.borrower_surname+' '+data.borrower_firstname+' '+data.borrower_lastname;}},{"data": "borrower_mobile"},{"data": "borrower_dob"},

                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    select: true,
        export_button: [
           
            {
                extend: 'collection',
                text: 'Export',
                export_button: [
                    'copy',
                    'excel',
                    'csv',
                    'pdf',
                    'print',
                ]
            }
        ],
    
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }

                });$.fn.dataTable.ext.errMode = 'throw';

            });
        </script>
    </body>
</html>
