<!doctype html>
<html>
    <head>
           <div class="content-wrapper">
                <!-- Content Header (Page header) -->
               
                <!-- Main content -->
               
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                   
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            
                    </div>
                </div>
            </div> 
            
            

    </head>
    <body>

        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <h2 style="margin-top:0px"><b>Borrowers Read</b></h2>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div></div>
       
        <section class="content">
        <div class="box box-widget">
            <div class="box-header with-border">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="user-block">
                           
                                <img src="<?php echo $borrower_picture; ?>" >
                                
                                
                            <span class="username">
                                <?php echo $borrower_surname; ?> <?php echo $borrower_firstname; ?> <?php echo $borrower_lastname; ?>
                            <span class="description" style="font-size:13px; color:#000000"><?php echo 'sio' ,$borrowers_id ?><br>
                        
                               <a href=  "<?php echo site_url('borrowers/update'); ?>">Edit</a><br>Business Ownership; <?php echo $Business_owner; ?><br><?php echo $borrower_gender; ?>, <?php echo $borrower_dob; ?>
                            </span>
                        </div><!-- /.user-block -->         
                    </div></span>
                    <div class="col-sm-2">
                        <ul class="list-unstyled">
                        <li><b>Address:</b>  <?php echo $borrower_address; ?></li>
                        <li><b>City:</b>  <?php echo $borrower_town; ?></li>
                        <li><b>Street:</b>  <?php echo $borrower_street; ?></li>
                        <li><b>Estate:</b>  <?php echo $borrower_estate; ?></li>
                        <li><b>Nearest Common Feature:</b>  <?php echo $borrower_nearestcommonfeature; ?></li>
                        <li><b>Zipcode:</b> <?php echo $borrower_zipcode; ?></li></ul></div>
                        <div class="col-sm-3">
                        <ul class="list-unstyled">
                        <li><b>Business Name:</b>    <?php echo $borrower_business_name; ?></li>
                        <li><b>Business Nature:</b>    <?php echo $borrower_business_nature; ?></li>
                        <li><b>Business Address:</b>   <?php echo $zipcode1; ?>, <?php echo $address1; ?> <?php echo $town1; ?>.</li>
                        <li><b>Business Estate:</b>    <?php echo $borrower_estate; ?></li>
                        <li><b>Business Nearest Common Feature:</b>    <?php echo $borrower_nearestcommonfeature; ?></li>
                        <li><b>Business Location:</b>    <?php echo $business_location; ?></li>
                        <li><b>Owner Location:</b>    <?php echo $residence_location; ?></li></ul></div>
                        <div class="col-sm-2">
                        <ul class="list-unstyled">
                        <li><b>Id Number:</b>    <?php echo $borrower_id_number; ?></li>
                        <li><b>Email:</b>    <?php echo $borrower_email; ?></li>
                        <li><b>Mobile:</b>   <?php echo $borrower_mobile; ?></li>
                        <li><b>Description:</b>    <?php echo $borrower_description; ?></li>
                        <li><b>id:</b>    <?php echo $borrower_id; ?></li></ul></div>
                        
                        
	    
	  
	  
	   
	  
	    
	    
	    <tr><td></td><td><a href="<?php echo site_url('borrowers') ?>" class="btn btn-default">Back</a></td></tr>
	
        </body>
</html>