
<!DOCTYPE html>
<html>
    <head>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header"><h1><b></b>Members</b></h1>
                </section>

                <!-- Main content -->
                <section class="content">
        <script>
        $(document).ready(function () {
          $(".slidingDiv").hide();
          $('.show_hide').click(function (e) {
            $(".slidingDiv").slideToggle("fast");
            var val = $(this).text() == "Hide" ? "Show" : "Hide";
            $(this).hide().text(val).fadeIn("fast");
            e.preventDefault();
          });
        });
        </script>

            <div class="row">
                <div class="col-xs">
                    <div class="pull-left  btn-default" id="export_button">

                    </div>

                    </div>
                </div>
        <div class="box box-info">
            <div class="box-body">
                <div class="col-sm-12 table-responsive">
                    <table id="view-borrowers" class="table table-bordered table-condensed table-hover dataTable"  style="width: 100%">
                        <thead>
                          <tr style="background-color: #D1F9FF">
                                       <th class="not-export-col" width="80px">Picture</th>

                                      <th>Name</th>

                                      <th>Mobile</th>
                                           <th>Age</th>
                                      <th width="200px">Action</th>
              </tr>
                       </thead>

                    </table>
                </div>
            </div>
        </div>

           <script type="text/javascript" language="javascript">

        $(document).ready(function() {
            var dataTable = $('#view-borrowers').DataTable( {
                "fixedHeader": {
                    "header": true,
                    "footer": true,
                },

                "autoWidth": true,
                "lengthMenu": [[10, 20, 100, 250, 500, 5000], [10, 20, 100, 250, 500, "All (Slow)"]],
                "iDisplayLength": 10,
                "processing": true,
                "serverSide": false,
                "responsive": true,
                searching:true,
                stateSave: true,
                ajax: {"url": "borrowers/json", "type": "POST"},
                columns: [
                    {
                      "data": "borrower_picture","render":function(data,type,row,meta){
                          return'<img src="'+data+'<?php echo base_url('./upload') ?>"/>';
                      },
                        "orderable": false
                    },{"data": null, render: function ( data, type, row ) {
            // Combine the first and last names into a single table field
            return data.borrower_title+' '+data.borrower_surname+' '+data.borrower_firstname+' '+data.borrower_lastname;}},{"data": "borrower_mobile"},{"data": "borrower_dob"},
                    {
                        "data" : "action",
                        "orderable": false,
                        "className" : "text-center"
                    }
                ],
                order: [[0, 'desc']],
            } );
             var buttons = new $.fn.dataTable.Buttons(dataTable, {
               "buttons": [
                  {
                      extend: 'collection',
                      text: 'Export Data',
                      buttons: [
                          'copy',
                          'excel',
                          'pdf',
                          'print'
                      ]
                  }
              ]
            }).container().appendTo($('#export_button'));


        } );

    </script>

    <script>
    $( "#pre_loader" ).hide();
    </script>

                    </section>
                </div><!-- /.content-wrapper -->
            </div><!-- ./wrapper -->

            <!-- REQUIRED JS SCRIPTS -->
            <script type="text/javascript">
            $(".numeric").numeric();
            $(".positive").numeric({ negative: false });
            $(".positive-integer").numeric({ decimal: false, negative: false });
            $(".decimal-2-places").numeric({ decimalPlaces: 2 });
            $(".decimal-4-places").numeric({ decimalPlaces: 4 });
            $("#remove").click(
                function(e)
                {
                    e.preventDefault();
                    $(".numeric,.positive,.positive-integer,.decimal-2-places,.decimal-4-places").removeNumeric();
                }
            );

</script>

    </body>
</html>
