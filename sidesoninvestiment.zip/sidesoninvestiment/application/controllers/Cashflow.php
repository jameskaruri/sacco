<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Cashflow extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Cashflow_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('cashflow/cashflow_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Cashflow_model->json();
    }

    public function read($id) 
    {
        $row = $this->Cashflow_model->get_by_id($id);
        if ($row) {
            $data = array(
		'cash_flow_id' => $row->cash_flow_id,
		'deposit' => $row->deposit,
		'withdrawal' => $row->withdrawal,
		'other_income' => $row->other_income,
		'loan_released' => $row->loan_released,
		'principal_repayment' => $row->principal_repayment,
		'penalty_repayment' => $row->penalty_repayment,
		'interest_repayment' => $row->interest_repayment,
		'fee_repayment' => $row->fee_repayment,
		'expences' => $row->expences,
		'deductable_loan_fee' => $row->deductable_loan_fee,
		'branch_capital' => $row->branch_capital,
		'time_date' => $row->time_date,
	    );
            $this->load->view('cashflow/cashflow_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cashflow'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('cashflow/create_action'),
	    'cash_flow_id' => set_value('cash_flow_id'),
	    'deposit' => set_value('deposit'),
	    'withdrawal' => set_value('withdrawal'),
	    'other_income' => set_value('other_income'),
	    'loan_released' => set_value('loan_released'),
	    'principal_repayment' => set_value('principal_repayment'),
	    'penalty_repayment' => set_value('penalty_repayment'),
	    'interest_repayment' => set_value('interest_repayment'),
	    'fee_repayment' => set_value('fee_repayment'),
	    'expences' => set_value('expences'),
	    'deductable_loan_fee' => set_value('deductable_loan_fee'),
	    'branch_capital' => set_value('branch_capital'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('cashflow/cashflow_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'deposit' => $this->input->post('deposit',TRUE),
		'withdrawal' => $this->input->post('withdrawal',TRUE),
		'other_income' => $this->input->post('other_income',TRUE),
		'loan_released' => $this->input->post('loan_released',TRUE),
		'principal_repayment' => $this->input->post('principal_repayment',TRUE),
		'penalty_repayment' => $this->input->post('penalty_repayment',TRUE),
		'interest_repayment' => $this->input->post('interest_repayment',TRUE),
		'fee_repayment' => $this->input->post('fee_repayment',TRUE),
		'expences' => $this->input->post('expences',TRUE),
		'deductable_loan_fee' => $this->input->post('deductable_loan_fee',TRUE),
		'branch_capital' => $this->input->post('branch_capital',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Cashflow_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('cashflow'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Cashflow_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('cashflow/update_action'),
		'cash_flow_id' => set_value('cash_flow_id', $row->cash_flow_id),
		'deposit' => set_value('deposit', $row->deposit),
		'withdrawal' => set_value('withdrawal', $row->withdrawal),
		'other_income' => set_value('other_income', $row->other_income),
		'loan_released' => set_value('loan_released', $row->loan_released),
		'principal_repayment' => set_value('principal_repayment', $row->principal_repayment),
		'penalty_repayment' => set_value('penalty_repayment', $row->penalty_repayment),
		'interest_repayment' => set_value('interest_repayment', $row->interest_repayment),
		'fee_repayment' => set_value('fee_repayment', $row->fee_repayment),
		'expences' => set_value('expences', $row->expences),
		'deductable_loan_fee' => set_value('deductable_loan_fee', $row->deductable_loan_fee),
		'branch_capital' => set_value('branch_capital', $row->branch_capital),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('cashflow/cashflow_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cashflow'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('cash_flow_id', TRUE));
        } else {
            $data = array(
		'deposit' => $this->input->post('deposit',TRUE),
		'withdrawal' => $this->input->post('withdrawal',TRUE),
		'other_income' => $this->input->post('other_income',TRUE),
		'loan_released' => $this->input->post('loan_released',TRUE),
		'principal_repayment' => $this->input->post('principal_repayment',TRUE),
		'penalty_repayment' => $this->input->post('penalty_repayment',TRUE),
		'interest_repayment' => $this->input->post('interest_repayment',TRUE),
		'fee_repayment' => $this->input->post('fee_repayment',TRUE),
		'expences' => $this->input->post('expences',TRUE),
		'deductable_loan_fee' => $this->input->post('deductable_loan_fee',TRUE),
		'branch_capital' => $this->input->post('branch_capital',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Cashflow_model->update($this->input->post('cash_flow_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('cashflow'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Cashflow_model->get_by_id($id);

        if ($row) {
            $this->Cashflow_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('cashflow'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('cashflow'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('deposit', 'deposit', 'trim|required');
	$this->form_validation->set_rules('withdrawal', 'withdrawal', 'trim|required');
	$this->form_validation->set_rules('other_income', 'other income', 'trim|required');
	$this->form_validation->set_rules('loan_released', 'loan released', 'trim|required');
	$this->form_validation->set_rules('principal_repayment', 'principal repayment', 'trim|required');
	$this->form_validation->set_rules('penalty_repayment', 'penalty repayment', 'trim|required');
	$this->form_validation->set_rules('interest_repayment', 'interest repayment', 'trim|required');
	$this->form_validation->set_rules('fee_repayment', 'fee repayment', 'trim|required');
	$this->form_validation->set_rules('expences', 'expences', 'trim|required');
	$this->form_validation->set_rules('deductable_loan_fee', 'deductable loan fee', 'trim|required');
	$this->form_validation->set_rules('branch_capital', 'branch capital', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('cash_flow_id', 'cash_flow_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Cashflow.php */
/* Location: ./application/controllers/Cashflow.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:19 */
/* http://harviacode.com */