<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Cashflow <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Deposit <?php echo form_error('deposit') ?></label>
            <input type="text" class="form-control" name="deposit" id="deposit" placeholder="Deposit" value="<?php echo $deposit; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Withdrawal <?php echo form_error('withdrawal') ?></label>
            <input type="text" class="form-control" name="withdrawal" id="withdrawal" placeholder="Withdrawal" value="<?php echo $withdrawal; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Other Income <?php echo form_error('other_income') ?></label>
            <input type="text" class="form-control" name="other_income" id="other_income" placeholder="Other Income" value="<?php echo $other_income; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Released <?php echo form_error('loan_released') ?></label>
            <input type="text" class="form-control" name="loan_released" id="loan_released" placeholder="Loan Released" value="<?php echo $loan_released; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Principal Repayment <?php echo form_error('principal_repayment') ?></label>
            <input type="text" class="form-control" name="principal_repayment" id="principal_repayment" placeholder="Principal Repayment" value="<?php echo $principal_repayment; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Penalty Repayment <?php echo form_error('penalty_repayment') ?></label>
            <input type="text" class="form-control" name="penalty_repayment" id="penalty_repayment" placeholder="Penalty Repayment" value="<?php echo $penalty_repayment; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Interest Repayment <?php echo form_error('interest_repayment') ?></label>
            <input type="text" class="form-control" name="interest_repayment" id="interest_repayment" placeholder="Interest Repayment" value="<?php echo $interest_repayment; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Fee Repayment <?php echo form_error('fee_repayment') ?></label>
            <input type="text" class="form-control" name="fee_repayment" id="fee_repayment" placeholder="Fee Repayment" value="<?php echo $fee_repayment; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Expences <?php echo form_error('expences') ?></label>
            <input type="text" class="form-control" name="expences" id="expences" placeholder="Expences" value="<?php echo $expences; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Deductable Loan Fee <?php echo form_error('deductable_loan_fee') ?></label>
            <input type="text" class="form-control" name="deductable_loan_fee" id="deductable_loan_fee" placeholder="Deductable Loan Fee" value="<?php echo $deductable_loan_fee; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Branch Capital <?php echo form_error('branch_capital') ?></label>
            <input type="text" class="form-control" name="branch_capital" id="branch_capital" placeholder="Branch Capital" value="<?php echo $branch_capital; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="cash_flow_id" value="<?php echo $cash_flow_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('cashflow') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>