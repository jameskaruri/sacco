<!doctype html>
<html>
    <head>

    </head>
    <body>
      <div class="content-wrapper">
          <!-- Content Header (Page header) -->


          <!-- Main content -->
          <section class="content">
  <div class="box box-info">
        <h2 style="margin-top:0px">Add Loan</h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
          <label for="int">Borrowers Id <?php echo form_error('borrowers_id') ?></label>
            <select data-placeholder="Choose Borrower or Search by Name"  class="form-control select2" ame="borrowers_id" id="borrowers_id" value="<?php echo $borrowers_id; ?>"  style="width: 100%;" required>
                <option value=""></option>
                <?php
                                $borrowers_get = $this->db->get('borrowers')->result_array();
                                foreach($borrowers_get as $row): ?>
                                    <option value="<?php echo $row['borrowers_id'];?>">
                                    <?php echo $row['borrower_title'];?>&nbsp&nbsp<?php echo $row['borrower_surname'];?>&nbsp&nbsp<?php echo $row['borrower_firstname'];?>&nbsp&nbsp<?php echo $row['borrower_lastname'];?>
                                    </option>
                                <?php
                                endforeach;
                              ?>
    <script src="<?php echo base_url()."assets/";?>select2.full.min.js"></script>
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2({
            allowClear: true,
            placeholder: "Select a value"
        });
      });
    </script>


        </div>
	    <div class="form-group">
            <label for="int">Loan Product <?php echo form_error('Loan_product') ?></label>
            <input type="text" class="form-control" name="Loan_product" id="Loan_product" placeholder="Loan Product" value="<?php echo $Loan_product; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan <?php echo form_error('loan') ?></label>
            <input type="text" class="form-control" name="loan" id="loan" placeholder="Loan" value="<?php echo $loan; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Disbursed By Id <?php echo form_error('loan_disbursed_by_id') ?></label>
            <input type="text" class="form-control" name="loan_disbursed_by_id" id="loan_disbursed_by_id" placeholder="Loan Disbursed By Id" value="<?php echo $loan_disbursed_by_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Principal Amount <?php echo form_error('loan_principal_amount') ?></label>
            <input type="text" class="form-control" name="loan_principal_amount" id="loan_principal_amount" placeholder="Loan Principal Amount" value="<?php echo $loan_principal_amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Released Date <?php echo form_error('loan_released_date') ?></label>
            <input type="text" class="form-control" name="loan_released_date" id="loan_released_date" placeholder="Loan Released Date" value="<?php echo $loan_released_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Interest Method <?php echo form_error('loan_interest_method') ?></label>
            <input type="text" class="form-control" name="loan_interest_method" id="loan_interest_method" placeholder="Loan Interest Method" value="<?php echo $loan_interest_method; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Interest Type <?php echo form_error('loan_interest_type') ?></label>
            <input type="text" class="form-control" name="loan_interest_type" id="loan_interest_type" placeholder="Loan Interest Type" value="<?php echo $loan_interest_type; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Interest <?php echo form_error('loan_interest') ?></label>
            <input type="text" class="form-control" name="loan_interest" id="loan_interest" placeholder="Loan Interest" value="<?php echo $loan_interest; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Interest Period <?php echo form_error('loan_interest_period') ?></label>
            <input type="text" class="form-control" name="loan_interest_period" id="loan_interest_period" placeholder="Loan Interest Period" value="<?php echo $loan_interest_period; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Duration <?php echo form_error('loan_duration') ?></label>
            <input type="text" class="form-control" name="loan_duration" id="loan_duration" placeholder="Loan Duration" value="<?php echo $loan_duration; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Duration Period <?php echo form_error('loan_duration_period') ?></label>
            <input type="text" class="form-control" name="loan_duration_period" id="loan_duration_period" placeholder="Loan Duration Period" value="<?php echo $loan_duration_period; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Payment Scheme Id <?php echo form_error('loan_payment_scheme_id') ?></label>
            <input type="text" class="form-control" name="loan_payment_scheme_id" id="loan_payment_scheme_id" placeholder="Loan Payment Scheme Id" value="<?php echo $loan_payment_scheme_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Num Of Repayments <?php echo form_error('loan_num_of_repayments') ?></label>
            <input type="text" class="form-control" name="loan_num_of_repayments" id="loan_num_of_repayments" placeholder="Loan Num Of Repayments" value="<?php echo $loan_num_of_repayments; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Decimal Places <?php echo form_error('loan_decimal_places') ?></label>
            <input type="text" class="form-control" name="loan_decimal_places" id="loan_decimal_places" placeholder="Loan Decimal Places" value="<?php echo $loan_decimal_places; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Loan Interest Start Date <?php echo form_error('loan_interest_start_date') ?></label>
            <input type="text" class="form-control" name="loan_interest_start_date" id="loan_interest_start_date" placeholder="Loan Interest Start Date" value="<?php echo $loan_interest_start_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan First Repayment Date <?php echo form_error('loan_first_repayment_date') ?></label>
            <input type="text" class="form-control" name="loan_first_repayment_date" id="loan_first_repayment_date" placeholder="Loan First Repayment Date" value="<?php echo $loan_first_repayment_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">First Repayment Amount <?php echo form_error('first_repayment_amount') ?></label>
            <input type="text" class="form-control" name="first_repayment_amount" id="first_repayment_amount" placeholder="First Repayment Amount" value="<?php echo $first_repayment_amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Last Repayment Amount <?php echo form_error('last_repayment_amount') ?></label>
            <input type="text" class="form-control" name="last_repayment_amount" id="last_repayment_amount" placeholder="Last Repayment Amount" value="<?php echo $last_repayment_amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Loan Override Maturity Date <?php echo form_error('loan_override_maturity_date') ?></label>
            <input type="text" class="form-control" name="loan_override_maturity_date" id="loan_override_maturity_date" placeholder="Loan Override Maturity Date" value="<?php echo $loan_override_maturity_date; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Override Each Repayment Amount <?php echo form_error('override_each_repayment_amount') ?></label>
            <input type="text" class="form-control" name="override_each_repayment_amount" id="override_each_repayment_amount" placeholder="Override Each Repayment Amount" value="<?php echo $override_each_repayment_amount; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Interest Schedule <?php echo form_error('loan_interest_schedule') ?></label>
            <input type="text" class="form-control" name="loan_interest_schedule" id="loan_interest_schedule" placeholder="Loan Interest Schedule" value="<?php echo $loan_interest_schedule; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Gaurantor Id <?php echo form_error('gaurantor_id') ?></label>
            <input type="text" class="form-control" name="gaurantor_id" id="gaurantor_id" placeholder="Gaurantor Id" value="<?php echo $gaurantor_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Gaurantor Id2 <?php echo form_error('gaurantor_id2') ?></label>
            <input type="text" class="form-control" name="gaurantor_id2" id="gaurantor_id2" placeholder="Gaurantor Id2" value="<?php echo $gaurantor_id2; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Loan Description <?php echo form_error('loan_description') ?></label>
            <input type="text" class="form-control" name="loan_description" id="loan_description" placeholder="Loan Description" value="<?php echo $loan_description; ?>" />
        </div>
	    <div class="form-group">
            <label for="longblob">Loan Files <?php echo form_error('loan_files') ?></label>
            <input type="text" class="form-control" name="loan_files" id="loan_files" placeholder="Loan Files" value="<?php echo $loan_files; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Loan Status Id <?php echo form_error('loan_status_id') ?></label>
            <input type="text" class="form-control" name="loan_status_id" id="loan_status_id" placeholder="Loan Status Id" value="<?php echo $loan_status_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">User Id <?php echo form_error('user_id') ?></label>
            <input type="text" class="form-control" name="user_id" id="user_id" placeholder="User Id" value="<?php echo $user_id; ?>" />
        </div>
	    <div class="form-group">
            <label for="timestamp">Time Date <?php echo form_error('time_date') ?></label>
            <input type="text" class="form-control" name="time_date" id="time_date" placeholder="Time Date" value="<?php echo $time_date; ?>" />
        </div>
	    <input type="hidden" name="loan_id" value="<?php echo $loan_id; ?>" />
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button>
	    <a href="<?php echo site_url('loan') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>
