<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">LoanProduct <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Loan Prduct Name <?php echo form_error('Loan_prduct_name') ?></label>
            <input type="text" class="form-control" name="Loan_prduct_name" id="Loan_prduct_name" placeholder="Loan Prduct Name" value="<?php echo $Loan_prduct_name; ?>" />
        </div>
	    <input type="hidden" name="Loan_prduct_id" value="<?php echo $Loan_prduct_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('loanproduct') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>