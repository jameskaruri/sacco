<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Colletral extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Colletral_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->load->view('colletral/colletral_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Colletral_model->json();
    }

    public function read($id) 
    {
        $row = $this->Colletral_model->get_by_id($id);
        if ($row) {
            $data = array(
		'colletral_id' => $row->colletral_id,
		'borrowers_id' => $row->borrowers_id,
		'type' => $row->type,
		'productname' => $row->productname,
		'register' => $row->register,
		'value' => $row->value,
		'colletralstatus' => $row->colletralstatus,
		'colletralstatus date' => $row->colletralstatus date,
		'serialno' => $row->serialno,
		'modelname' => $row->modelname,
		'datemanufacured' => $row->datemanufacured,
		'colletracondition' => $row->colletracondition,
		'address' => $row->address,
		'description' => $row->description,
		'photo' => $row->photo,
		'file' => $row->file,
		'time_date' => $row->time_date,
	    );
            $this->load->view('colletral/colletral_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('colletral'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('colletral/create_action'),
	    'colletral_id' => set_value('colletral_id'),
	    'borrowers_id' => set_value('borrowers_id'),
	    'type' => set_value('type'),
	    'productname' => set_value('productname'),
	    'register' => set_value('register'),
	    'value' => set_value('value'),
	    'colletralstatus' => set_value('colletralstatus'),
	    'colletralstatus date' => set_value('colletralstatus date'),
	    'serialno' => set_value('serialno'),
	    'modelname' => set_value('modelname'),
	    'datemanufacured' => set_value('datemanufacured'),
	    'colletracondition' => set_value('colletracondition'),
	    'address' => set_value('address'),
	    'description' => set_value('description'),
	    'photo' => set_value('photo'),
	    'file' => set_value('file'),
	    'time_date' => set_value('time_date'),
	);
        $this->load->view('colletral/colletral_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'type' => $this->input->post('type',TRUE),
		'productname' => $this->input->post('productname',TRUE),
		'register' => $this->input->post('register',TRUE),
		'value' => $this->input->post('value',TRUE),
		'colletralstatus' => $this->input->post('colletralstatus',TRUE),
		'colletralstatus date' => $this->input->post('colletralstatus date',TRUE),
		'serialno' => $this->input->post('serialno',TRUE),
		'modelname' => $this->input->post('modelname',TRUE),
		'datemanufacured' => $this->input->post('datemanufacured',TRUE),
		'colletracondition' => $this->input->post('colletracondition',TRUE),
		'address' => $this->input->post('address',TRUE),
		'description' => $this->input->post('description',TRUE),
		'photo' => $this->input->post('photo',TRUE),
		'file' => $this->input->post('file',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Colletral_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('colletral'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Colletral_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('colletral/update_action'),
		'colletral_id' => set_value('colletral_id', $row->colletral_id),
		'borrowers_id' => set_value('borrowers_id', $row->borrowers_id),
		'type' => set_value('type', $row->type),
		'productname' => set_value('productname', $row->productname),
		'register' => set_value('register', $row->register),
		'value' => set_value('value', $row->value),
		'colletralstatus' => set_value('colletralstatus', $row->colletralstatus),
		'colletralstatus date' => set_value('colletralstatus date', $row->colletralstatus date),
		'serialno' => set_value('serialno', $row->serialno),
		'modelname' => set_value('modelname', $row->modelname),
		'datemanufacured' => set_value('datemanufacured', $row->datemanufacured),
		'colletracondition' => set_value('colletracondition', $row->colletracondition),
		'address' => set_value('address', $row->address),
		'description' => set_value('description', $row->description),
		'photo' => set_value('photo', $row->photo),
		'file' => set_value('file', $row->file),
		'time_date' => set_value('time_date', $row->time_date),
	    );
            $this->load->view('colletral/colletral_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('colletral'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('colletral_id', TRUE));
        } else {
            $data = array(
		'borrowers_id' => $this->input->post('borrowers_id',TRUE),
		'type' => $this->input->post('type',TRUE),
		'productname' => $this->input->post('productname',TRUE),
		'register' => $this->input->post('register',TRUE),
		'value' => $this->input->post('value',TRUE),
		'colletralstatus' => $this->input->post('colletralstatus',TRUE),
		'colletralstatus date' => $this->input->post('colletralstatus date',TRUE),
		'serialno' => $this->input->post('serialno',TRUE),
		'modelname' => $this->input->post('modelname',TRUE),
		'datemanufacured' => $this->input->post('datemanufacured',TRUE),
		'colletracondition' => $this->input->post('colletracondition',TRUE),
		'address' => $this->input->post('address',TRUE),
		'description' => $this->input->post('description',TRUE),
		'photo' => $this->input->post('photo',TRUE),
		'file' => $this->input->post('file',TRUE),
		'time_date' => $this->input->post('time_date',TRUE),
	    );

            $this->Colletral_model->update($this->input->post('colletral_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('colletral'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Colletral_model->get_by_id($id);

        if ($row) {
            $this->Colletral_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('colletral'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('colletral'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('borrowers_id', 'borrowers id', 'trim|required');
	$this->form_validation->set_rules('type', 'type', 'trim|required');
	$this->form_validation->set_rules('productname', 'productname', 'trim|required');
	$this->form_validation->set_rules('register', 'register', 'trim|required');
	$this->form_validation->set_rules('value', 'value', 'trim|required');
	$this->form_validation->set_rules('colletralstatus', 'colletralstatus', 'trim|required');
	$this->form_validation->set_rules('colletralstatus date', 'colletralstatus date', 'trim|required');
	$this->form_validation->set_rules('serialno', 'serialno', 'trim|required');
	$this->form_validation->set_rules('modelname', 'modelname', 'trim|required');
	$this->form_validation->set_rules('datemanufacured', 'datemanufacured', 'trim|required');
	$this->form_validation->set_rules('colletracondition', 'colletracondition', 'trim|required');
	$this->form_validation->set_rules('address', 'address', 'trim|required');
	$this->form_validation->set_rules('description', 'description', 'trim|required');
	$this->form_validation->set_rules('photo', 'photo', 'trim|required');
	$this->form_validation->set_rules('file', 'file', 'trim|required');
	$this->form_validation->set_rules('time_date', 'time date', 'trim|required');

	$this->form_validation->set_rules('colletral_id', 'colletral_id', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Colletral.php */
/* Location: ./application/controllers/Colletral.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2018-01-17 08:17:20 */
/* http://harviacode.com */