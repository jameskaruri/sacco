<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Savingproduct <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Savingproduct <?php echo form_error('savingproduct') ?></label>
            <input type="text" class="form-control" name="savingproduct" id="savingproduct" placeholder="Savingproduct" value="<?php echo $savingproduct; ?>" />
        </div>
	    <input type="hidden" name="savingproduct_id" value="<?php echo $savingproduct_id; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('savingproduct') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>