<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Cash Read</h2>
        <table class="table">
	    <tr><td>Apr</td><td><?php echo $Apr; ?></td></tr>
	    <tr><td>May</td><td><?php echo $May; ?></td></tr>
	    <tr><td>June</td><td><?php echo $June; ?></td></tr>
	    <tr><td>July</td><td><?php echo $July; ?></td></tr>
	    <tr><td>Aug</td><td><?php echo $Aug; ?></td></tr>
	    <tr><td>Sep</td><td><?php echo $Sep; ?></td></tr>
	    <tr><td>Type</td><td><?php echo $Type; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('cash') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>