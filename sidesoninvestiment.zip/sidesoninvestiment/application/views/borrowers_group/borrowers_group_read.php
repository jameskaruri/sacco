<!doctype html>
<html>
         <div class="content-wrapper">
                <!-- Content Header (Page header) -->
               
                <!-- Main content -->
               
            <div class="row">
                <div class="col-xs-6">
                    <div class="pull-left">
                        <div id="export_button">
                        </div>
                    </div>
                   
                </div>
                <div class="col-xs-6">
                    <div class="pull-right">
                        
            
                    </div>
                </div>
            </div> 
            
            

    </head>
    <body>

        <div class="row" style="margin-bottom: 10px">
            <div class="col-md-4">
                <h2 style="margin-top:0px"><b>group</b></h2>
            </div>
            <div class="col-md-4 text-center">
                <div style="margin-top: 4px"  id="message">
                    <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
                </div>
            </div></div>
        
        <table class="table">
	    <tr><td>Group Name</td><td><?php echo $group_name; ?></td></tr>
	    <tr><td>Borrowers Id</td><td><?php echo $borrowers_id; ?></td></tr>
	    <tr><td>Group Collector Name</td><td><?php echo $group_collector_name; ?></td></tr>
	    <tr><td>Group Meeting Schedule</td><td><?php echo $group_meeting_schedule; ?></td></tr>
	    <tr><td>Group Description</td><td><?php echo $group_description; ?></td></tr>
	    
	    <tr><td></td><td><a href="<?php echo site_url('borrowers_group') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>