$(function () {
    $.ajax({
           url: "selectvalues.php",
            type: "POST",
            dataType: "json",

        }).done(function(results) { 
               $("#view-savings-accounts-branch").html(results['tableData']);

        });
});