<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Borrowers extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Borrowers_model');
        $this->load->library('form_validation');
	$this->load->library('datatables');
        $this->load->library('custom_upload');

    }

    public function index()
    {
      $this->load->view('header/link');
        $this->load->view('borrowers/borrowers_view');
    }

    public function json() {
        header('Content-Type: application/json');
        echo $this->Borrowers_model->json();
    }

    public function read($id)
    {
        $row = $this->Borrowers_model->get_by_id($id);
        if ($row) {
            $data = array(
		'borrowers_id' => $row->borrowers_id,
		'borrower_surname' => $row->borrower_surname,
		'borrower_firstname' => $row->borrower_firstname,
		'borrower_lastname' => $row->borrower_lastname,
		'borrower_id_number' => $row->borrower_id_number,
		'borrower_email' => $row->borrower_email,
		'borrower_mobile' => $row->borrower_mobile,
		'borrower_gender' => $row->borrower_gender,
		'borrower_title' => $row->borrower_title,
		'borrower_dob' => $row->borrower_dob,
		'borrower_address' => $row->borrower_address,
		'borrower_zipcode' => $row->borrower_zipcode,
		'borrower_town' => $row->borrower_town,
		'borrower_street' => $row->borrower_street,
		'borrower_estate' => $row->borrower_estate,
		'borrower_nearestcommonfeature' => $row->borrower_nearestcommonfeature,
		'borrower_picture' => $row->borrower_picture,
		'borrower_description' => $row->borrower_description,
		'borrower_id' => $row->borrower_id,
		'borrower_business_name' => $row->borrower_business_name,
		'borrower_business_nature' => $row->borrower_business_nature,
		'borrower_business_Duration' => $row->borrower_business_Duration,
		'Business_owner' => $row->Business_owner,
		'address1' => $row->address1,
		'zipcode1' => $row->zipcode1,
		'town1' => $row->town1,
		'street1' => $row->street1,
		'estate1' => $row->estate1,
		'nearestcommonfeature1' => $row->nearestcommonfeature1,
		'business_location' => $row->business_location,
		'residence_location' => $row->residence_location,
		'borrower_access_ids' => $row->borrower_access_ids,
		'created_at' => $row->created_at,
	    );
            $this->load->view('header/link');
            $this->load->view('borrowers/borrowers_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('borrowers'));
        }
    }

    public function create()
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('borrowers/create_action'),
	    'borrowers_id' => set_value('borrowers_id'),
	    'borrower_surname' => set_value('borrower_surname'),
	    'borrower_firstname' => set_value('borrower_firstname'),
	    'borrower_lastname' => set_value('borrower_lastname'),
	    'borrower_id_number' => set_value('borrower_id_number'),
	    'borrower_email' => set_value('borrower_email'),
	    'borrower_mobile' => set_value('borrower_mobile'),
	    'borrower_gender' => set_value('borrower_gender'),
	    'borrower_title' => set_value('borrower_title'),
	    'borrower_dob' => set_value('borrower_dob'),
	    'borrower_address' => set_value('borrower_address'),
	    'borrower_zipcode' => set_value('borrower_zipcode'),
	    'borrower_town' => set_value('borrower_town'),
	    'borrower_street' => set_value('borrower_street'),
	    'borrower_estate' => set_value('borrower_estate'),
	    'borrower_nearestcommonfeature' => set_value('borrower_nearestcommonfeature'),

	    'borrower_description' => set_value('borrower_description'),

	    'borrower_business_name' => set_value('borrower_business_name'),
	    'borrower_business_nature' => set_value('borrower_business_nature'),
	    'borrower_business_Duration' => set_value('borrower_business_Duration'),
	    'Business_owner' => set_value('Business_owner'),
	    'address1' => set_value('address1'),
	    'zipcode1' => set_value('zipcode1'),
	    'town1' => set_value('town1'),
	    'street1' => set_value('street1'),
	    'estate1' => set_value('estate1'),
	    'nearestcommonfeature1' => set_value('nearestcommonfeature1'),
	    'business_location' => set_value('business_location'),
	    'residence_location' => set_value('residence_location'),


	);
  $this->load->view('header/link');
        $this->load->view('borrowers/add_borrower', $data);
    }

    public function create_action()
    {
    	$this->_rules();

       

        if ($this->form_validation->run()== FALSE ) {
          $this->create();}

         else {

            $data = array(
    'borrower_surname' => $this->input->post('borrower_surname',TRUE),
    'borrower_firstname' => $this->input->post('borrower_firstname',TRUE),
    'borrower_lastname' => $this->input->post('borrower_lastname',TRUE),
    'borrower_id_number' => $this->input->post('borrower_id_number',TRUE),
    'borrower_email' => $this->input->post('borrower_email',TRUE),
    'borrower_mobile' => $this->input->post('borrower_mobile',TRUE),
    'borrower_gender' => $this->input->post('borrower_gender',TRUE),
    'borrower_title' => $this->input->post('borrower_title',TRUE),
    'borrower_dob' => $this->input->post('borrower_dob',TRUE),
    'borrower_address' => $this->input->post('borrower_address',TRUE),
    'borrower_zipcode' => $this->input->post('borrower_zipcode',TRUE),
    'borrower_town' => $this->input->post('borrower_town',TRUE),
    'borrower_street' => $this->input->post('borrower_street',TRUE),
    'borrower_estate' => $this->input->post('borrower_estate',TRUE),
    'borrower_nearestcommonfeature' => $this->input->post('borrower_nearestcommonfeature',TRUE),
    'borrower_description' => $this->input->post('borrower_description',TRUE),
    'borrower_business_name' => $this->input->post('borrower_business_name',TRUE),
    'borrower_business_nature' => $this->input->post('borrower_business_nature',TRUE),
    'borrower_business_Duration' => $this->input->post('borrower_business_Duration',TRUE),
    'Business_owner' => $this->input->post('Business_owner',TRUE),
    'address1' => $this->input->post('address1',TRUE),
    'zipcode1' => $this->input->post('zipcode1',TRUE),
    'town1' => $this->input->post('town1',TRUE),
    'street1' => $this->input->post('street1',TRUE),
    'estate1' => $this->input->post('estate1',TRUE),
    'nearestcommonfeature1' => $this->input->post('nearestcommonfeature1',TRUE),
    'business_location' => $this->input->post('business_location',TRUE),
    'residence_location' => $this->input->post('residence_location',TRUE),
  );


            move_uploaded_file($_FILES['userfile']['tmp_name'], 'uploads/' . $data . '.jpeg|png|gif|jpg');
            
            $this->Borrowers_model->insert($data);
            $this->session->set_flashdata('message', 'added successifully');
            redirect(site_url('borrowers'));
        }

    }


    public function update($id)
    {
        $row = $this->Borrowers_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('borrowers/update_action'),
		'borrowers_id' => set_value('borrowers_id', $row->borrowers_id),
		'borrower_surname' => set_value('borrower_surname', $row->borrower_surname),
		'borrower_firstname' => set_value('borrower_firstname', $row->borrower_firstname),
		'borrower_lastname' => set_value('borrower_lastname', $row->borrower_lastname),
		'borrower_id_number' => set_value('borrower_id_number', $row->borrower_id_number),
		'borrower_email' => set_value('borrower_email', $row->borrower_email),
		'borrower_mobile' => set_value('borrower_mobile', $row->borrower_mobile),
		'borrower_gender' => set_value('borrower_gender', $row->borrower_gender),
		'borrower_title' => set_value('borrower_title', $row->borrower_title),
		'borrower_dob' => set_value('borrower_dob', $row->borrower_dob),
		'borrower_address' => set_value('borrower_address', $row->borrower_address),
		'borrower_zipcode' => set_value('borrower_zipcode', $row->borrower_zipcode),
		'borrower_town' => set_value('borrower_town', $row->borrower_town),
		'borrower_street' => set_value('borrower_street', $row->borrower_street),
		'borrower_estate' => set_value('borrower_estate', $row->borrower_estate),
		'borrower_nearestcommonfeature' => set_value('borrower_nearestcommonfeature', $row->borrower_nearestcommonfeature),
		'borrower_description' => set_value('borrower_description', $row->borrower_description),
		'borrower_business_name' => set_value('borrower_business_name', $row->borrower_business_name),
		'borrower_business_nature' => set_value('borrower_business_nature', $row->borrower_business_nature),
		'borrower_business_Duration' => set_value('borrower_business_Duration', $row->borrower_business_Duration),
		'Business_owner' => set_value('Business_owner', $row->Business_owner),
		'address1' => set_value('address1', $row->address1),
		'zipcode1' => set_value('zipcode1', $row->zipcode1),
		'town1' => set_value('town1', $row->town1),
		'street1' => set_value('street1', $row->street1),
		'estate1' => set_value('estate1', $row->estate1),
		'nearestcommonfeature1' => set_value('nearestcommonfeature1', $row->nearestcommonfeature1),
		'business_location' => set_value('business_location', $row->business_location),
		'residence_location' => set_value('residence_location', $row->residence_location),


	    );
      $this->load->view('header/link');
            $this->load->view('borrowers/add_borrower', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('borrowers'));
        }
    }

    public function update_action()
    {

        $this->_rules();
        $config['upload_path']          = './upload/';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 30000000;

  $this->load->library('upload',$config);

        if ($this->form_validation->run()== FALSE && $this->upload->do_upload() == FALSE) {
            $this->update($this->input->post('borrowers_id', TRUE));
        } else {
            $data = array(
		'borrower_surname' => $this->input->post('borrower_surname',TRUE),
		'borrower_firstname' => $this->input->post('borrower_firstname',TRUE),
		'borrower_lastname' => $this->input->post('borrower_lastname',TRUE),
		'borrower_id_number' => $this->input->post('borrower_id_number',TRUE),
		'borrower_email' => $this->input->post('borrower_email',TRUE),
		'borrower_mobile' => $this->input->post('borrower_mobile',TRUE),
		'borrower_gender' => $this->input->post('borrower_gender',TRUE),
		'borrower_title' => $this->input->post('borrower_title',TRUE),
		'borrower_dob' => $this->input->post('borrower_dob',TRUE),
		'borrower_address' => $this->input->post('borrower_address',TRUE),
		'borrower_zipcode' => $this->input->post('borrower_zipcode',TRUE),
		'borrower_town' => $this->input->post('borrower_town',TRUE),
		'borrower_street' => $this->input->post('borrower_street',TRUE),
		'borrower_estate' => $this->input->post('borrower_estate',TRUE),
		'borrower_nearestcommonfeature' => $this->input->post('borrower_nearestcommonfeature',TRUE),
		'borrower_description' => $this->input->post('borrower_description',TRUE),
		'borrower_business_name' => $this->input->post('borrower_business_name',TRUE),
		'borrower_business_nature' => $this->input->post('borrower_business_nature',TRUE),
		'borrower_business_Duration' => $this->input->post('borrower_business_Duration',TRUE),
		'Business_owner' => $this->input->post('Business_owner',TRUE),
		'address1' => $this->input->post('address1',TRUE),
		'zipcode1' => $this->input->post('zipcode1',TRUE),
		'town1' => $this->input->post('town1',TRUE),
		'street1' => $this->input->post('street1',TRUE),
		'estate1' => $this->input->post('estate1',TRUE),
		'nearestcommonfeature1' => $this->input->post('nearestcommonfeature1',TRUE),
		'business_location' => $this->input->post('business_location',TRUE),
		'residence_location' => $this->input->post('residence_location',TRUE),


	    );
      $data= $this->input->post('userfile',TRUE);
      $info= $this->upload->data();
        $img_path = base_url("upload/".$info['raw_name'].$info['file_ext']);
        $data['borrower_picture'] = $img_path;

            $this->Borrowers_model->update($this->input->post('borrowers_id', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('borrowers'));
        }
    }

    public function delete($id)
    {
        $row = $this->Borrowers_model->get_by_id($id);

        if ($row) {
            $this->Borrowers_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('borrowers'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('borrowers'));
        }
    }

    public function _rules()
    {
	$this->form_validation->set_rules('borrower_surname', 'borrower surname', 'trim|required');
	$this->form_validation->set_rules('borrower_firstname', 'borrower firstname', 'trim|required');
	$this->form_validation->set_rules('borrower_lastname', 'borrower lastname', 'trim|required');
	$this->form_validation->set_rules('borrower_id_number', 'borrower id number', 'trim|required|is_unique[borrowers.borrower_id_number]');
	
	$this->form_validation->set_rules('borrower_mobile', 'borrower mobile', 'trim|required|numeric');
	$this->form_validation->set_rules('borrower_gender', 'borrower gender', 'trim|required');
	$this->form_validation->set_rules('borrower_title', 'borrower title', 'trim|required');
	$this->form_validation->set_rules('borrower_dob', 'borrower dob', 'trim|required');
	$this->form_validation->set_rules('borrower_address', 'borrower address', 'trim|required');
	$this->form_validation->set_rules('borrower_zipcode', 'borrower zipcode', 'trim|required');
	$this->form_validation->set_rules('borrower_town', 'borrower town', 'trim|required');
	$this->form_validation->set_rules('borrower_street', 'borrower street', 'trim|required');
	$this->form_validation->set_rules('borrower_estate', 'borrower estate', 'trim|required');
	$this->form_validation->set_rules('borrower_nearestcommonfeature', 'borrower nearestcommonfeature', 'trim|required');
	$this->form_validation->set_rules('borrower_description', 'borrower description', 'trim|required');
	$this->form_validation->set_rules('borrower_business_name', 'borrower business name', 'trim|required');
	$this->form_validation->set_rules('borrower_business_nature', 'borrower business nature', 'trim|required');
	$this->form_validation->set_rules('borrower_business_Duration', 'borrower business duration', 'trim|required');
	$this->form_validation->set_rules('Business_owner', 'business owner', 'trim|required');
	$this->form_validation->set_rules('address1', 'address1', 'trim|required');
	$this->form_validation->set_rules('zipcode1', 'zipcode1', 'trim|required');
	$this->form_validation->set_rules('town1', 'town1', 'trim|required');
	$this->form_validation->set_rules('street1', 'street1', 'trim|required');
	$this->form_validation->set_rules('estate1', 'estate1', 'trim|required');
	$this->form_validation->set_rules('nearestcommonfeature1', 'nearestcommonfeature1', 'trim|required');
	$this->form_validation->set_rules('business_location', 'business location', 'trim|required');
	$this->form_validation->set_rules('residence_location', 'residence location', 'trim|required');
	$this->form_validation->set_message('is_unique', 'The Id number is already registered');
    $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }
   
    }


